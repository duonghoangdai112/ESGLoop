package com.ignitech.esgcompanion.data.seed

import com.ignitech.esgcompanion.data.repository.NotificationRepositoryImpl
import com.ignitech.esgcompanion.domain.entity.Notification
import com.ignitech.esgcompanion.domain.entity.NotificationType
import com.ignitech.esgcompanion.domain.entity.NotificationPriority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationSeeder @Inject constructor(
    private val notificationRepository: NotificationRepositoryImpl
) {
    
    fun seedNotifications() {
        CoroutineScope(Dispatchers.IO).launch {
            val notifications = generateSampleNotifications()
            notificationRepository.insertNotifications(notifications)
        }
    }
    
    private fun generateSampleNotifications(): List<Notification> {
        val currentTime = System.currentTimeMillis()
        val oneHourAgo = currentTime - 3600000
        val oneDayAgo = currentTime - 86400000
        val threeDaysAgo = currentTime - 259200000
        val oneWeekAgo = currentTime - 604800000
        
        return listOf(
            // Enterprise User Notifications
            Notification(
                id = "notif_001",
                title = "Đánh giá ESG hoàn thành",
                message = "Đánh giá ESG cho tháng 12/2024 đã được hoàn thành. Bạn có thể xem báo cáo chi tiết trong phần Báo cáo.",
                type = NotificationType.ASSESSMENT,
                userId = "enterprise_001",
                isRead = false,
                createdAt = oneHourAgo,
                priority = NotificationPriority.HIGH,
                actionUrl = "enterprise_report"
            ),
            
            Notification(
                id = "notif_002",
                title = "Báo cáo ESG đã sẵn sàng",
                message = "Báo cáo ESG tháng 12/2024 của Công ty TNHH Xây Dựng Xanh đã được tạo thành công và sẵn sàng để tải xuống.",
                type = NotificationType.REPORT,
                userId = "enterprise_001",
                isRead = false,
                createdAt = oneDayAgo,
                priority = NotificationPriority.NORMAL,
                actionUrl = "enterprise_report"
            ),
            
            Notification(
                id = "notif_003",
                title = "Nhắc nhở cập nhật dữ liệu",
                message = "Vui lòng cập nhật dữ liệu môi trường và xã hội cho quý 4/2024 trước ngày 31/12/2024.",
                type = NotificationType.REMINDER,
                userId = "enterprise_001",
                isRead = true,
                createdAt = threeDaysAgo,
                priority = NotificationPriority.HIGH,
                actionUrl = "enterprise_assessment"
            ),
            
            Notification(
                id = "notif_004",
                title = "Khóa học ESG mới",
                message = "Khóa học 'Quản lý rủi ro môi trường trong xây dựng' đã được thêm vào Learning Hub. Hãy tham gia để nâng cao kiến thức!",
                type = NotificationType.LEARNING,
                userId = "enterprise_001",
                isRead = true,
                createdAt = oneWeekAgo,
                priority = NotificationPriority.NORMAL,
                actionUrl = "learning_hub"
            ),
            
            // Expert User Notifications
            Notification(
                id = "notif_005",
                title = "Yêu cầu tư vấn mới",
                message = "Bạn có một yêu cầu tư vấn ESG mới từ Công ty ABC. Vui lòng xem xét và phản hồi trong 24 giờ.",
                type = NotificationType.ASSESSMENT,
                userId = "individual_001",
                isRead = false,
                createdAt = oneHourAgo,
                priority = NotificationPriority.HIGH,
                actionUrl = "expert_assessment"
            ),
            
            Notification(
                id = "notif_006",
                title = "Cập nhật ứng dụng",
                message = "Phiên bản 1.2.0 đã được phát hành với nhiều tính năng mới. Cập nhật ngay để trải nghiệm tốt nhất!",
                type = NotificationType.UPDATE,
                userId = "individual_001",
                isRead = false,
                createdAt = oneDayAgo,
                priority = NotificationPriority.NORMAL,
                actionUrl = null
            ),
            
            Notification(
                id = "notif_007",
                title = "Khuyến mãi gói Pro",
                message = "Giảm giá 30% cho gói Pro trong tháng 12. Nâng cấp ngay để tận hưởng các tính năng cao cấp!",
                type = NotificationType.PROMOTION,
                userId = "individual_001",
                isRead = true,
                createdAt = threeDaysAgo,
                priority = NotificationPriority.LOW,
                actionUrl = "settings"
            ),
            
            // Academic User Notifications
            Notification(
                id = "notif_008",
                title = "Báo cáo nghiên cứu ESG",
                message = "Báo cáo nghiên cứu 'Xu hướng ESG tại các trường đại học Việt Nam' đã được xuất bản thành công.",
                type = NotificationType.REPORT,
                userId = "academic_001",
                isRead = false,
                createdAt = oneHourAgo,
                priority = NotificationPriority.NORMAL,
                actionUrl = "expert_report"
            ),
            
            Notification(
                id = "notif_009",
                title = "Hội thảo ESG sắp diễn ra",
                message = "Hội thảo 'ESG và Phát triển bền vững trong giáo dục đại học' sẽ diễn ra vào ngày 15/12/2024 tại TP.HCM.",
                type = NotificationType.LEARNING,
                userId = "academic_001",
                isRead = true,
                createdAt = oneDayAgo,
                priority = NotificationPriority.NORMAL,
                actionUrl = "learning_hub"
            ),
            
            Notification(
                id = "notif_010",
                title = "Nhắc nhở nộp báo cáo",
                message = "Báo cáo ESG học kỳ 1/2024-2025 của Đại học Kinh tế TP.HCM cần được nộp trước ngày 20/12/2024.",
                type = NotificationType.REMINDER,
                userId = "academic_001",
                isRead = false,
                createdAt = threeDaysAgo,
                priority = NotificationPriority.HIGH,
                actionUrl = "regulatory_assessment"
            ),
            
            // Regulatory User Notifications
            Notification(
                id = "notif_011",
                title = "Cảnh báo bảo mật",
                message = "Phát hiện hoạt động đăng nhập bất thường từ địa chỉ IP lạ. Vui lòng kiểm tra và thay đổi mật khẩu nếu cần thiết.",
                type = NotificationType.SECURITY,
                userId = "regulatory_001",
                isRead = false,
                createdAt = oneHourAgo,
                priority = NotificationPriority.URGENT,
                actionUrl = "settings"
            ),
            
            Notification(
                id = "notif_012",
                title = "Báo cáo quy định mới",
                message = "Thông tư 15/2024/TT-BCT về báo cáo ESG cho doanh nghiệp đã được ban hành. Vui lòng cập nhật quy trình báo cáo.",
                type = NotificationType.SYSTEM,
                userId = "regulatory_001",
                isRead = true,
                createdAt = oneDayAgo,
                priority = NotificationPriority.HIGH,
                actionUrl = "policy"
            ),
            
            Notification(
                id = "notif_013",
                title = "Thống kê báo cáo ESG",
                message = "Tổng hợp báo cáo ESG từ các doanh nghiệp trong tháng 11/2024: 245 doanh nghiệp đã nộp báo cáo thành công.",
                type = NotificationType.REPORT,
                userId = "regulatory_001",
                isRead = true,
                createdAt = threeDaysAgo,
                priority = NotificationPriority.NORMAL,
                actionUrl = "analytics"
            ),
            
            // Additional notifications for variety
            Notification(
                id = "notif_014",
                title = "Hỗ trợ khách hàng 24/7",
                message = "Đội ngũ hỗ trợ của chúng tôi luôn sẵn sàng giúp đỡ bạn 24/7. Liên hệ qua email hoặc chat trực tuyến.",
                type = NotificationType.SYSTEM,
                userId = "enterprise_001",
                isRead = true,
                createdAt = oneWeekAgo,
                priority = NotificationPriority.LOW,
                actionUrl = null
            ),
            
            Notification(
                id = "notif_015",
                title = "Khảo sát mức độ hài lòng",
                message = "Chúng tôi đánh giá cao ý kiến của bạn. Vui lòng tham gia khảo sát ngắn để giúp chúng tôi cải thiện dịch vụ.",
                type = NotificationType.SYSTEM,
                userId = "individual_001",
                isRead = false,
                createdAt = oneWeekAgo,
                priority = NotificationPriority.LOW,
                actionUrl = null
            ),
            
            Notification(
                id = "notif_016",
                title = "Chúc mừng năm mới 2025",
                message = "Chúc bạn một năm mới thành công và phát triển bền vững! Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ ESG Companion.",
                type = NotificationType.SYSTEM,
                userId = "academic_001",
                isRead = true,
                createdAt = currentTime,
                priority = NotificationPriority.NORMAL,
                actionUrl = null
            )
        )
    }
}
