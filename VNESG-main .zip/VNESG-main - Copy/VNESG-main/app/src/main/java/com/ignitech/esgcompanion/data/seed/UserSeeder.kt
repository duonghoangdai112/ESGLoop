package com.ignitech.esgcompanion.data.seed

import com.ignitech.esgcompanion.data.local.entity.UserEntity
import com.ignitech.esgcompanion.domain.entity.SubscriptionPlan
import com.ignitech.esgcompanion.domain.entity.UserRole
import java.util.*

object UserSeeder {
    
    fun getDemoUsers(): List<UserEntity> {
        val currentTime = System.currentTimeMillis()
        
        return listOf(
            // Enterprise Users
            UserEntity(
                id = "enterprise_user_1",
                email = "enterprise@demo.com",
                password = "123456", // Demo password
                name = "Công ty TNHH Xây Dựng Xanh",
                role = UserRole.ENTERPRISE,
                companyId = "company_1",
                companyName = "Công ty TNHH Xây Dựng Xanh",
                subscriptionPlan = SubscriptionPlan.ENTERPRISE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 30, // 30 days ago
                lastLoginAt = currentTime - 86400000L * 1, // 1 day ago
                isActive = false
            ),
            UserEntity(
                id = "enterprise_user_2",
                email = "company2@demo.com",
                password = "123456",
                name = "Công ty Cổ phần Công nghệ Xanh",
                role = UserRole.ENTERPRISE,
                companyId = "company_2",
                companyName = "Công ty Cổ phần Công nghệ Xanh",
                subscriptionPlan = SubscriptionPlan.PRO,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 15,
                lastLoginAt = currentTime - 86400000L * 3,
                isActive = false
            ),
            
            // Expert Users
            UserEntity(
                id = "expert_user_1",
                email = "expert@demo.com",
                password = "123456",
                name = "TS. Nguyễn Minh Tuấn",
                role = UserRole.EXPERT,
                companyId = null,
                companyName = "Viện Nghiên cứu ESG",
                subscriptionPlan = SubscriptionPlan.ENTERPRISE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 60,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            ),
            UserEntity(
                id = "expert_user_2",
                email = "consultant@demo.com",
                password = "123456",
                name = "ThS. Trần Thị Hương",
                role = UserRole.EXPERT,
                companyId = null,
                companyName = "Công ty Tư vấn ESG",
                subscriptionPlan = SubscriptionPlan.PRO,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 45,
                lastLoginAt = currentTime - 86400000L * 5,
                isActive = false
            ),
            
            // Academic Users (Students/Teachers)
            UserEntity(
                id = "academic_user_1",
                email = "student@demo.com",
                password = "123456",
                name = "Nguyễn Thị Linh",
                role = UserRole.ACADEMIC,
                companyId = null,
                companyName = "Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 7,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "academic_user_2",
                email = "student2@demo.com",
                password = "123456",
                name = "Trần Đức Minh",
                role = UserRole.ACADEMIC,
                companyId = null,
                companyName = "Đại học Bách khoa Hà Nội",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 3,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            ),
            
            // Instructor Users
            UserEntity(
                id = "instructor_user_1",
                email = "instructor@demo.com",
                password = "123456",
                name = "TS. Nguyễn Thị Mai",
                role = UserRole.INSTRUCTOR,
                companyId = null,
                companyName = "Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.ENTERPRISE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 120,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "instructor_user_2",
                email = "teacher@demo.com",
                password = "123456",
                name = "ThS. Trần Văn Hùng",
                role = UserRole.INSTRUCTOR,
                companyId = null,
                companyName = "Đại học Bách khoa Hà Nội",
                subscriptionPlan = SubscriptionPlan.PRO,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 90,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            ),
            
            // Regulatory Users
            UserEntity(
                id = "regulatory_user_1",
                email = "regulatory@demo.com",
                password = "123456",
                name = "Lê Văn Đức",
                role = UserRole.REGULATORY,
                companyId = null,
                companyName = "Sở Tài nguyên và Môi trường Hà Nội",
                subscriptionPlan = SubscriptionPlan.ENTERPRISE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 90,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "regulatory_user_2",
                email = "inspector@demo.com",
                password = "123456",
                name = "Phạm Thị Lan",
                role = UserRole.REGULATORY,
                companyId = null,
                companyName = "Cục Bảo vệ Môi trường",
                subscriptionPlan = SubscriptionPlan.PRO,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 60,
                lastLoginAt = currentTime - 86400000L * 7,
                isActive = false
            )
        )
    }
    
    fun getCurrentActiveUser(): UserEntity? {
        return getDemoUsers().find { it.isActive }
    }
    
    fun getUserByEmail(email: String): UserEntity? {
        return getDemoUsers().find { it.email == email }
    }
    
    fun getUserById(userId: String): UserEntity? {
        return getDemoUsers().find { it.id == userId }
    }
    
    fun getExpertUsers(): List<UserEntity> {
        return getDemoUsers().filter { it.role == UserRole.EXPERT }
    }
    
    fun getAcademicUsers(): List<UserEntity> {
        return getDemoUsers().filter { it.role == UserRole.ACADEMIC }
    }
    
    fun getInstructorUsers(): List<UserEntity> {
        return getDemoUsers().filter { it.role == UserRole.INSTRUCTOR }
    }
}
