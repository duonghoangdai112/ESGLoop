package com.ignitech.esgcompanion.presentation.screen.expert

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.ignitech.esgcompanion.domain.entity.*
import com.ignitech.esgcompanion.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertAssessmentScreen(
    navController: NavController
) {
    var selectedTab by remember { mutableStateOf(0) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Đánh giá ESG - Chuyên gia",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Được mời xem") },
                    icon = { Icon(Icons.Default.Visibility, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Đã nhận xét") },
                    icon = { Icon(Icons.Default.Comment, contentDescription = null) }
                )
            }
            
            // Content based on selected tab
            when (selectedTab) {
                0 -> InvitedAssessmentsContent(navController = navController)
                1 -> ReviewedAssessmentsContent(navController = navController)
            }
        }
    }
}

@Composable
fun InvitedAssessmentsContent(
    navController: NavController
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(getInvitedAssessments()) { assessment ->
            InvitedAssessmentCard(
                assessment = assessment,
                onViewAssessment = { 
                    // TODO: Navigate to assessment review screen
                    // navController.navigate("assessment_review/${assessment.id}")
                },
                onAcceptInvite = { /* Accept invite logic */ }
            )
        }
    }
}

@Composable
fun ReviewedAssessmentsContent(
    navController: NavController
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(getReviewedAssessments()) { assessment ->
            ReviewedAssessmentCard(
                assessment = assessment,
                onViewFeedback = { 
                    // TODO: Navigate to feedback detail screen
                    // navController.navigate("feedback_detail/${assessment.id}")
                }
            )
        }
    }
}

@Composable
fun InvitedAssessmentCard(
    assessment: InvitedAssessment,
    onViewAssessment: () -> Unit,
    onAcceptInvite: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = assessment.enterpriseName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = assessment.assessmentTitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ExpertPillarChip(pillar = assessment.pillar)
                        ScoreChip(score = assessment.score, maxScore = assessment.maxScore)
                    }
                }
                
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = ESGSuccess.copy(alpha = 0.1f)
                    )
                ) {
                    Text(
                        text = "Mời xem",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = ESGSuccess
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Được mời bởi: ${assessment.invitedBy}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onViewAssessment,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Xem đánh giá")
                }
                
                Button(
                    onClick = onAcceptInvite,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Chấp nhận")
                }
            }
        }
    }
}

@Composable
fun ReviewedAssessmentCard(
    assessment: ReviewedAssessment,
    onViewFeedback: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = assessment.enterpriseName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = assessment.assessmentTitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ExpertPillarChip(pillar = assessment.pillar)
                        ScoreChip(score = assessment.score, maxScore = assessment.maxScore)
                    }
                }
                
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = ESGInfo.copy(alpha = 0.1f)
                    )
                ) {
                    Text(
                        text = "Đã nhận xét",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = ESGInfo
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Nhận xét: ${assessment.feedbackPreview}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Button(
                onClick = onViewFeedback,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Comment, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Xem nhận xét")
            }
        }
    }
}


@Composable
fun ScoreChip(score: Int, maxScore: Int) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
        )
    ) {
        Text(
            text = "$score/$maxScore",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

// Data classes for Individual Assessment Screen
data class InvitedAssessment(
    val id: String,
    val enterpriseName: String,
    val assessmentTitle: String,
    val pillar: ESGPillar,
    val score: Int,
    val maxScore: Int,
    val invitedBy: String,
    val invitedAt: Long
)

data class ReviewedAssessment(
    val id: String,
    val enterpriseName: String,
    val assessmentTitle: String,
    val pillar: ESGPillar,
    val score: Int,
    val maxScore: Int,
    val feedbackPreview: String,
    val reviewedAt: Long
)

// Mock data functions
private fun getInvitedAssessments(): List<InvitedAssessment> {
    return listOf(
        InvitedAssessment(
            id = "invited_001",
            enterpriseName = "Công ty TNHH ABC",
            assessmentTitle = "Đánh giá tác động môi trường",
            pillar = ESGPillar.ENVIRONMENTAL,
            score = 75,
            maxScore = 100,
            invitedBy = "Nguyễn Văn A",
            invitedAt = System.currentTimeMillis() - 86400000 * 2
        ),
        InvitedAssessment(
            id = "invited_002",
            enterpriseName = "Tập đoàn XYZ",
            assessmentTitle = "Quản trị doanh nghiệp",
            pillar = ESGPillar.GOVERNANCE,
            score = 82,
            maxScore = 100,
            invitedBy = "Trần Thị B",
            invitedAt = System.currentTimeMillis() - 86400000 * 5
        )
    )
}

private fun getReviewedAssessments(): List<ReviewedAssessment> {
    return listOf(
        ReviewedAssessment(
            id = "reviewed_001",
            enterpriseName = "Công ty DEF",
            assessmentTitle = "Quyền lao động",
            pillar = ESGPillar.SOCIAL,
            score = 68,
            maxScore = 100,
            feedbackPreview = "Doanh nghiệp cần cải thiện chế độ phúc lợi và đào tạo nhân viên...",
            reviewedAt = System.currentTimeMillis() - 86400000 * 7
        )
    )
}
