package com.ignitech.esgcompanion.domain.entity

enum class ESGPillar {
    ENVIRONMENTAL,  // Môi trường
    SOCIAL,         // Xã hội
    GOVERNANCE      // Quản trị
}

data class ESGPillarInfo(
    val pillar: ESGPillar,
    val name: String,
    val description: String,
    val icon: String,
    val color: String
) {
    companion object {
        val ENVIRONMENTAL_INFO = ESGPillarInfo(
            pillar = ESGPillar.ENVIRONMENTAL,
            name = "Môi trường",
            description = "Đo lường tác động của doanh nghiệp lên môi trường tự nhiên",
            icon = "🌱",
            color = "#4CAF50"
        )
        
        val SOCIAL_INFO = ESGPillarInfo(
            pillar = ESGPillar.SOCIAL,
            name = "Xã hội", 
            description = "Phản ánh cách doanh nghiệp đối xử với con người",
            icon = "👥",
            color = "#81C784"
        )
        
        val GOVERNANCE_INFO = ESGPillarInfo(
            pillar = ESGPillar.GOVERNANCE,
            name = "Quản trị",
            description = "Đánh giá cơ cấu quản lý và minh bạch tài chính",
            icon = "🏛️",
            color = "#8BC34A"
        )
        
        val ALL_PILLARS = listOf(ENVIRONMENTAL_INFO, SOCIAL_INFO, GOVERNANCE_INFO)
    }
}

