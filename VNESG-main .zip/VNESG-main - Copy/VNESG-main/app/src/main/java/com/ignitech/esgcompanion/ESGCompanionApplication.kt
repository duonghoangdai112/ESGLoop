package com.ignitech.esgcompanion

import android.app.Application
import com.ignitech.esgcompanion.data.local.DatabaseInitializer
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class ESGCompanionApplication : Application() {
    
    @Inject
    lateinit var databaseInitializer: DatabaseInitializer
    
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize database with demo data only if needed
        applicationScope.launch {
            try {
                // Only initialize if no users exist in database
                databaseInitializer.initializeDatabase()
            } catch (e: Exception) {
                // Log error but don't crash the app
                android.util.Log.e("ESGCompanionApplication", "Failed to initialize database", e)
            }
        }
    }
}