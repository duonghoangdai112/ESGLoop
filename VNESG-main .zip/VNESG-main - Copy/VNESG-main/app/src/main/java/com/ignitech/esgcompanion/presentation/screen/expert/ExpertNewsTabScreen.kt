package com.ignitech.esgcompanion.presentation.screen.expert

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.presentation.viewmodel.ExpertNewsTabViewModel
import com.ignitech.esgcompanion.utils.AppColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertNewsTabScreen(
    modifier: Modifier = Modifier,
    navController: androidx.navigation.NavController? = null,
    viewModel: ExpertNewsTabViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = AppColors()

    LaunchedEffect(Unit) {
        navController?.let { viewModel.setNavController(it) }
        viewModel.loadNewsData()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.backgroundSurface),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Section
        item {
            Column {
                Text(
                    text = "Tin tức ESG",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "Cập nhật tin tức và xu hướng ESG mới nhất",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            }
        }

        // Search and Filter
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = viewModel::updateSearchQuery,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Tìm kiếm tin tức...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.clearSearch() }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.primary,
                        unfocusedBorderColor = colors.borderLight
                    )
                )
                
                IconButton(onClick = { viewModel.toggleFilter() }) {
                    Icon(Icons.Default.FilterList, contentDescription = "Filter")
                }
            }
        }

        // Filter Section
        if (uiState.isFilterVisible) {
            item {
                NewsFilterSection(
                    selectedCategory = uiState.selectedCategory,
                    selectedPillar = uiState.selectedPillar,
                    selectedTimeRange = uiState.selectedTimeRange,
                    onCategorySelected = viewModel::selectCategory,
                    onPillarSelected = viewModel::selectPillar,
                    onTimeRangeSelected = viewModel::selectTimeRange
                )
            }
        }

        // Breaking News
        if (uiState.breakingNews.isNotEmpty()) {
            item {
                Text(
                    text = "Tin nóng",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.breakingNews) { news ->
                        BreakingNewsCard(
                            news = news,
                            onClick = { viewModel.openNews(news.id) }
                        )
                    }
                }
            }
        }

        // Featured News
        if (uiState.featuredNews.isNotEmpty()) {
            item {
                Text(
                    text = "Tin tức nổi bật",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            items(uiState.featuredNews) { news ->
                FeaturedNewsCard(
                    news = news,
                    onClick = { viewModel.openNews(news.id) },
                    onBookmark = { viewModel.toggleBookmark(news.id) },
                    onShare = { viewModel.shareNews(news.id) }
                )
            }
        }

        // News Categories
        item {
            Text(
                text = "Danh mục tin tức",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.newsCategories) { category ->
                    NewsCategoryCard(
                        category = category,
                        onClick = { viewModel.selectCategory(category.id) }
                    )
                }
            }
        }

        // Latest News
        if (uiState.latestNews.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tin tức mới nhất",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    
                    TextButton(onClick = { viewModel.viewAllNews() }) {
                        Text("Xem tất cả")
                        Icon(Icons.Default.ArrowForward, contentDescription = null)
                    }
                }
            }
            
            items(uiState.latestNews) { news ->
                NewsCard(
                    news = news,
                    onClick = { viewModel.openNews(news.id) },
                    onBookmark = { viewModel.toggleBookmark(news.id) },
                    onShare = { viewModel.shareNews(news.id) }
                )
            }
        }

        // Expert Insights
        if (uiState.expertInsights.isNotEmpty()) {
            item {
                Text(
                    text = "Góc nhìn chuyên gia",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            items(uiState.expertInsights) { insight ->
                ExpertInsightCard(
                    insight = insight,
                    onClick = { viewModel.openNews(insight.id) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsFilterSection(
    selectedCategory: String?,
    selectedPillar: ESGPillar?,
    selectedTimeRange: TimeRange?,
    onCategorySelected: (String?) -> Unit,
    onPillarSelected: (ESGPillar?) -> Unit,
    onTimeRangeSelected: (TimeRange?) -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Bộ lọc",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            // Category Filter
            Text(
                text = "Danh mục",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + listOf("Tất cả", "Môi trường", "Xã hội", "Quản trị", "Kinh tế", "Công nghệ")) { category ->
                    FilterChip(
                        selected = category == selectedCategory,
                        onClick = { onCategorySelected(category) },
                        label = { Text(category ?: "Tất cả") }
                    )
                }
            }
            
            // Pillar Filter
            Text(
                text = "Trụ cột ESG",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + ESGPillar.values().toList()) { pillar ->
                    PillarFilterChip(
                        pillar = pillar,
                        isSelected = pillar == selectedPillar,
                        onClick = { onPillarSelected(pillar) }
                    )
                }
            }
            
            // Time Range Filter
            Text(
                text = "Thời gian",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + TimeRange.values().toList()) { timeRange ->
                    TimeRangeFilterChip(
                        timeRange = timeRange,
                        isSelected = timeRange == selectedTimeRange,
                        onClick = { onTimeRangeSelected(timeRange) }
                    )
                }
            }
        }
    }
}

@Composable
fun BreakingNewsCard(
    news: ESGNews,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .width(280.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFF5722).copy(alpha = 0.1f)
        ),
         elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color(0xFFFF5722),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "TIN NÓNG",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Text(
                    text = "🔥",
                    style = MaterialTheme.typography.headlineSmall
                )
            }
            
            Text(
                text = news.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Text(
                text = news.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun FeaturedNewsCard(
    news: ESGNews,
    onClick: () -> Unit,
    onBookmark: () -> Unit,
    onShare: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = colors.primary.copy(alpha = 0.05f)
        ),
         elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = colors.primary,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "NỔI BẬT",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = onBookmark) {
                        Icon(
                            Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (news.isBookmarked) colors.primary else colors.textSecondary
                        )
                    }
                    IconButton(onClick = onShare) {
                        Icon(
                            Icons.Default.Share,
                            contentDescription = "Share",
                            tint = colors.textSecondary
                        )
                    }
                }
            }
            
            Text(
                text = news.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            Text(
                text = news.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = news.source,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    
                    Text(
                        text = dateFormat.format(Date(news.publishedAt)),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                
                ExpertPillarChip(pillar = news.pillar)
            }
        }
    }
}

@Composable
fun NewsCategoryCard(
    category: NewsCategory,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .width(120.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = category.icon,
                style = MaterialTheme.typography.headlineMedium
            )
            
            Text(
                text = category.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            
            Text(
                text = "${category.newsCount} tin",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
    }
}

@Composable
fun NewsCard(
    news: ESGNews,
    onClick: () -> Unit,
    onBookmark: () -> Unit,
    onShare: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // News Image Placeholder
            Surface(
                color = colors.primary.copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(80.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "📰",
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            }
            
            // News Content
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = news.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = news.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = news.source,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                        
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                        
                        Text(
                            text = dateFormat.format(Date(news.publishedAt)),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                    
                    ExpertPillarChip(pillar = news.pillar)
                }
            }
            
            // Action Buttons
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = onBookmark) {
                    Icon(
                        Icons.Default.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (news.isBookmarked) colors.primary else colors.textSecondary
                    )
                }
                IconButton(onClick = onShare) {
                    Icon(
                        Icons.Default.Share,
                        contentDescription = "Share",
                        tint = colors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun ExpertInsightCard(
    insight: ExpertInsight,
    onClick: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFF9800).copy(alpha = 0.05f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = Color(0xFFFF9800).copy(alpha = 0.1f),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = insight.expertName.take(1).uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFFFF9800),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Column {
                        Text(
                            text = insight.expertName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "Chuyên gia ESG",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
                
                Surface(
                    color = Color(0xFFFF9800),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "GÓC NHÌN",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            Text(
                text = insight.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            Text(
                text = insight.content,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            
            Text(
                text = dateFormat.format(Date(insight.publishedAt)),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PillarFilterChip(
    pillar: ESGPillar?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (pillar) {
                ESGPillar.ENVIRONMENTAL -> "Môi trường"
                ESGPillar.SOCIAL -> "Xã hội"
                ESGPillar.GOVERNANCE -> "Quản trị"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeRangeFilterChip(
    timeRange: TimeRange?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (timeRange) {
                TimeRange.TODAY -> "Hôm nay"
                TimeRange.WEEK -> "Tuần này"
                TimeRange.MONTH -> "Tháng này"
                TimeRange.YEAR -> "Năm nay"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

// Data classes
data class ESGNews(
    val id: String,
    val title: String,
    val summary: String,
    val content: String,
    val source: String,
    val pillar: ESGPillar,
    val publishedAt: Long,
    val isBookmarked: Boolean = false,
    val isBreaking: Boolean = false,
    val isFeatured: Boolean = false
)

data class NewsCategory(
    val id: String,
    val name: String,
    val icon: String,
    val newsCount: Int
)

data class ExpertInsight(
    val id: String,
    val title: String,
    val content: String,
    val expertName: String,
    val expertId: String,
    val publishedAt: Long
)

enum class TimeRange {
    TODAY, WEEK, MONTH, YEAR
}
