package com.ignitech.esgcompanion.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.data.repository.ESGAssessmentRepository
import com.ignitech.esgcompanion.domain.entity.UserRole
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LearningHubViewModel @Inject constructor(
    private val repository: ESGAssessmentRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(LearningHubUiState())
    val uiState: StateFlow<LearningHubUiState> = _uiState.asStateFlow()
    
    fun loadLearningHub() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isLoading = true)
                
                // Load categories for current role
                val categories = repository.getLearningCategoriesByUserRole(_uiState.value.selectedRole)
                val resources = repository.getLearningResourcesByUserRole(_uiState.value.selectedRole)
                val featuredResources = repository.getFeaturedResources(_uiState.value.selectedRole)
                
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    categories = categories,
                    resources = resources,
                    featuredResources = featuredResources
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Có lỗi xảy ra"
                )
            }
        }
    }
    
    fun selectRole(role: UserRole) {
        _uiState.value = _uiState.value.copy(selectedRole = role)
        loadLearningHub()
    }
    
    fun selectCategory(categoryId: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = categoryId)
        filterResources()
    }
    
    fun selectLevel(level: LearningLevel?) {
        _uiState.value = _uiState.value.copy(selectedLevel = level)
        filterResources()
    }
    
    fun selectType(type: LearningResourceType?) {
        _uiState.value = _uiState.value.copy(selectedType = type)
        filterResources()
    }
    
    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }
    
    fun performSearch() {
        viewModelScope.launch {
            try {
                val results = repository.searchLearningResources(
                    userRole = _uiState.value.selectedRole,
                    query = _uiState.value.searchQuery
                )
                _uiState.value = _uiState.value.copy(resources = results)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = e.message ?: "Lỗi tìm kiếm"
                )
            }
        }
    }
    
    fun toggleSearch() {
        _uiState.value = _uiState.value.copy(
            isSearchVisible = !_uiState.value.isSearchVisible
        )
    }
    
    fun toggleFilter() {
        _uiState.value = _uiState.value.copy(
            isFilterVisible = !_uiState.value.isFilterVisible
        )
    }
    
    fun toggleSort() {
        // TODO: Implement sorting logic
    }
    
    fun openResource(resource: LearningResourceEntity) {
        // TODO: Navigate to resource detail
    }
    
    fun toggleBookmark(resourceId: String) {
        viewModelScope.launch {
            try {
                repository.toggleBookmark("current_user_id", resourceId)
                // Refresh resources to update bookmark status
                loadLearningHub()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = e.message ?: "Lỗi bookmark"
                )
            }
        }
    }
    
    fun refresh() {
        loadLearningHub()
    }
    
    private fun filterResources() {
        viewModelScope.launch {
            try {
                val filteredResources = repository.getFilteredLearningResources(
                    userRole = _uiState.value.selectedRole,
                    categoryId = _uiState.value.selectedCategory.takeIf { it.isNotEmpty() },
                    level = _uiState.value.selectedLevel,
                    type = _uiState.value.selectedType
                )
                _uiState.value = _uiState.value.copy(resources = filteredResources)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = e.message ?: "Lỗi lọc tài liệu"
                )
            }
        }
    }
}

data class LearningHubUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val selectedRole: UserRole = UserRole.ENTERPRISE,
    val selectedCategory: String = "",
    val selectedLevel: LearningLevel? = null,
    val selectedType: LearningResourceType? = null,
    val searchQuery: String = "",
    val isSearchVisible: Boolean = false,
    val isFilterVisible: Boolean = false,
    val categories: List<LearningCategoryEntity> = emptyList(),
    val resources: List<LearningResourceEntity> = emptyList(),
    val featuredResources: List<LearningResourceEntity> = emptyList()
)
