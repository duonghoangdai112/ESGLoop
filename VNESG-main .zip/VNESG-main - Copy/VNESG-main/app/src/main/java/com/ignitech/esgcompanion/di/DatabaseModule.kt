package com.ignitech.esgcompanion.di

import android.content.Context
import androidx.room.Room
import com.ignitech.esgcompanion.data.local.dao.ESGScoresDao
import com.ignitech.esgcompanion.data.local.dao.UserDao
import com.ignitech.esgcompanion.data.local.dao.NotificationDao
import com.ignitech.esgcompanion.data.local.dao.AssessmentDao
import com.ignitech.esgcompanion.data.local.dao.ESGQuestionDao
import com.ignitech.esgcompanion.data.dao.LearningHubDao
import com.ignitech.esgcompanion.data.dao.ESGTrackerDao
import com.ignitech.esgcompanion.data.dao.ReportDao
import com.ignitech.esgcompanion.data.repository.ReportRepository
import com.ignitech.esgcompanion.data.database.ESGDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    @Singleton
    fun provideESGDatabase(@ApplicationContext context: Context): ESGDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            ESGDatabase::class.java,
            "esg_database"
        )
        .fallbackToDestructiveMigration()
        .build()
    }
    
    @Provides
    fun provideUserDao(database: ESGDatabase): UserDao {
        return database.userDao()
    }
    
    @Provides
    fun provideESGQuestionDao(database: ESGDatabase): ESGQuestionDao {
        return database.esgQuestionDao()
    }
    
    @Provides
    fun provideESGQuestionOptionDao(database: ESGDatabase): com.ignitech.esgcompanion.data.local.dao.ESGQuestionOptionDao {
        return database.esgQuestionOptionDao()
    }
    
    @Provides
    fun provideAssessmentDao(database: ESGDatabase): AssessmentDao {
        return database.assessmentDao()
    }
    
    @Provides
    fun provideNotificationDao(database: ESGDatabase): NotificationDao {
        return database.notificationDao()
    }
    
    @Provides
    fun provideESGAssessmentDao(database: ESGDatabase): com.ignitech.esgcompanion.data.dao.ESGAssessmentDao {
        return database.esgAssessmentDao()
    }
    
    @Provides
    fun provideESGScoresDao(database: ESGDatabase): ESGScoresDao {
        return database.esgScoresDao()
    }
    
    @Provides
    fun provideLearningHubDao(database: ESGDatabase): LearningHubDao {
        return database.learningHubDao()
    }
    
    @Provides
    fun provideESGTrackerDao(database: ESGDatabase): ESGTrackerDao {
        return database.esgTrackerDao()
    }
    
    @Provides
    fun provideReportDao(database: ESGDatabase): ReportDao {
        return database.reportDao()
    }
    
    @Provides
    fun provideReportRepository(
        esgAssessmentDao: com.ignitech.esgcompanion.data.dao.ESGAssessmentDao,
        esgTrackerDao: ESGTrackerDao,
        learningHubDao: LearningHubDao,
        reportDao: ReportDao
    ): ReportRepository {
        return ReportRepository(esgAssessmentDao, esgTrackerDao, learningHubDao, reportDao)
    }
}
