package com.ignitech.esgcompanion.presentation.screen.enterprise

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.domain.entity.*
import com.ignitech.esgcompanion.presentation.viewmodel.EnterpriseReportViewModel
import com.ignitech.esgcompanion.utils.AppColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnterpriseReportScreen(
    navController: androidx.navigation.NavHostController,
    modifier: Modifier = Modifier,
    viewModel: EnterpriseReportViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navigateToReportBuilder by viewModel.navigateToReportBuilder.collectAsStateWithLifecycle()
    val navigateToReportViewer by viewModel.navigateToReportViewer.collectAsStateWithLifecycle()
    val colors = AppColors()

    LaunchedEffect(Unit) {
        viewModel.loadReportData()
    }
    
    LaunchedEffect(navigateToReportBuilder) {
        navigateToReportBuilder?.let { template ->
            navController.navigate("report_builder/${template.name}") {
                // Create proper navigation stack
                popUpTo("enterprise_home") { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
            viewModel.onNavigateToReportBuilder()
        }
    }
    
    LaunchedEffect(navigateToReportViewer) {
        navigateToReportViewer?.let { reportId ->
            navController.navigate("report_viewer/$reportId") {
                // Create proper navigation stack
                popUpTo("enterprise_home") { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
            viewModel.onNavigateToReportViewer()
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text(
                            text = "Báo cáo ESG",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tổng hợp và xuất báo cáo",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.showCreateReport() }) {
                        Icon(
                            Icons.Default.Add, 
                            contentDescription = "Tạo báo cáo mới",
                            tint = colors.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.backgroundSurface,
                    titleContentColor = colors.textPrimary
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(colors.backgroundSurface),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Quick Stats
            item {
                QuickStatsSection(
                    totalReports = uiState.totalReports,
                    draftReports = uiState.draftReports,
                    publishedReports = uiState.publishedReports
                )
            }

            // Report Templates
            item {
                Text(
                    text = "Mẫu báo cáo",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                ReportTemplatesSection(
                    onTemplateSelected = viewModel::selectTemplate
                )
            }

            // Recent Reports
            item {
                Text(
                    text = "Báo cáo gần đây",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            if (uiState.recentReports.isNotEmpty()) {
                items(uiState.recentReports) { report ->
                    ReportCard(
                        report = report,
                        onClick = { viewModel.openReport(report.id) },
                        onShare = { viewModel.shareReport(report.id) },
                        onDelete = { viewModel.deleteReport(report.id) }
                    )
                }
            } else {
                    item {
                        ReportEmptyState(
                            message = "Chưa có báo cáo nào",
                            onCreateReport = { viewModel.showCreateReport() }
                        )
                    }
            }
        }
    }
}

@Composable
fun QuickStatsSection(
    totalReports: Int,
    draftReports: Int,
    publishedReports: Int
) {
    val colors = AppColors()
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatCard(
            title = "Tổng báo cáo",
            value = totalReports.toString(),
            color = colors.primary,
            modifier = Modifier.weight(1f)
        )
        
        StatCard(
            title = "Bản nháp",
            value = draftReports.toString(),
            color = Color(0xFFFF9800),
            modifier = Modifier.weight(1f)
        )
        
        StatCard(
            title = "Đã xuất bản",
            value = publishedReports.toString(),
            color = Color(0xFF4CAF50),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = color
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = color,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun ReportTemplatesSection(
    onTemplateSelected: (ReportStandard) -> Unit
) {
    val colors = AppColors()
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(ReportStandard.values().toList()) { standard ->
            TemplateCard(
                standard = standard,
                onClick = { onTemplateSelected(standard) }
            )
        }
    }
}

@Composable
fun TemplateCard(
    standard: ReportStandard,
    onClick: () -> Unit
) {
    val colors = AppColors()
    val (title, description, icon) = when (standard) {
        ReportStandard.GRI -> Triple("GRI", "Chuẩn quốc tế", "🌍")
        ReportStandard.SASB -> Triple("SASB", "Chuẩn tài chính", "💰")
        ReportStandard.VN_ENVIRONMENT -> Triple("VN MT", "Chuẩn Việt Nam", "🇻🇳")
        ReportStandard.CUSTOM -> Triple("Tùy chỉnh", "Mẫu riêng", "⚙️")
    }
    
    Card(
        modifier = Modifier
            .width(120.dp)
            .height(100.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = icon,
                style = MaterialTheme.typography.headlineSmall
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun ReportCard(
    report: ReportSummary,
    onClick: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = report.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    
                    Text(
                        text = "Tạo lúc: ${dateFormat.format(Date(report.createdAt))}",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                
                StatusChip(status = report.status)
            }
            
            Text(
                text = report.description,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Chuẩn: ${report.standard.name}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onShare) {
                        Icon(
                            Icons.Default.Share,
                            contentDescription = "Chia sẻ",
                            modifier = Modifier.size(20.dp),
                            tint = colors.primary
                        )
                    }
                    
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Xóa",
                            modifier = Modifier.size(20.dp),
                            tint = Color(0xFFF44336)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusChip(status: ReportStatus) {
    val (text, color) = when (status) {
        ReportStatus.DRAFT -> "Bản nháp" to Color(0xFFFF9800)
        ReportStatus.IN_REVIEW -> "Đang xem xét" to Color(0xFF2196F3)
        ReportStatus.APPROVED -> "Đã duyệt" to Color(0xFF4CAF50)
        ReportStatus.PUBLISHED -> "Đã xuất bản" to Color(0xFF2E7D32)
    }
    
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ReportEmptyState(
    message: String,
    onCreateReport: () -> Unit
) {
    val colors = AppColors()
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            Icons.Default.Assessment,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = colors.textSecondary
        )
        
        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = colors.textSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        
        Button(onClick = onCreateReport) {
            Text("Tạo báo cáo đầu tiên")
        }
    }
}

