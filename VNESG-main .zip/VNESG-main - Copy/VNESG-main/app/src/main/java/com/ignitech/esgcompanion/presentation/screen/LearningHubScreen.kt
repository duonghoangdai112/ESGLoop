package com.ignitech.esgcompanion.presentation.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.domain.entity.UserRole
import com.ignitech.esgcompanion.presentation.viewmodel.LearningHubViewModel
import com.ignitech.esgcompanion.utils.AppColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearningHubScreen(
    modifier: Modifier = Modifier,
    viewModel: LearningHubViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = AppColors()

    LaunchedEffect(Unit) {
        viewModel.loadLearningHub()
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Học liệu ESG") },
                actions = {
                    IconButton(onClick = { viewModel.toggleSearch() }) {
                        Icon(Icons.Default.Search, contentDescription = "Tìm kiếm")
                    }
                    IconButton(onClick = { viewModel.toggleFilter() }) {
                        Icon(Icons.Default.FilterList, contentDescription = "Lọc")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(colors.backgroundSurface)
        ) {
            // Role Filter Chips
            RoleFilterSection(
                selectedRole = uiState.selectedRole,
                onRoleSelected = viewModel::selectRole
            )

            // Search Bar (if visible)
            if (uiState.isSearchVisible) {
                SearchBar(
                    query = uiState.searchQuery,
                    onQueryChange = viewModel::updateSearchQuery,
                    onSearch = viewModel::performSearch
                )
            }

            // Filter Section (if visible)
            if (uiState.isFilterVisible) {
                FilterSection(
                    selectedCategory = uiState.selectedCategory,
                    selectedLevel = uiState.selectedLevel,
                    selectedType = uiState.selectedType,
                    onCategorySelected = viewModel::selectCategory,
                    onLevelSelected = viewModel::selectLevel,
                    onTypeSelected = viewModel::selectType
                )
            }

            // Content
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Featured Resources
                if (uiState.featuredResources.isNotEmpty()) {
                    item {
                        Text(
                            text = "Nổi bật",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            items(uiState.featuredResources) { resource ->
                                FeaturedResourceCard(
                                    resource = resource,
                                    onClick = { viewModel.openResource(resource) }
                                )
                            }
                        }
                    }
                }

                // Categories
                if (uiState.categories.isNotEmpty()) {
                    item {
                        Text(
                            text = "Danh mục",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            items(uiState.categories) { category ->
                                CategoryChip(
                                    category = category,
                                    isSelected = category.id == uiState.selectedCategory,
                                    onClick = { viewModel.selectCategory(category.id) }
                                )
                            }
                        }
                    }
                }

                // Resources List
                if (uiState.resources.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Tài liệu học tập",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            
                            TextButton(onClick = { viewModel.toggleSort() }) {
                                Text("Sắp xếp")
                                Icon(Icons.Default.Sort, contentDescription = null)
                            }
                        }
                    }
                    
                    items(uiState.resources) { resource ->
                        ResourceCard(
                            resource = resource,
                            onClick = { viewModel.openResource(resource) },
                            onBookmark = { viewModel.toggleBookmark(resource.id) }
                        )
                    }
                } else {
                    item {
                        EmptyState(
                            message = "Không tìm thấy tài liệu nào",
                            onRefresh = { viewModel.refresh() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RoleFilterSection(
    selectedRole: UserRole,
    onRoleSelected: (UserRole) -> Unit
) {
    val colors = AppColors()
    
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(UserRole.values().toList()) { role ->
            RoleChip(
                role = role,
                isSelected = role == selectedRole,
                onClick = { onRoleSelected(role) }
            )
        }
    }
}

@Composable
fun RoleChip(
    role: UserRole,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple()
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (role) {
                UserRole.ENTERPRISE -> "Doanh nghiệp"
                UserRole.ACADEMIC -> "Sinh viên"
                UserRole.INSTRUCTOR -> "Giảng viên"
                UserRole.REGULATORY -> "Cơ quan quản lý"
                UserRole.EXPERT -> "Chuyên gia"
            },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@Composable
fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit
) {
    val colors = AppColors()
    
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { 
            Text(
                text = "Tìm kiếm tài liệu...",
                color = colors.textSecondary.copy(alpha = 0.6f)
            ) 
        },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Xóa")
                }
            }
        },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.primary,
            unfocusedBorderColor = colors.borderLight
        )
    )
}

@Composable
fun FilterSection(
    selectedCategory: String,
    selectedLevel: LearningLevel?,
    selectedType: LearningResourceType?,
    onCategorySelected: (String) -> Unit,
    onLevelSelected: (LearningLevel?) -> Unit,
    onTypeSelected: (LearningResourceType?) -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Bộ lọc",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            // Level Filter
            Text(
                text = "Mức độ",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + LearningLevel.values().toList()) { level ->
                    LevelChip(
                        level = level,
                        isSelected = level == selectedLevel,
                        onClick = { onLevelSelected(level) }
                    )
                }
            }
            
            // Type Filter
            Text(
                text = "Loại tài liệu",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + LearningResourceType.values().toList()) { type ->
                    TypeChip(
                        type = type,
                        isSelected = type == selectedType,
                        onClick = { onTypeSelected(type) }
                    )
                }
            }
        }
    }
}

@Composable
fun LevelChip(
    level: LearningLevel?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple()
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (level) {
                LearningLevel.BEGINNER -> "Cơ bản"
                LearningLevel.INTERMEDIATE -> "Trung cấp"
                LearningLevel.ADVANCED -> "Nâng cao"
                LearningLevel.EXPERT -> "Chuyên gia"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@Composable
fun TypeChip(
    type: LearningResourceType?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple()
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (type) {
                LearningResourceType.VIDEO -> "Video"
                LearningResourceType.ARTICLE -> "Bài viết"
                LearningResourceType.COURSE -> "Khóa học"
                LearningResourceType.TEMPLATE -> "Template"
                LearningResourceType.CHECKLIST -> "Checklist"
                LearningResourceType.DOCUMENT -> "Tài liệu"
                LearningResourceType.PODCAST -> "Podcast"
                LearningResourceType.WEBINAR -> "Webinar"
                LearningResourceType.TOOL -> "Công cụ"
                LearningResourceType.CASE_STUDY -> "Case Study"
                LearningResourceType.GUIDELINE -> "Hướng dẫn"
                LearningResourceType.PRESENTATION -> "Presentation"
                LearningResourceType.SPREADSHEET -> "Spreadsheet"
                LearningResourceType.INTERACTIVE -> "Tương tác"
                LearningResourceType.WORKSHOP -> "Thực hành"
                LearningResourceType.GUIDE -> "Hướng dẫn"
                LearningResourceType.RESEARCH -> "Nghiên cứu"
                LearningResourceType.LESSON -> "Bài giảng"
                LearningResourceType.ASSIGNMENT -> "Bài tập"
                LearningResourceType.QUIZ -> "Câu hỏi"
                LearningResourceType.EXAM -> "Bài thi"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@Composable
fun CategoryChip(
    category: LearningCategoryEntity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple()
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = category.icon,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = category.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else colors.textPrimary
            )
        }
    }
}

@Composable
fun FeaturedResourceCard(
    resource: LearningResourceEntity,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .width(280.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = getResourceTypeIcon(resource.type),
                    style = MaterialTheme.typography.headlineMedium
                )
                
                if (resource.isFeatured) {
                Surface(
                    color = colors.primary,
                    shape = RoundedCornerShape(12.dp)
                ) {
                        Text(
                            text = "Nổi bật",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }
                }
            }
            
            Text(
                text = resource.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Text(
                text = resource.description,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${resource.duration} phút",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = String.format("%.1f", resource.rating),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun ResourceCard(
    resource: LearningResourceEntity,
    onClick: () -> Unit,
    onBookmark: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Resource Icon
            Surface(
                color = colors.primary.copy(alpha = 0.1f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = getResourceTypeIcon(resource.type),
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            }
            
            // Resource Info
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = resource.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = resource.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = resource.category,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    
                    Text(
                        text = when (resource.level) {
                            LearningLevel.BEGINNER -> "Cơ bản"
                            LearningLevel.INTERMEDIATE -> "Trung cấp"
                            LearningLevel.ADVANCED -> "Nâng cao"
                            LearningLevel.EXPERT -> "Chuyên gia"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    
                    Text(
                        text = "${resource.duration} phút",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
            }
            
            // Bookmark Button
            IconButton(onClick = onBookmark) {
                Icon(
                    Icons.Default.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = colors.textSecondary
                )
            }
        }
    }
}

@Composable
fun EmptyState(
    message: String,
    onRefresh: () -> Unit
) {
    val colors = AppColors()
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            Icons.Default.SearchOff,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = colors.textSecondary
        )
        
        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = colors.textSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        
        Button(onClick = onRefresh) {
            Text("Làm mới")
        }
    }
}

private fun getResourceTypeIcon(type: LearningResourceType): String {
    return when (type) {
        LearningResourceType.VIDEO -> "🎥"
        LearningResourceType.ARTICLE -> "📄"
        LearningResourceType.COURSE -> "🎓"
        LearningResourceType.TEMPLATE -> "📋"
        LearningResourceType.CHECKLIST -> "✅"
        LearningResourceType.DOCUMENT -> "📑"
        LearningResourceType.PODCAST -> "🎧"
        LearningResourceType.WEBINAR -> "💻"
        LearningResourceType.TOOL -> "🛠️"
        LearningResourceType.CASE_STUDY -> "📊"
        LearningResourceType.GUIDELINE -> "📖"
        LearningResourceType.PRESENTATION -> "📽️"
        LearningResourceType.SPREADSHEET -> "📈"
        LearningResourceType.INTERACTIVE -> "🎮"
        LearningResourceType.WORKSHOP -> "🔧"
        LearningResourceType.GUIDE -> "📖"
        LearningResourceType.RESEARCH -> "🔬"
        LearningResourceType.LESSON -> "📚"
        LearningResourceType.ASSIGNMENT -> "📝"
        LearningResourceType.QUIZ -> "❓"
        LearningResourceType.EXAM -> "📋"
    }
}
