package com.ignitech.esgcompanion.presentation.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(
    navController: NavController
) {
    var expandedFAQ by remember { mutableStateOf<String?>(null) }
    var showContactDialog by remember { mutableStateOf(false) }
    
    val faqItems = listOf(
        FAQItem(
            id = "faq_1",
            question = "Làm thế nào để tạo đánh giá ESG?",
            answer = "Để tạo đánh giá ESG, bạn cần:\n\n1. Vào màn hình 'Đánh giá' từ trang chủ\n2. Chọn loại đánh giá phù hợp với vai trò của bạn\n3. Điền đầy đủ thông tin theo từng phần (Môi trường, Xã hội, Quản trị)\n4. Xem lại và gửi đánh giá\n5. Theo dõi kết quả trong phần 'Báo cáo'"
        ),
        FAQItem(
            id = "faq_2",
            question = "Tôi có thể chỉnh sửa đánh giá sau khi gửi không?",
            answer = "Bạn có thể chỉnh sửa đánh giá trong vòng 24 giờ sau khi gửi. Sau thời gian này, bạn sẽ cần tạo đánh giá mới để cập nhật thông tin."
        ),
        FAQItem(
            id = "faq_3",
            question = "Làm sao để xem báo cáo ESG?",
            answer = "Để xem báo cáo ESG:\n\n1. Vào màn hình 'Báo cáo' từ trang chủ\n2. Chọn báo cáo bạn muốn xem\n3. Báo cáo sẽ hiển thị kết quả đánh giá ESG của bạn\n4. Bạn có thể tải xuống báo cáo dưới dạng PDF"
        ),
        FAQItem(
            id = "faq_4",
            question = "Ứng dụng có hỗ trợ đa ngôn ngữ không?",
            answer = "Hiện tại ứng dụng hỗ trợ tiếng Việt và tiếng Anh. Bạn có thể thay đổi ngôn ngữ trong phần 'Cài đặt' > 'Ngôn ngữ'."
        ),
        FAQItem(
            id = "faq_5",
            question = "Làm thế nào để nâng cấp gói dịch vụ?",
            answer = "Để nâng cấp gói dịch vụ:\n\n1. Vào 'Cài đặt' > 'Thông tin tài khoản'\n2. Xem gói dịch vụ hiện tại\n3. Liên hệ với bộ phận hỗ trợ để được tư vấn gói phù hợp\n4. Thanh toán và kích hoạt gói mới"
        ),
        FAQItem(
            id = "faq_6",
            question = "Tôi quên mật khẩu, làm sao để khôi phục?",
            answer = "Để khôi phục mật khẩu:\n\n1. Vào màn hình đăng nhập\n2. Nhấn 'Quên mật khẩu?'\n3. Nhập email đã đăng ký\n4. Kiểm tra email và làm theo hướng dẫn\n5. Tạo mật khẩu mới"
        )
    )
    
    val supportOptions = listOf(
        SupportOption(
            icon = Icons.Default.Email,
            title = "Email hỗ trợ",
            subtitle = "support@esgcompanion.vn",
            onClick = { /* Open email client */ }
        ),
        SupportOption(
            icon = Icons.Default.Phone,
            title = "Hotline",
            subtitle = "1900 1234",
            onClick = { /* Open phone dialer */ }
        ),
        SupportOption(
            icon = Icons.Default.Chat,
            title = "Chat trực tuyến",
            subtitle = "Hỗ trợ 24/7",
            onClick = { /* Open chat */ }
        ),
        SupportOption(
            icon = Icons.Default.VideoCall,
            title = "Video call",
            subtitle = "Tư vấn trực tiếp",
            onClick = { /* Open video call */ }
        )
    )
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trợ giúp") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Welcome Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Help,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Text(
                            text = "Chúng tôi luôn sẵn sàng hỗ trợ bạn!",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            textAlign = TextAlign.Center
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = "Tìm câu trả lời cho các câu hỏi thường gặp hoặc liên hệ với chúng tôi để được hỗ trợ.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            
            // FAQ Section
            item {
                HelpSectionCard(
                    title = "Câu hỏi thường gặp",
                    icon = Icons.Default.QuestionAnswer,
                    items = faqItems.map { faq ->
                        HelpItem(
                            title = faq.question,
                            subtitle = if (expandedFAQ == faq.id) faq.answer else null,
                            icon = Icons.Default.HelpOutline,
                            isExpandable = true,
                            isExpanded = expandedFAQ == faq.id,
                            onClick = {
                                expandedFAQ = if (expandedFAQ == faq.id) null else faq.id
                            }
                        )
                    }
                )
            }
            
            // Support Section
            item {
                HelpSectionCard(
                    title = "Liên hệ hỗ trợ",
                    icon = Icons.Default.Support,
                    items = supportOptions.map { option ->
                        HelpItem(
                            title = option.title,
                            subtitle = option.subtitle,
                            icon = option.icon,
                            onClick = option.onClick
                        )
                    }
                )
            }
            
            // Quick Actions Section
            item {
                HelpSectionCard(
                    title = "Thao tác nhanh",
                    icon = Icons.Default.Speed,
                    items = listOf(
                        HelpItem(
                            title = "Hướng dẫn sử dụng",
                            subtitle = "Xem video hướng dẫn chi tiết",
                            icon = Icons.Default.PlayCircle,
                            onClick = { /* Navigate to tutorial */ }
                        ),
                        HelpItem(
                            title = "Góp ý ứng dụng",
                            subtitle = "Chia sẻ ý kiến của bạn",
                            icon = Icons.Default.Feedback,
                            onClick = { /* Open feedback form */ }
                        ),
                        HelpItem(
                            title = "Báo lỗi",
                            subtitle = "Báo cáo sự cố gặp phải",
                            icon = Icons.Default.BugReport,
                            onClick = { /* Open bug report form */ }
                        )
                    )
                )
            }
            
            // Resources Section
            item {
                HelpSectionCard(
                    title = "Tài nguyên",
                    icon = Icons.Default.LibraryBooks,
                    items = listOf(
                        HelpItem(
                            title = "Tài liệu ESG",
                            subtitle = "Tìm hiểu về ESG và bền vững",
                            icon = Icons.Default.MenuBook,
                            onClick = { /* Navigate to ESG docs */ }
                        ),
                        HelpItem(
                            title = "Video hướng dẫn",
                            subtitle = "Xem các video hướng dẫn chi tiết",
                            icon = Icons.Default.VideoLibrary,
                            onClick = { /* Navigate to video tutorials */ }
                        ),
                        HelpItem(
                            title = "Cộng đồng",
                            subtitle = "Tham gia cộng đồng ESG Việt Nam",
                            icon = Icons.Default.Group,
                            onClick = { /* Navigate to community */ }
                        )
                    )
                )
            }
        }
    }
}

@Composable
fun HelpSectionCard(
    title: String,
    icon: ImageVector,
    items: List<HelpItem>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primary,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
                
                Spacer(modifier = Modifier.width(10.dp))
                
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            
            items.forEachIndexed { index, item ->
                HelpItemRow(item = item)
                if (index < items.size - 1) {
                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpItemRow(
    item: HelpItem
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = item.onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.title,
                    modifier = Modifier.size(24.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    item.subtitle?.let { subtitle ->
                        Spacer(modifier = Modifier.height(1.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
                
                if (item.isExpandable) {
                    Icon(
                        imageVector = if (item.isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (item.isExpanded) "Thu gọn" else "Mở rộng",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Navigate",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
            
            // Expanded content
            if (item.isExpanded && item.subtitle != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = MaterialTheme.typography.bodyMedium.lineHeight * 1.4
                )
            }
        }
    }
}

data class HelpItem(
    val icon: ImageVector,
    val title: String,
    val subtitle: String?,
    val onClick: () -> Unit,
    val isExpandable: Boolean = false,
    val isExpanded: Boolean = false
)

data class FAQItem(
    val id: String,
    val question: String,
    val answer: String
)

data class SupportOption(
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val onClick: () -> Unit
)
