package com.ignitech.esgcompanion.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.ignitech.esgcompanion.data.local.dao.ESGScoresDao
import com.ignitech.esgcompanion.data.local.dao.UserDao
import com.ignitech.esgcompanion.data.local.dao.NotificationDao
import com.ignitech.esgcompanion.data.local.dao.AssessmentDao
import com.ignitech.esgcompanion.data.dao.LearningHubDao
import com.ignitech.esgcompanion.data.dao.ESGTrackerDao
import com.ignitech.esgcompanion.data.dao.ReportDao
import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.data.local.entity.ESGAssessmentEntity
import com.ignitech.esgcompanion.data.local.entity.ESGAnswerEntity
import com.ignitech.esgcompanion.data.local.entity.ESGQuestionEntity
import com.ignitech.esgcompanion.data.local.entity.ESGQuestionOptionEntity
import com.ignitech.esgcompanion.data.local.entity.UserEntity
import com.ignitech.esgcompanion.data.local.entity.NotificationEntity
import com.ignitech.esgcompanion.data.local.entity.QuizAttemptEntity
import com.ignitech.esgcompanion.data.local.entity.AssessmentFeedbackEntity
import com.ignitech.esgcompanion.data.converter.ESGTypeConverters

@Database(
    entities = [
        UserEntity::class,
        com.ignitech.esgcompanion.data.local.entity.ESGQuestionEntity::class,
        com.ignitech.esgcompanion.data.local.entity.ESGQuestionOptionEntity::class,
        ESGAssessmentEntity::class,
        ESGAnswerEntity::class,
        QuizAttemptEntity::class,
        AssessmentFeedbackEntity::class,
        NotificationEntity::class,
        ESGCategoryEntity::class,
        LearningResourceEntity::class,
        LearningCategoryEntity::class,
        LearningProgressEntity::class,
        LearningCertificateEntity::class,
        LearningQuizEntity::class,
        LearningQuizAttemptEntity::class,
        AssignmentSubmissionEntity::class,
        QuestionAttemptEntity::class,
        ESGTrackerEntity::class,
        ESGTrackerAttachmentEntity::class,
        ESGTrackerKPIEntity::class,
        ESGTrackerKPIValueEntity::class,
        ESGTrackerTimelineEntity::class,
        ReportEntity::class,
        ReportSectionEntity::class,
        ReportFieldEntity::class
    ],
    version = 5,
    exportSchema = false
)
@TypeConverters(ESGTypeConverters::class)
abstract class ESGDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun esgQuestionDao(): com.ignitech.esgcompanion.data.local.dao.ESGQuestionDao
    abstract fun esgQuestionOptionDao(): com.ignitech.esgcompanion.data.local.dao.ESGQuestionOptionDao
    abstract fun assessmentDao(): AssessmentDao
    abstract fun notificationDao(): NotificationDao
    abstract fun esgAssessmentDao(): com.ignitech.esgcompanion.data.dao.ESGAssessmentDao
    abstract fun esgScoresDao(): ESGScoresDao
    abstract fun learningHubDao(): LearningHubDao
    abstract fun esgTrackerDao(): ESGTrackerDao
    abstract fun reportDao(): ReportDao
    
    companion object {
        @Volatile
        private var INSTANCE: ESGDatabase? = null
        
        fun getDatabase(context: Context): ESGDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ESGDatabase::class.java,
                    "esg_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
