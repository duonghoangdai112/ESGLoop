package com.ignitech.esgcompanion.data.seed

import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.domain.entity.UserRole

object LearningHubSeeder {
    
    fun getLearningCategories(): List<LearningCategoryEntity> {
        return listOf(
            // Categories for all user roles
            LearningCategoryEntity(
                id = "cat_esg_fundamentals",
                name = "Kiến thức cơ bản ESG",
                description = "Những khái niệm và nguyên tắc cơ bản về ESG",
                icon = "📚",
                color = "#4CAF50",
                userRole = UserRole.ENTERPRISE,
                order = 1
            ),
            LearningCategoryEntity(
                id = "cat_esg_fundamentals_student",
                name = "Kiến thức cơ bản ESG",
                description = "Những khái niệm và nguyên tắc cơ bản về ESG",
                icon = "📚",
                color = "#4CAF50",
                userRole = UserRole.ACADEMIC,
                order = 1
            ),
            LearningCategoryEntity(
                id = "cat_environmental",
                name = "Môi trường (Environmental)",
                description = "Quản lý môi trường, biến đổi khí hậu, tài nguyên",
                icon = "🌱",
                color = "#8BC34A",
                userRole = UserRole.ENTERPRISE,
                order = 2
            ),
            LearningCategoryEntity(
                id = "cat_social",
                name = "Xã hội (Social)",
                description = "Trách nhiệm xã hội, quyền con người, cộng đồng",
                icon = "👥",
                color = "#FF9800",
                userRole = UserRole.ENTERPRISE,
                order = 3
            ),
            LearningCategoryEntity(
                id = "cat_governance",
                name = "Quản trị (Governance)",
                description = "Quản trị doanh nghiệp, minh bạch, đạo đức",
                icon = "🏛️",
                color = "#2196F3",
                userRole = UserRole.ENTERPRISE,
                order = 4
            ),
            LearningCategoryEntity(
                id = "cat_reporting",
                name = "Báo cáo ESG",
                description = "Hướng dẫn lập báo cáo ESG, tiêu chuẩn quốc tế",
                icon = "📊",
                color = "#9C27B0",
                userRole = UserRole.ENTERPRISE,
                order = 5
            ),
            LearningCategoryEntity(
                id = "cat_consulting_tools",
                name = "Công cụ tư vấn",
                description = "Template, checklist, công cụ hỗ trợ tư vấn ESG",
                icon = "🛠️",
                color = "#607D8B",
                userRole = UserRole.REGULATORY,
                order = 1
            ),
            LearningCategoryEntity(
                id = "cat_policy_regulations",
                name = "Chính sách & Quy định",
                description = "Chính sách ESG quốc tế và Việt Nam",
                icon = "📋",
                color = "#795548",
                userRole = UserRole.REGULATORY,
                order = 2
            ),
            
            // Expert Categories
            LearningCategoryEntity(
                id = "cat_expert_consulting",
                name = "Tư vấn ESG",
                description = "Kỹ năng tư vấn và triển khai ESG chuyên sâu",
                icon = "🎯",
                color = "#FF5722",
                userRole = UserRole.EXPERT,
                order = 1
            ),
            LearningCategoryEntity(
                id = "cat_expert_reporting",
                name = "Báo cáo ESG",
                description = "Báo cáo ESG theo chuẩn quốc tế",
                icon = "📊",
                color = "#2196F3",
                userRole = UserRole.EXPERT,
                order = 2
            ),
            LearningCategoryEntity(
                id = "cat_expert_risk",
                name = "Quản lý rủi ro",
                description = "Đánh giá và quản lý rủi ro ESG",
                icon = "⚠️",
                color = "#FF9800",
                userRole = UserRole.EXPERT,
                order = 3
            ),
            LearningCategoryEntity(
                id = "cat_expert_investment",
                name = "Đầu tư ESG",
                description = "Đầu tư và tài chính bền vững",
                icon = "💰",
                color = "#4CAF50",
                userRole = UserRole.EXPERT,
                order = 4
            )
        )
    }
    
    fun getLearningResources(): List<LearningResourceEntity> {
        return listOf(
            // Resources for Enterprise users
            LearningResourceEntity(
                id = "res_esg_intro_video",
                title = "ESG là gì? Tổng quan về ESG cho doanh nghiệp",
                description = "Video giới thiệu tổng quan về ESG, tầm quan trọng và lợi ích cho doanh nghiệp",
                content = "ESG (Environmental, Social, Governance) là bộ tiêu chuẩn đánh giá tác động của doanh nghiệp đến môi trường, xã hội và quản trị...",
                type = LearningResourceType.VIDEO,
                category = "Kiến thức cơ bản ESG",
                subcategory = "Giới thiệu ESG",
                level = LearningLevel.BEGINNER,
                userRole = UserRole.ENTERPRISE,
                industry = "Tất cả",
                duration = 15,
                difficulty = 1,
                rating = 4.5f,
                viewCount = 1250,
                isFeatured = true,
                thumbnailUrl = "https://example.com/thumbnails/esg_intro.jpg",
                videoUrl = "https://example.com/videos/esg_intro.mp4",
                tags = "ESG, cơ bản, doanh nghiệp, môi trường, xã hội, quản trị",
                learningObjectives = "Hiểu được khái niệm ESG, Tầm quan trọng của ESG, Lợi ích cho doanh nghiệp",
                authorName = "Dr. Nguyễn Văn A",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_carbon_footprint_guide",
                title = "Hướng dẫn tính toán Carbon Footprint cho doanh nghiệp",
                description = "Hướng dẫn chi tiết cách tính toán và quản lý dấu chân carbon của doanh nghiệp",
                content = "Carbon Footprint là tổng lượng khí nhà kính được tạo ra trực tiếp hoặc gián tiếp bởi hoạt động của doanh nghiệp...",
                type = LearningResourceType.ARTICLE,
                category = "Môi trường (Environmental)",
                subcategory = "Biến đổi khí hậu",
                level = LearningLevel.INTERMEDIATE,
                userRole = UserRole.ENTERPRISE,
                industry = "Sản xuất",
                duration = 25,
                difficulty = 3,
                rating = 4.7f,
                viewCount = 890,
                isFeatured = true,
                documentUrl = "https://example.com/docs/carbon_footprint_guide.pdf",
                tags = "carbon footprint, khí nhà kính, môi trường, tính toán",
                learningObjectives = "Hiểu cách tính carbon footprint, Áp dụng công thức tính toán, Xây dựng kế hoạch giảm phát thải",
                authorName = "PGS.TS Lê Thị B",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_esg_reporting_template",
                title = "Template báo cáo ESG theo tiêu chuẩn GRI",
                description = "Mẫu báo cáo ESG chuẩn quốc tế theo Global Reporting Initiative (GRI)",
                content = "Template báo cáo ESG theo tiêu chuẩn GRI bao gồm các phần chính: Tổng quan về doanh nghiệp, Chiến lược ESG, Quản lý rủi ro, Chỉ số hiệu suất...",
                type = LearningResourceType.TEMPLATE,
                category = "Báo cáo ESG",
                subcategory = "Template báo cáo",
                level = LearningLevel.ADVANCED,
                userRole = UserRole.ENTERPRISE,
                industry = "Tất cả",
                duration = 60,
                difficulty = 4,
                rating = 4.8f,
                viewCount = 650,
                isFeatured = true,
                documentUrl = "https://example.com/templates/gri_esg_report_template.xlsx",
                tags = "báo cáo ESG, GRI, template, tiêu chuẩn quốc tế",
                learningObjectives = "Hiểu cấu trúc báo cáo GRI, Sử dụng template hiệu quả, Tuân thủ tiêu chuẩn quốc tế",
                authorName = "ESG Consulting Team",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_social_impact_measurement",
                title = "Đo lường tác động xã hội của doanh nghiệp",
                description = "Hướng dẫn đo lường và đánh giá tác động xã hội của các hoạt động doanh nghiệp",
                content = "Đo lường tác động xã hội là quá trình đánh giá và định lượng các tác động tích cực và tiêu cực...",
                type = LearningResourceType.COURSE,
                category = "Xã hội (Social)",
                subcategory = "Tác động xã hội",
                level = LearningLevel.INTERMEDIATE,
                userRole = UserRole.ENTERPRISE,
                industry = "Dịch vụ",
                duration = 120,
                difficulty = 3,
                rating = 4.6f,
                viewCount = 420,
                isFeatured = false,
                videoUrl = "https://example.com/videos/social_impact_course.mp4",
                documentUrl = "https://example.com/docs/social_impact_guide.pdf",
                tags = "tác động xã hội, đo lường, đánh giá, CSR",
                learningObjectives = "Hiểu các chỉ số tác động xã hội, Xây dựng hệ thống đo lường, Báo cáo kết quả tác động",
                authorName = "ThS. Trần Văn C",
                language = "vi"
            ),
            
            // Resources for Student users
            LearningResourceEntity(
                id = "res_esg_student_intro",
                title = "ESG cho sinh viên: Bắt đầu từ đâu?",
                description = "Khóa học cơ bản về ESG dành riêng cho sinh viên và người mới bắt đầu",
                content = "ESG không chỉ là vấn đề của doanh nghiệp mà còn là trách nhiệm của mỗi cá nhân...",
                type = LearningResourceType.VIDEO,
                category = "Kiến thức cơ bản ESG",
                subcategory = "Giới thiệu ESG",
                level = LearningLevel.BEGINNER,
                userRole = UserRole.ACADEMIC,
                industry = "Tất cả",
                duration = 20,
                difficulty = 1,
                rating = 4.3f,
                viewCount = 2100,
                isFeatured = true,
                thumbnailUrl = "https://example.com/thumbnails/esg_student_intro.jpg",
                videoUrl = "https://example.com/videos/esg_student_intro.mp4",
                tags = "ESG, sinh viên, cơ bản, môi trường, xã hội",
                learningObjectives = "Hiểu ESG từ góc độ cá nhân, Tầm quan trọng của ESG với sinh viên, Cách áp dụng ESG trong cuộc sống",
                authorName = "TS. Phạm Thị D",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_sustainable_lifestyle",
                title = "Lối sống bền vững: Hành động nhỏ, tác động lớn",
                description = "Hướng dẫn thực hành lối sống bền vững trong cuộc sống hàng ngày",
                content = "Lối sống bền vững không phải là điều gì đó quá phức tạp hay tốn kém...",
                type = LearningResourceType.ARTICLE,
                category = "Môi trường (Environmental)",
                subcategory = "Lối sống bền vững",
                level = LearningLevel.BEGINNER,
                userRole = UserRole.ACADEMIC,
                industry = "Tất cả",
                duration = 10,
                difficulty = 1,
                rating = 4.4f,
                viewCount = 1800,
                isFeatured = true,
                documentUrl = "https://example.com/docs/sustainable_lifestyle.pdf",
                tags = "lối sống bền vững, môi trường, tiết kiệm, tái chế",
                learningObjectives = "Hiểu lối sống bền vững, Áp dụng các thực hành bền vững, Tạo thói quen tốt",
                authorName = "ThS. Nguyễn Văn E",
                language = "vi"
            ),
            
            // Resources for Regulatory users
            LearningResourceEntity(
                id = "res_esg_policy_vietnam",
                title = "Chính sách ESG tại Việt Nam: Cập nhật mới nhất",
                description = "Tổng hợp các chính sách, quy định ESG mới nhất tại Việt Nam",
                content = "Việt Nam đang tích cực thúc đẩy phát triển bền vững thông qua các chính sách ESG...",
                type = LearningResourceType.DOCUMENT,
                category = "Chính sách & Quy định",
                subcategory = "Chính sách Việt Nam",
                level = LearningLevel.ADVANCED,
                userRole = UserRole.REGULATORY,
                industry = "Tất cả",
                duration = 45,
                difficulty = 4,
                rating = 4.9f,
                viewCount = 320,
                isFeatured = true,
                documentUrl = "https://example.com/docs/esg_policy_vietnam_2024.pdf",
                tags = "chính sách ESG, Việt Nam, quy định, pháp luật",
                learningObjectives = "Nắm vững chính sách ESG Việt Nam, Hiểu các quy định mới, Hướng dẫn doanh nghiệp tuân thủ",
                authorName = "Bộ Tài nguyên và Môi trường",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_esg_audit_checklist",
                title = "Checklist kiểm tra ESG cho doanh nghiệp",
                description = "Danh sách kiểm tra toàn diện để đánh giá tình hình ESG của doanh nghiệp",
                content = "Checklist kiểm tra ESG bao gồm các tiêu chí đánh giá về môi trường, xã hội và quản trị doanh nghiệp...",
                type = LearningResourceType.CHECKLIST,
                category = "Công cụ tư vấn",
                subcategory = "Checklist kiểm tra",
                level = LearningLevel.EXPERT,
                userRole = UserRole.REGULATORY,
                industry = "Tất cả",
                duration = 30,
                difficulty = 5,
                rating = 4.7f,
                viewCount = 180,
                isFeatured = true,
                documentUrl = "https://example.com/tools/esg_audit_checklist.xlsx",
                tags = "checklist, kiểm tra ESG, đánh giá, audit",
                learningObjectives = "Sử dụng checklist hiệu quả, Đánh giá toàn diện ESG, Xác định điểm cần cải thiện",
                authorName = "ESG Audit Team",
                language = "vi"
            ),
            
            // More resources...
            LearningResourceEntity(
                id = "res_circular_economy",
                title = "Kinh tế tuần hoàn: Từ lý thuyết đến thực tiễn",
                description = "Khóa học về kinh tế tuần hoàn và cách áp dụng vào doanh nghiệp",
                content = "Kinh tế tuần hoàn là mô hình kinh tế tập trung vào việc tái sử dụng, tái chế và tái tạo tài nguyên...",
                type = LearningResourceType.COURSE,
                category = "Môi trường (Environmental)",
                subcategory = "Kinh tế tuần hoàn",
                level = LearningLevel.INTERMEDIATE,
                userRole = UserRole.ENTERPRISE,
                industry = "Sản xuất",
                duration = 90,
                difficulty = 3,
                rating = 4.5f,
                viewCount = 560,
                isFeatured = false,
                videoUrl = "https://example.com/videos/circular_economy_course.mp4",
                tags = "kinh tế tuần hoàn, tái chế, tái sử dụng, bền vững",
                learningObjectives = "Hiểu nguyên lý kinh tế tuần hoàn, Áp dụng vào mô hình kinh doanh, Tạo giá trị bền vững",
                authorName = "PGS.TS Võ Thị F",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_diversity_inclusion",
                title = "Đa dạng và hòa nhập trong doanh nghiệp",
                description = "Hướng dẫn xây dựng môi trường làm việc đa dạng và hòa nhập",
                content = "Đa dạng và hòa nhập (D&I) là yếu tố quan trọng trong quản trị doanh nghiệp hiện đại...",
                type = LearningResourceType.ARTICLE,
                category = "Xã hội (Social)",
                subcategory = "Đa dạng và hòa nhập",
                level = LearningLevel.INTERMEDIATE,
                userRole = UserRole.ENTERPRISE,
                industry = "Tất cả",
                duration = 20,
                difficulty = 2,
                rating = 4.6f,
                viewCount = 720,
                isFeatured = false,
                documentUrl = "https://example.com/docs/diversity_inclusion_guide.pdf",
                tags = "đa dạng, hòa nhập, quản trị, nhân sự",
                learningObjectives = "Hiểu tầm quan trọng của D&I, Xây dựng chính sách D&I, Tạo môi trường hòa nhập",
                authorName = "ThS. Lê Văn G",
                language = "vi"
            ),
            
            // Expert Resources
            LearningResourceEntity(
                id = "res_expert_esg_consulting",
                title = "Tư vấn ESG chuyên sâu cho doanh nghiệp",
                description = "Khóa học nâng cao về tư vấn và triển khai ESG trong doanh nghiệp",
                content = "Khóa học này dành cho các chuyên gia ESG muốn nâng cao kỹ năng tư vấn...",
                type = LearningResourceType.COURSE,
                category = "Tư vấn ESG",
                subcategory = "Chuyên sâu",
                level = LearningLevel.EXPERT,
                userRole = UserRole.EXPERT,
                industry = "Tất cả",
                duration = 120,
                difficulty = 5,
                rating = 4.9f,
                viewCount = 150,
                isFeatured = true,
                documentUrl = "https://example.com/courses/expert_esg_consulting.pdf",
                tags = "tư vấn, chuyên sâu, doanh nghiệp, ESG",
                learningObjectives = "Nắm vững phương pháp tư vấn ESG, Xây dựng chiến lược ESG, Đánh giá rủi ro ESG",
                authorName = "TS. Nguyễn Văn Chuyên gia",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_expert_esg_reporting",
                title = "Báo cáo ESG theo chuẩn quốc tế",
                description = "Hướng dẫn chi tiết về báo cáo ESG theo các chuẩn GRI, SASB, TCFD",
                content = "Báo cáo ESG là công cụ quan trọng để minh bạch hóa hoạt động bền vững...",
                type = LearningResourceType.GUIDE,
                category = "Báo cáo ESG",
                subcategory = "Chuẩn quốc tế",
                level = LearningLevel.EXPERT,
                userRole = UserRole.EXPERT,
                industry = "Tất cả",
                duration = 90,
                difficulty = 4,
                rating = 4.8f,
                viewCount = 200,
                isFeatured = true,
                documentUrl = "https://example.com/guides/expert_esg_reporting.pdf",
                tags = "báo cáo, GRI, SASB, TCFD, minh bạch",
                learningObjectives = "Hiểu các chuẩn báo cáo ESG, Xây dựng báo cáo ESG, Đánh giá chất lượng báo cáo",
                authorName = "ThS. Trần Thị Tư vấn",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_expert_esg_risk_assessment",
                title = "Đánh giá rủi ro ESG nâng cao",
                description = "Phương pháp đánh giá và quản lý rủi ro ESG trong doanh nghiệp",
                content = "Đánh giá rủi ro ESG là bước quan trọng trong quản trị doanh nghiệp bền vững...",
                type = LearningResourceType.WORKSHOP,
                category = "Quản lý rủi ro",
                subcategory = "ESG Risk",
                level = LearningLevel.EXPERT,
                userRole = UserRole.EXPERT,
                industry = "Tất cả",
                duration = 60,
                difficulty = 5,
                rating = 4.7f,
                viewCount = 180,
                isFeatured = false,
                documentUrl = "https://example.com/workshops/expert_esg_risk.pdf",
                tags = "rủi ro, đánh giá, quản lý, ESG",
                learningObjectives = "Xác định rủi ro ESG, Đo lường tác động rủi ro, Xây dựng kế hoạch giảm thiểu",
                authorName = "TS. Nguyễn Văn Chuyên gia",
                language = "vi"
            ),
            
            LearningResourceEntity(
                id = "res_expert_esg_investment",
                title = "Đầu tư ESG và tác động tài chính",
                description = "Phân tích tác động của ESG lên hiệu quả đầu tư và giá trị doanh nghiệp",
                content = "Đầu tư ESG đang trở thành xu hướng chủ đạo trong thị trường tài chính...",
                type = LearningResourceType.RESEARCH,
                category = "Đầu tư ESG",
                subcategory = "Tài chính",
                level = LearningLevel.EXPERT,
                userRole = UserRole.EXPERT,
                industry = "Tài chính",
                duration = 45,
                difficulty = 4,
                rating = 4.6f,
                viewCount = 120,
                isFeatured = false,
                documentUrl = "https://example.com/research/expert_esg_investment.pdf",
                tags = "đầu tư, tài chính, ESG, ROI",
                learningObjectives = "Hiểu tác động ESG lên đầu tư, Phân tích hiệu quả tài chính, Xây dựng danh mục ESG",
                authorName = "ThS. Trần Thị Tư vấn",
                language = "vi"
            )
        )
    }
    
    fun getLearningQuizzes(): List<LearningQuizEntity> {
        return listOf(
            LearningQuizEntity(
                id = "quiz_esg_intro_1",
                resourceId = "res_esg_intro_video",
                question = "ESG là viết tắt của gì?",
                questionType = QuizQuestionType.MULTIPLE_CHOICE,
                options = "[\"Environmental, Social, Governance\", \"Economic, Social, Government\", \"Energy, Society, Growth\", \"Enterprise, Strategy, Goals\"]",
                correctAnswer = "Environmental, Social, Governance",
                explanation = "ESG là viết tắt của Environmental (Môi trường), Social (Xã hội), và Governance (Quản trị).",
                points = 1,
                order = 1,
                difficulty = 1
            ),
            
            LearningQuizEntity(
                id = "quiz_esg_intro_2",
                resourceId = "res_esg_intro_video",
                question = "Tại sao ESG quan trọng đối với doanh nghiệp?",
                questionType = QuizQuestionType.MULTIPLE_CHOICE,
                options = "[\"Giảm rủi ro tài chính\", \"Tăng uy tín thương hiệu\", \"Thu hút nhà đầu tư\", \"Tất cả các đáp án trên\"]",
                correctAnswer = "Tất cả các đáp án trên",
                explanation = "ESG giúp doanh nghiệp giảm rủi ro, tăng uy tín và thu hút nhà đầu tư.",
                points = 1,
                order = 2,
                difficulty = 2
            ),
            
            LearningQuizEntity(
                id = "quiz_carbon_footprint_1",
                resourceId = "res_carbon_footprint_guide",
                question = "Carbon Footprint được đo bằng đơn vị nào?",
                questionType = QuizQuestionType.MULTIPLE_CHOICE,
                options = "[\"CO2e (Carbon Dioxide Equivalent)\", \"kg CO2\", \"Tấn CO2\", \"Tất cả các đáp án trên\"]",
                correctAnswer = "Tất cả các đáp án trên",
                explanation = "Carbon Footprint có thể được đo bằng nhiều đơn vị khác nhau, nhưng CO2e là đơn vị chuẩn quốc tế.",
                points = 1,
                order = 1,
                difficulty = 2
            )
        )
    }
}
