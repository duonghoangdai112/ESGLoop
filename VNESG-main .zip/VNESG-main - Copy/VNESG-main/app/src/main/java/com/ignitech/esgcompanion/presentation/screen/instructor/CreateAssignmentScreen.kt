package com.ignitech.esgcompanion.presentation.screen.instructor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.hilt.navigation.compose.hiltViewModel
import com.ignitech.esgcompanion.presentation.viewmodel.CreateAssignmentViewModel
import com.ignitech.esgcompanion.ui.theme.*
import com.ignitech.esgcompanion.utils.AppColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAssignmentScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: CreateAssignmentViewModel = hiltViewModel()
) {
    var assignmentTitle by remember { mutableStateOf("") }
    var assignmentDescription by remember { mutableStateOf("") }
    var selectedClass by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("") }
    var selectedDifficulty by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("") }
    var maxScore by remember { mutableStateOf("") }
    var assignmentInstructions by remember { mutableStateOf("") }
    var showClassDropdown by remember { mutableStateOf(false) }
    val colors = AppColors()
    var showTypeDropdown by remember { mutableStateOf(false) }
    var showDifficultyDropdown by remember { mutableStateOf(false) }

    val classes = listOf("ESG-101", "ESG-102", "ESG-201")
    val types = listOf("Bài tập cá nhân", "Bài tập nhóm", "Dự án", "Báo cáo", "Thuyết trình")
    val difficulties = listOf("Dễ", "Trung bình", "Khó", "Rất khó")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                }
                Text(
                    text = "Tạo bài tập mới",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Basic Information
        item {
            Text(
                text = "Thông tin cơ bản",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            OutlinedTextField(
                value = assignmentTitle,
                onValueChange = { assignmentTitle = it },
                label = { Text("Tiêu đề bài tập") },
                placeholder = { 
                    Text(
                        "Nhập tiêu đề bài tập",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Assignment, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = assignmentDescription,
                onValueChange = { assignmentDescription = it },
                label = { Text("Mô tả bài tập") },
                placeholder = { 
                    Text(
                        "Mô tả ngắn gọn về yêu cầu bài tập",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                leadingIcon = { Icon(Icons.Default.Description, contentDescription = null) }
            )
        }

        // Class and Settings
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Class Selection
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = selectedClass,
                        onValueChange = { selectedClass = it },
                        label = { Text("Lớp học") },
                        placeholder = { 
                            Text(
                                "Chọn lớp",
                                color = colors.textSecondary.copy(alpha = 0.6f)
                            ) 
                        },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { showClassDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    DropdownMenu(
                        expanded = showClassDropdown,
                        onDismissRequest = { showClassDropdown = false }
                    ) {
                        classes.forEach { className ->
                            DropdownMenuItem(
                                text = { Text(className) },
                                onClick = {
                                    selectedClass = className
                                    showClassDropdown = false
                                }
                            )
                        }
                    }
                }

                // Type Selection
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = selectedType,
                        onValueChange = { selectedType = it },
                        label = { Text("Loại bài tập") },
                        placeholder = { 
                            Text(
                                "Chọn loại",
                                color = colors.textSecondary.copy(alpha = 0.6f)
                            ) 
                        },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { showTypeDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    DropdownMenu(
                        expanded = showTypeDropdown,
                        onDismissRequest = { showTypeDropdown = false }
                    ) {
                        types.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type) },
                                onClick = {
                                    selectedType = type
                                    showTypeDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Difficulty Selection
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = selectedDifficulty,
                        onValueChange = { selectedDifficulty = it },
                        label = { Text("Độ khó") },
                        placeholder = { 
                            Text(
                                "Chọn độ khó",
                                color = colors.textSecondary.copy(alpha = 0.6f)
                            ) 
                        },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { showDifficultyDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    DropdownMenu(
                        expanded = showDifficultyDropdown,
                        onDismissRequest = { showDifficultyDropdown = false }
                    ) {
                        difficulties.forEach { difficulty ->
                            DropdownMenuItem(
                                text = { Text(difficulty) },
                                onClick = {
                                    selectedDifficulty = difficulty
                                    showDifficultyDropdown = false
                                }
                            )
                        }
                    }
                }

                // Max Score
                OutlinedTextField(
                    value = maxScore,
                    onValueChange = { maxScore = it },
                    label = { Text("Điểm tối đa") },
                    placeholder = { 
                    Text(
                        "100",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                    modifier = Modifier.weight(1f),
                    leadingIcon = { Icon(Icons.Default.Grade, contentDescription = null) }
                )
            }
        }

        // Due Date
        item {
            OutlinedTextField(
                value = dueDate,
                onValueChange = { dueDate = it },
                label = { Text("Hạn nộp") },
                placeholder = { 
                    Text(
                        "DD/MM/YYYY",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null) },
                trailingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) }
            )
        }

        // Assignment Instructions
        item {
            Text(
                text = "Hướng dẫn chi tiết",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            OutlinedTextField(
                value = assignmentInstructions,
                onValueChange = { assignmentInstructions = it },
                label = { Text("Hướng dẫn làm bài") },
                placeholder = { 
                    Text(
                        "Nhập hướng dẫn chi tiết cho học sinh...",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                minLines = 5
            )
        }

        // Assignment Requirements
        item {
            Text(
                text = "Yêu cầu bài tập",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            AssignmentRequirementsSection()
        }

        // File Upload
        item {
            Text(
                text = "Tài liệu đính kèm",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Đính kèm tài liệu tham khảo",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "PDF, DOC, PPT, XLS, ZIP",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { /* Handle file upload */ },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("Chọn file")
                    }
                }
            }
        }

        // Assignment Templates
        item {
            Text(
                text = "Mẫu bài tập",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(getAssignmentTemplates()) { template ->
            AssignmentTemplateCard(
                template = template,
                onClick = { /* Apply template */ }
            )
        }

        // Action Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Hủy")
                }
                Button(
                    onClick = { /* Save assignment */ },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800),
                        contentColor = Color.White
                    )
                ) {
                    Text("Tạo bài tập")
                }
            }
        }
    }
}

@Composable
fun AssignmentRequirementsSection() {
    var wordCount by remember { mutableStateOf(false) }
    var fileFormat by remember { mutableStateOf(false) }
    var citation by remember { mutableStateOf(false) }
    var plagiarism by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .selectableGroup()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .selectable(
                    selected = wordCount,
                    onClick = { wordCount = !wordCount }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = wordCount,
                onCheckedChange = { wordCount = it }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Yêu cầu số từ tối thiểu")
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .selectable(
                    selected = fileFormat,
                    onClick = { fileFormat = !fileFormat }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = fileFormat,
                onCheckedChange = { fileFormat = it }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Yêu cầu định dạng file cụ thể")
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .selectable(
                    selected = citation,
                    onClick = { citation = !citation }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = citation,
                onCheckedChange = { citation = it }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Yêu cầu trích dẫn nguồn")
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .selectable(
                    selected = plagiarism,
                    onClick = { plagiarism = !plagiarism }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = plagiarism,
                onCheckedChange = { plagiarism = it }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Kiểm tra đạo văn")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignmentTemplateCard(
    template: AssignmentTemplate,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = template.icon,
                contentDescription = null,
                tint = template.color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = template.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = template.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = template.difficulty,
                    style = MaterialTheme.typography.bodySmall,
                    color = template.color
                )
                Text(
                    text = template.duration,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// Data classes
data class AssignmentTemplate(
    val name: String,
    val description: String,
    val difficulty: String,
    val duration: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

// Mock data
private fun getAssignmentTemplates(): List<AssignmentTemplate> {
    return listOf(
        AssignmentTemplate(
            name = "Mẫu báo cáo ESG",
            description = "Template cho báo cáo phân tích ESG",
            difficulty = "Trung bình",
            duration = "2 tuần",
            icon = Icons.Default.Assignment,
            color = ESGInfo
        ),
        AssignmentTemplate(
            name = "Mẫu dự án nhóm",
            description = "Template cho dự án nhóm về bền vững",
            difficulty = "Khó",
            duration = "1 tháng",
            icon = Icons.Default.Group,
            color = ESGWarning
        ),
        AssignmentTemplate(
            name = "Mẫu thuyết trình",
            description = "Template cho bài thuyết trình",
            difficulty = "Trung bình",
            duration = "1 tuần",
            icon = Icons.Default.PresentToAll,
            color = ESGSuccess
        )
    )
}