package com.ignitech.esgcompanion.data.seed

import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.data.local.entity.ESGQuestionEntity
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.domain.entity.UserRole

object ESGQuestionSeeder {
    
    fun getStandardQuestions(): List<ESGQuestionEntity> {
        return listOf(
            // ENVIRONMENTAL PILLAR
            // Climate Change & Energy
            ESGQuestionEntity(
                id = "env_climate_001",
                pillar = ESGPillar.ENVIRONMENTAL,
                category = "Climate Change & Energy",
                question = "Doanh nghiệp có đánh giá và báo cáo lượng khí thải carbon không?",
                description = "Đánh giá việc đo lường, báo cáo và quản lý lượng khí thải nhà kính (GHG) của doanh nghiệp",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Có hệ thống đo lường và báo cáo đầy đủ"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang xây dựng hệ thống đo lường"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa có hệ thống đo lường"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 5,
                isRequired = true,
                userRole = UserRole.ENTERPRISE,
                order = 1
            ),
            ESGQuestionEntity(
                id = "env_climate_002",
                pillar = ESGPillar.ENVIRONMENTAL,
                category = "Climate Change & Energy",
                question = "Doanh nghiệp có kế hoạch giảm phát thải carbon không?",
                description = "Đánh giá việc xây dựng và thực hiện kế hoạch giảm phát thải carbon",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Có kế hoạch chi tiết và đang thực hiện"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang xây dựng kế hoạch"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa có kế hoạch cụ thể"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 4,
                isRequired = true,
                userRole = UserRole.ENTERPRISE,
                order = 2
            ),
            
            // Waste Management
            ESGQuestionEntity(
                id = "env_waste_001",
                pillar = ESGPillar.ENVIRONMENTAL,
                category = "Waste Management",
                question = "Doanh nghiệp có hệ thống quản lý chất thải không?",
                description = "Đánh giá việc phân loại, xử lý và tái chế chất thải",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Có hệ thống quản lý chất thải hoàn chỉnh"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang xây dựng hệ thống"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa có hệ thống quản lý"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 3,
                isRequired = true,
                userRole = UserRole.ENTERPRISE,
                order = 1
            ),
            
            // SOCIAL PILLAR
            // Labor Rights
            ESGQuestionEntity(
                id = "soc_labor_001",
                pillar = ESGPillar.SOCIAL,
                category = "Labor Rights",
                question = "Doanh nghiệp có tuân thủ quyền lao động không?",
                description = "Đánh giá việc tuân thủ các quyền lao động cơ bản",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Tuân thủ đầy đủ các quyền lao động"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang cải thiện việc tuân thủ"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa tuân thủ đầy đủ"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 4,
                isRequired = true,
                userRole = UserRole.ENTERPRISE,
                order = 1
            ),
            
            // Community Engagement
            ESGQuestionEntity(
                id = "soc_community_001",
                pillar = ESGPillar.SOCIAL,
                category = "Community Engagement",
                question = "Doanh nghiệp có tham gia hoạt động cộng đồng không?",
                description = "Đánh giá việc tham gia và đóng góp cho cộng đồng",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Tham gia tích cực các hoạt động cộng đồng"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang mở rộng hoạt động cộng đồng"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa tham gia nhiều hoạt động"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 3,
                isRequired = false,
                userRole = UserRole.ENTERPRISE,
                order = 1
            ),
            
            // GOVERNANCE PILLAR
            // Ethics & Compliance
            ESGQuestionEntity(
                id = "gov_ethics_001",
                pillar = ESGPillar.GOVERNANCE,
                category = "Ethics & Compliance",
                question = "Doanh nghiệp có bộ quy tắc đạo đức không?",
                description = "Đánh giá việc xây dựng và thực hiện bộ quy tắc đạo đức",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Có bộ quy tắc đạo đức hoàn chỉnh"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang xây dựng bộ quy tắc"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa có bộ quy tắc đạo đức"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 4,
                isRequired = true,
                userRole = UserRole.ENTERPRISE,
                order = 1
            ),
            
            // Transparency
            ESGQuestionEntity(
                id = "gov_transparency_001",
                pillar = ESGPillar.GOVERNANCE,
                category = "Transparency",
                question = "Doanh nghiệp có minh bạch trong báo cáo không?",
                description = "Đánh giá tính minh bạch trong báo cáo tài chính và hoạt động",
                optionsJson = """[
                    {"id": "opt1", "text": "Có đầy đủ", "score": 4, "description": "Báo cáo rất minh bạch và chi tiết"},
                    {"id": "opt2", "text": "Đang triển khai", "score": 3, "description": "Đang cải thiện tính minh bạch"},
                    {"id": "opt3", "text": "Chưa có", "score": 2, "description": "Chưa minh bạch đầy đủ"},
                    {"id": "opt4", "text": "Không áp dụng", "score": 1, "description": "Không áp dụng cho doanh nghiệp"}
                ]""",
                weight = 3,
                isRequired = true,
                userRole = UserRole.ENTERPRISE,
                order = 1
            )
        )
    }
    
    fun getStandardCategories(): List<ESGCategoryEntity> {
        return listOf(
            // Environmental Categories
            ESGCategoryEntity(
                id = "env_climate",
                name = "Climate Change & Energy",
                description = "Quản lý khí thải carbon và năng lượng tái tạo",
                pillar = ESGPillar.ENVIRONMENTAL,
                order = 1
            ),
            ESGCategoryEntity(
                id = "env_waste",
                name = "Waste Management",
                description = "Quản lý chất thải và tái chế",
                pillar = ESGPillar.ENVIRONMENTAL,
                order = 2
            ),
            ESGCategoryEntity(
                id = "env_water",
                name = "Water Management",
                description = "Quản lý nước và bảo vệ nguồn nước",
                pillar = ESGPillar.ENVIRONMENTAL,
                order = 3
            ),
            ESGCategoryEntity(
                id = "env_biodiversity",
                name = "Biodiversity",
                description = "Bảo vệ đa dạng sinh học",
                pillar = ESGPillar.ENVIRONMENTAL,
                order = 4
            ),
            
            // Social Categories
            ESGCategoryEntity(
                id = "soc_labor",
                name = "Labor Rights",
                description = "Quyền lao động và điều kiện làm việc",
                pillar = ESGPillar.SOCIAL,
                order = 1
            ),
            ESGCategoryEntity(
                id = "soc_community",
                name = "Community Engagement",
                description = "Tham gia cộng đồng và trách nhiệm xã hội",
                pillar = ESGPillar.SOCIAL,
                order = 2
            ),
            ESGCategoryEntity(
                id = "soc_diversity",
                name = "Diversity & Inclusion",
                description = "Đa dạng và hòa nhập",
                pillar = ESGPillar.SOCIAL,
                order = 3
            ),
            ESGCategoryEntity(
                id = "soc_human_rights",
                name = "Human Rights",
                description = "Quyền con người",
                pillar = ESGPillar.SOCIAL,
                order = 4
            ),
            
            // Governance Categories
            ESGCategoryEntity(
                id = "gov_ethics",
                name = "Ethics & Compliance",
                description = "Đạo đức và tuân thủ",
                pillar = ESGPillar.GOVERNANCE,
                order = 1
            ),
            ESGCategoryEntity(
                id = "gov_transparency",
                name = "Transparency",
                description = "Minh bạch và báo cáo",
                pillar = ESGPillar.GOVERNANCE,
                order = 2
            ),
            ESGCategoryEntity(
                id = "gov_risk",
                name = "Risk Management",
                description = "Quản lý rủi ro",
                pillar = ESGPillar.GOVERNANCE,
                order = 3
            ),
            ESGCategoryEntity(
                id = "gov_stakeholder",
                name = "Stakeholder Engagement",
                description = "Tương tác với các bên liên quan",
                pillar = ESGPillar.GOVERNANCE,
                order = 4
            )
        )
    }
}