package com.ignitech.esgcompanion.data.seed

import com.ignitech.esgcompanion.data.local.entity.ESGAssessmentEntity
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.domain.entity.AssessmentStatus

object AssessmentHistorySeeder {
    
    fun getHistoricalAssessments(userId: String): List<ESGAssessmentEntity> {
        val currentTime = System.currentTimeMillis()
        val oneDay = 24 * 60 * 60 * 1000L
        val oneMonth = 30 * oneDay
        val oneQuarter = 3 * oneMonth
        
        return listOf(
            // Q4 2023 - Environmental
            ESGAssessmentEntity(
                id = "env_q4_2023",
                userId = userId,
                title = "Đánh giá Môi trường Q4 2023",
                description = "Đánh giá tác động môi trường quý 4 năm 2023",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 78,
                maxScore = 100,
                completedAt = currentTime - oneQuarter * 3,
                createdAt = currentTime - oneQuarter * 3 - oneMonth,
                assessmentPeriod = "Q4-2023",
                assessmentYear = 2023,
                assessmentQuarter = 4,
                isHistorical = true
            ),
            
            // Q4 2023 - Social
            ESGAssessmentEntity(
                id = "social_q4_2023",
                userId = userId,
                title = "Đánh giá Xã hội Q4 2023",
                description = "Đánh giá tác động xã hội quý 4 năm 2023",
                pillar = ESGPillar.SOCIAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 82,
                maxScore = 100,
                completedAt = currentTime - oneQuarter * 3 + oneDay * 5,
                createdAt = currentTime - oneQuarter * 3 - oneMonth + oneDay * 5,
                assessmentPeriod = "Q4-2023",
                assessmentYear = 2023,
                assessmentQuarter = 4,
                isHistorical = true
            ),
            
            // Q4 2023 - Governance
            ESGAssessmentEntity(
                id = "gov_q4_2023",
                userId = userId,
                title = "Đánh giá Quản trị Q4 2023",
                description = "Đánh giá quản trị doanh nghiệp quý 4 năm 2023",
                pillar = ESGPillar.GOVERNANCE,
                status = AssessmentStatus.COMPLETED,
                totalScore = 85,
                maxScore = 100,
                completedAt = currentTime - oneQuarter * 3 + oneDay * 10,
                createdAt = currentTime - oneQuarter * 3 - oneMonth + oneDay * 10,
                assessmentPeriod = "Q4-2023",
                assessmentYear = 2023,
                assessmentQuarter = 4,
                isHistorical = true
            ),
            
            // Q1 2024 - Environmental
            ESGAssessmentEntity(
                id = "env_q1_2024",
                userId = userId,
                title = "Đánh giá Môi trường Q1 2024",
                description = "Đánh giá tác động môi trường quý 1 năm 2024",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 85,
                maxScore = 100,
                completedAt = currentTime - oneQuarter * 2,
                createdAt = currentTime - oneQuarter * 2 - oneMonth,
                assessmentPeriod = "Q1-2024",
                assessmentYear = 2024,
                assessmentQuarter = 1,
                isHistorical = true
            ),
            
            // Q1 2024 - Social
            ESGAssessmentEntity(
                id = "social_q1_2024",
                userId = userId,
                title = "Đánh giá Xã hội Q1 2024",
                description = "Đánh giá tác động xã hội quý 1 năm 2024",
                pillar = ESGPillar.SOCIAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 88,
                maxScore = 100,
                completedAt = currentTime - oneQuarter * 2 + oneDay * 7,
                createdAt = currentTime - oneQuarter * 2 - oneMonth + oneDay * 7,
                assessmentPeriod = "Q1-2024",
                assessmentYear = 2024,
                assessmentQuarter = 1,
                isHistorical = true
            ),
            
            // Q1 2024 - Governance
            ESGAssessmentEntity(
                id = "gov_q1_2024",
                userId = userId,
                title = "Đánh giá Quản trị Q1 2024",
                description = "Đánh giá quản trị doanh nghiệp quý 1 năm 2024",
                pillar = ESGPillar.GOVERNANCE,
                status = AssessmentStatus.COMPLETED,
                totalScore = 90,
                maxScore = 100,
                completedAt = currentTime - oneQuarter * 2 + oneDay * 12,
                createdAt = currentTime - oneQuarter * 2 - oneMonth + oneDay * 12,
                assessmentPeriod = "Q1-2024",
                assessmentYear = 2024,
                assessmentQuarter = 1,
                isHistorical = true
            ),
            
            // Q2 2024 - Environmental
            ESGAssessmentEntity(
                id = "env_q2_2024",
                userId = userId,
                title = "Đánh giá Môi trường Q2 2024",
                description = "Đánh giá tác động môi trường quý 2 năm 2024",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 92,
                maxScore = 100,
                completedAt = currentTime - oneQuarter,
                createdAt = currentTime - oneQuarter - oneMonth,
                assessmentPeriod = "Q2-2024",
                assessmentYear = 2024,
                assessmentQuarter = 2,
                isHistorical = true
            ),
            
            // Q2 2024 - Social
            ESGAssessmentEntity(
                id = "social_q2_2024",
                userId = userId,
                title = "Đánh giá Xã hội Q2 2024",
                description = "Đánh giá tác động xã hội quý 2 năm 2024",
                pillar = ESGPillar.SOCIAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 85,
                maxScore = 100,
                completedAt = currentTime - oneQuarter + oneDay * 8,
                createdAt = currentTime - oneQuarter - oneMonth + oneDay * 8,
                assessmentPeriod = "Q2-2024",
                assessmentYear = 2024,
                assessmentQuarter = 2,
                isHistorical = true
            ),
            
            // Q2 2024 - Governance
            ESGAssessmentEntity(
                id = "gov_q2_2024",
                userId = userId,
                title = "Đánh giá Quản trị Q2 2024",
                description = "Đánh giá quản trị doanh nghiệp quý 2 năm 2024",
                pillar = ESGPillar.GOVERNANCE,
                status = AssessmentStatus.COMPLETED,
                totalScore = 87,
                maxScore = 100,
                completedAt = currentTime - oneQuarter + oneDay * 15,
                createdAt = currentTime - oneQuarter - oneMonth + oneDay * 15,
                assessmentPeriod = "Q2-2024",
                assessmentYear = 2024,
                assessmentQuarter = 2,
                isHistorical = true
            ),
            
            // Q3 2024 - Environmental
            ESGAssessmentEntity(
                id = "env_q3_2024",
                userId = userId,
                title = "Đánh giá Môi trường Q3 2024",
                description = "Đánh giá tác động môi trường quý 3 năm 2024",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 88,
                maxScore = 100,
                completedAt = currentTime - oneDay * 15,
                createdAt = currentTime - oneMonth - oneDay * 15,
                assessmentPeriod = "Q3-2024",
                assessmentYear = 2024,
                assessmentQuarter = 3,
                isHistorical = true
            ),
            
            // Q3 2024 - Social
            ESGAssessmentEntity(
                id = "social_q3_2024",
                userId = userId,
                title = "Đánh giá Xã hội Q3 2024",
                description = "Đánh giá tác động xã hội quý 3 năm 2024",
                pillar = ESGPillar.SOCIAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 91,
                maxScore = 100,
                completedAt = currentTime - oneDay * 10,
                createdAt = currentTime - oneMonth - oneDay * 10,
                assessmentPeriod = "Q3-2024",
                assessmentYear = 2024,
                assessmentQuarter = 3,
                isHistorical = true
            ),
            
            // Q3 2024 - Governance
            ESGAssessmentEntity(
                id = "gov_q3_2024",
                userId = userId,
                title = "Đánh giá Quản trị Q3 2024",
                description = "Đánh giá quản trị doanh nghiệp quý 3 năm 2024",
                pillar = ESGPillar.GOVERNANCE,
                status = AssessmentStatus.COMPLETED,
                totalScore = 89,
                maxScore = 100,
                completedAt = currentTime - oneDay * 5,
                createdAt = currentTime - oneMonth - oneDay * 5,
                assessmentPeriod = "Q3-2024",
                assessmentYear = 2024,
                assessmentQuarter = 3,
                isHistorical = true
            )
        )
    }
    
    fun getCurrentQuarterAssessments(userId: String): List<ESGAssessmentEntity> {
        val currentTime = System.currentTimeMillis()
        val oneDay = 24 * 60 * 60 * 1000L
        val oneMonth = 30 * oneDay
        
        return listOf(
            // Q4 2024 - Environmental (Current)
            ESGAssessmentEntity(
                id = "env_q4_2024",
                userId = userId,
                title = "Đánh giá Môi trường Q4 2024",
                description = "Đánh giá tác động môi trường quý 4 năm 2024",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.IN_PROGRESS,
                totalScore = 0,
                maxScore = 100,
                completedAt = null,
                createdAt = currentTime - oneDay * 7,
                assessmentPeriod = "Q4-2024",
                assessmentYear = 2024,
                assessmentQuarter = 4,
                isHistorical = false
            ),
            
            // Q4 2024 - Social (Current)
            ESGAssessmentEntity(
                id = "social_q4_2024",
                userId = userId,
                title = "Đánh giá Xã hội Q4 2024",
                description = "Đánh giá tác động xã hội quý 4 năm 2024",
                pillar = ESGPillar.SOCIAL,
                status = AssessmentStatus.NOT_STARTED,
                totalScore = 0,
                maxScore = 100,
                completedAt = null,
                createdAt = currentTime - oneDay * 5,
                assessmentPeriod = "Q4-2024",
                assessmentYear = 2024,
                assessmentQuarter = 4,
                isHistorical = false
            ),
            
            // Q4 2024 - Governance (Current)
            ESGAssessmentEntity(
                id = "gov_q4_2024",
                userId = userId,
                title = "Đánh giá Quản trị Q4 2024",
                description = "Đánh giá quản trị doanh nghiệp quý 4 năm 2024",
                pillar = ESGPillar.GOVERNANCE,
                status = AssessmentStatus.NOT_STARTED,
                totalScore = 0,
                maxScore = 100,
                completedAt = null,
                createdAt = currentTime - oneDay * 3,
                assessmentPeriod = "Q4-2024",
                assessmentYear = 2024,
                assessmentQuarter = 4,
                isHistorical = false
            )
        )
    }
    
    fun getAllAssessmentsForUser(userId: String): List<ESGAssessmentEntity> {
        return getHistoricalAssessments(userId) + getCurrentQuarterAssessments(userId)
    }
}
