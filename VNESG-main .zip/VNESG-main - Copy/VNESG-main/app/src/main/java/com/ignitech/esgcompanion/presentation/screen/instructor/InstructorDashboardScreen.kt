package com.ignitech.esgcompanion.presentation.screen.instructor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.domain.entity.ESGPillarInfo
import com.ignitech.esgcompanion.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorDashboardScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize()
    ) {
        // Header
        TopAppBar(
            title = { 
                Column {
                    Text(
                        text = "ESG Companion",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Giảng viên",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            actions = {
                IconButton(onClick = { navController.navigate("settings") }) {
                    Icon(Icons.Default.Person, contentDescription = "Profile")
                }
            }
        )
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Class Overview
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "📚 Tổng quan lớp học",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ClassStatCard(
                                title = "Tổng học sinh",
                                value = "45",
                                icon = Icons.Default.People,
                                color = ESGInfo,
                                modifier = Modifier.weight(1f)
                            )
                            ClassStatCard(
                                title = "Bài tập chưa chấm",
                                value = "12",
                                icon = Icons.Default.Assignment,
                                color = ESGWarning,
                                modifier = Modifier.weight(1f)
                            )
                            ClassStatCard(
                                title = "Điểm trung bình",
                                value = "85%",
                                icon = Icons.Default.Grade,
                                color = ESGSuccess,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
            
            // Recent Activities
            item {
                Text(
                    text = "Hoạt động gần đây",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            items(getRecentActivities()) { activity ->
                ActivityCard(activity = activity)
            }
            
            // Quick Actions
            item {
                Text(
                    text = "Thao tác nhanh",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InstructorQuickActionCard(
                        title = "Tạo bài tập",
                        icon = Icons.Default.Create,
                        onClick = { /* Create assignment */ },
                        modifier = Modifier.weight(1f)
                    )
                    InstructorQuickActionCard(
                        title = "Chấm bài",
                        icon = Icons.Default.Grade,
                        onClick = { /* Grade assignments */ },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            // Student Performance by ESG Pillar
            item {
                Text(
                    text = "Thành tích theo lĩnh vực ESG",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(ESGPillarInfo.ALL_PILLARS) { pillarInfo ->
                        ESGPillarCard(
                            pillarInfo = pillarInfo,
                            averageScore = when (pillarInfo.pillar) {
                                ESGPillar.ENVIRONMENTAL -> 88
                                ESGPillar.SOCIAL -> 82
                                ESGPillar.GOVERNANCE -> 85
                            }
                        )
                    }
                }
            }
            
            // Upcoming Deadlines
            item {
                Text(
                    text = "Hạn nộp sắp tới",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            items(getUpcomingDeadlines()) { deadline ->
                DeadlineCard(deadline = deadline)
            }
        }
    }
}

@Composable
fun ClassStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ActivityCard(
    activity: Activity
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = activity.icon,
                contentDescription = null,
                tint = activity.color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = activity.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = activity.time,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ESGPillarCard(
    pillarInfo: ESGPillarInfo,
    averageScore: Int
) {
    Card(
        modifier = Modifier.width(140.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = pillarInfo.icon,
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = pillarInfo.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Điểm TB: $averageScore%",
                style = MaterialTheme.typography.bodySmall,
                color = when {
                    averageScore >= 85 -> ESGSuccess
                    averageScore >= 70 -> ESGWarning
                    else -> Color(0xFFFF5722)
                },
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun DeadlineCard(
    deadline: Deadline
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (deadline.isUrgent) Color(0xFFFF5722).copy(alpha = 0.1f) 
                            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = null,
                tint = if (deadline.isUrgent) Color(0xFFFF5722) else MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = deadline.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = deadline.className,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = deadline.dueDate,
                style = MaterialTheme.typography.bodySmall,
                color = if (deadline.isUrgent) Color(0xFFFF5722) else MaterialTheme.colorScheme.primary
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorQuickActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// Data classes
data class Activity(
    val title: String,
    val description: String,
    val time: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

data class Deadline(
    val title: String,
    val className: String,
    val dueDate: String,
    val isUrgent: Boolean
)

// Mock data functions
private fun getRecentActivities(): List<Activity> {
    return listOf(
        Activity(
            title = "Học sinh Nguyễn Văn A nộp bài tập",
            description = "Bài tập: Phân tích báo cáo ESG",
            time = "2 giờ trước",
            icon = Icons.Default.Assignment,
            color = ESGInfo
        ),
        Activity(
            title = "Lớp ESG-101 hoàn thành bài kiểm tra",
            description = "Điểm trung bình: 85%",
            time = "4 giờ trước",
            icon = Icons.Default.Quiz,
            color = ESGSuccess
        ),
        Activity(
            title = "Tạo bài tập mới",
            description = "Thiết kế chiến lược bền vững",
            time = "1 ngày trước",
            icon = Icons.Default.Create,
            color = ESGWarning
        )
    )
}

private fun getUpcomingDeadlines(): List<Deadline> {
    return listOf(
        Deadline(
            title = "Nộp báo cáo ESG",
            className = "ESG-101",
            dueDate = "Hôm nay",
            isUrgent = true
        ),
        Deadline(
            title = "Bài tập nhóm",
            className = "ESG-102",
            dueDate = "2 ngày nữa",
            isUrgent = false
        ),
        Deadline(
            title = "Thuyết trình dự án",
            className = "ESG-201",
            dueDate = "1 tuần nữa",
            isUrgent = false
        )
    )
}
