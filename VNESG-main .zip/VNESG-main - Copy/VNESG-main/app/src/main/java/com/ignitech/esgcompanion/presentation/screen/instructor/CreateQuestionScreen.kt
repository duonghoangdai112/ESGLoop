package com.ignitech.esgcompanion.presentation.screen.instructor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.hilt.navigation.compose.hiltViewModel
import com.ignitech.esgcompanion.presentation.viewmodel.CreateQuestionViewModel
import com.ignitech.esgcompanion.ui.theme.*
import com.ignitech.esgcompanion.utils.AppColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateQuestionScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: CreateQuestionViewModel = hiltViewModel()
) {
    var questionText by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("") }
    var selectedDifficulty by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var points by remember { mutableStateOf("") }
    var explanation by remember { mutableStateOf("") }
    var showTypeDropdown by remember { mutableStateOf(false) }
    var showDifficultyDropdown by remember { mutableStateOf(false) }
    var showCategoryDropdown by remember { mutableStateOf(false) }
    val colors = AppColors()
    
    // Collect UI state from ViewModel
    val uiState by viewModel.uiState.collectAsState()
    
    // Handle success state
    LaunchedEffect(uiState.isSuccess) {
        if (uiState.isSuccess) {
            // Show success message and navigate back
            navController.popBackStack()
            viewModel.resetSuccess()
        }
    }
    
    // Handle error state
    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            // TODO: Show error snackbar or dialog
            viewModel.clearError()
        }
    }

    val questionTypes = listOf("Trắc nghiệm", "Tự luận", "Đúng/Sai", "Điền từ", "Ghép cặp")
    val difficulties = listOf("Dễ", "Trung bình", "Khó", "Rất khó")
    val categories = listOf("Môi trường", "Xã hội", "Quản trị", "Tổng hợp", "Thực hành")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                }
                Text(
                    text = "Tạo câu hỏi mới",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Question Type Selection
        item {
            Text(
                text = "Loại câu hỏi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(questionTypes) { type ->
                    QuestionTypeChip(
                        text = type,
                        selected = selectedType == type,
                        onClick = { selectedType = type }
                    )
                }
            }
        }

        // Question Settings
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Difficulty Selection
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = selectedDifficulty,
                        onValueChange = { selectedDifficulty = it },
                        label = { Text("Độ khó") },
                        placeholder = { 
                    Text(
                        "Chọn độ khó",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { showDifficultyDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    DropdownMenu(
                        expanded = showDifficultyDropdown,
                        onDismissRequest = { showDifficultyDropdown = false }
                    ) {
                        difficulties.forEach { difficulty ->
                            DropdownMenuItem(
                                text = { Text(difficulty) },
                                onClick = {
                                    selectedDifficulty = difficulty
                                    showDifficultyDropdown = false
                                }
                            )
                        }
                    }
                }

                // Category Selection
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = { selectedCategory = it },
                        label = { Text("Chủ đề") },
                        placeholder = { 
                            Text(
                                "Chọn chủ đề",
                                color = colors.textSecondary.copy(alpha = 0.6f)
                            ) 
                        },
                        readOnly = true,
                        trailingIcon = { 
                            IconButton(onClick = { showCategoryDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    DropdownMenu(
                        expanded = showCategoryDropdown,
                        onDismissRequest = { showCategoryDropdown = false }
                    ) {
                        categories.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category) },
                                onClick = {
                                    selectedCategory = category
                                    showCategoryDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = points,
                onValueChange = { points = it },
                label = { Text("Điểm số") },
                placeholder = { 
                    Text(
                        "1",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Grade, contentDescription = null) }
            )
        }

        // Question Content
        item {
            Text(
                text = "Nội dung câu hỏi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            OutlinedTextField(
                value = questionText,
                onValueChange = { questionText = it },
                label = { Text("Câu hỏi") },
                placeholder = { 
                    Text(
                        "Nhập nội dung câu hỏi...",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                minLines = 3
            )
        }

        // Answer Options (for multiple choice)
        if (selectedType == "Trắc nghiệm") {
            item {
                Text(
                    text = "Các lựa chọn trả lời",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                MultipleChoiceOptions()
            }
        }

        // True/False Options
        if (selectedType == "Đúng/Sai") {
            item {
                Text(
                    text = "Lựa chọn trả lời",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                TrueFalseOptions()
            }
        }

        // Fill in the blank
        if (selectedType == "Điền từ") {
            item {
                Text(
                    text = "Từ cần điền",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                FillInBlankOptions()
            }
        }

        // Explanation
        item {
            Text(
                text = "Giải thích đáp án",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            OutlinedTextField(
                value = explanation,
                onValueChange = { explanation = it },
                label = { Text("Giải thích") },
                placeholder = { 
                    Text(
                        "Giải thích tại sao đáp án này đúng...",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp),
                minLines = 2
            )
        }

        // Question Tags
        item {
            Text(
                text = "Thẻ tag",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            QuestionTagsSection()
        }

        // Question Templates
        item {
            Text(
                text = "Mẫu câu hỏi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(getQuestionTemplates()) { template ->
            QuestionTemplateCard(
                template = template,
                onClick = { /* Apply template */ }
            )
        }

        // Action Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.outline
                    )
                ) {
                    Text("Hủy")
                }
                Button(
                    onClick = { 
                        if (questionText.isNotBlank() && selectedType.isNotBlank() && 
                            selectedDifficulty.isNotBlank() && selectedCategory.isNotBlank() && 
                            points.isNotBlank()) {
                            
                            val options = when (selectedType) {
                                "Trắc nghiệm" -> listOf("A", "B", "C", "D") // TODO: Get from MultipleChoiceOptions
                                "Đúng/Sai" -> listOf("Đúng", "Sai")
                                "Điền từ" -> listOf("") // TODO: Get from FillInBlankOptions
                                else -> emptyList()
                            }
                            
                            val correctAnswer = when (selectedType) {
                                "Trắc nghiệm" -> "A" // TODO: Get from MultipleChoiceOptions
                                "Đúng/Sai" -> "Đúng" // TODO: Get from TrueFalseOptions
                                "Điền từ" -> "" // TODO: Get from FillInBlankOptions
                                else -> ""
                            }
                            
                            val tags = listOf("ESG", "Bền vững", "Môi trường") // TODO: Get from QuestionTagsSection
                            
                            viewModel.createQuestion(
                                questionText = questionText,
                                type = selectedType,
                                difficulty = selectedDifficulty,
                                category = selectedCategory,
                                points = points.toIntOrNull() ?: 1,
                                explanation = explanation,
                                authorId = "instructor_001", // TODO: Get from current user
                                authorName = "Giảng viên", // TODO: Get from current user
                                options = options,
                                correctAnswer = correctAnswer,
                                tags = tags,
                                hint = ""
                            )
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800),
                        contentColor = Color.White
                    ),
                    enabled = !uiState.isLoading && questionText.isNotBlank() && 
                             selectedType.isNotBlank() && selectedDifficulty.isNotBlank() && 
                             selectedCategory.isNotBlank() && points.isNotBlank()
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(if (uiState.isLoading) "Đang lưu..." else "Lưu câu hỏi")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionTypeChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        onClick = onClick,
        label = { Text(text) },
        selected = selected,
        leadingIcon = if (selected) {
            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
        } else null
    )
}

@Composable
fun MultipleChoiceOptions() {
    var options by remember { mutableStateOf(listOf("", "", "", "")) }
    var correctAnswer by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        options.forEachIndexed { index, option ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = correctAnswer == index,
                    onClick = { correctAnswer = index }
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(
                    value = option,
                    onValueChange = { newValue ->
                        options = options.toMutableList().apply { set(index, newValue) }
                    },
                    label = { Text("Lựa chọn ${('A' + index)}") },
                    modifier = Modifier.weight(1f)
                )
                if (options.size > 2) {
                    IconButton(
                        onClick = {
                            options = options.filterIndexed { i, _ -> i != index }
                        }
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Xóa")
                    }
                }
            }
        }
        
        if (options.size < 6) {
            Button(
                onClick = {
                    options = options + ""
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Thêm lựa chọn")
            }
        }
    }
}

@Composable
fun TrueFalseOptions() {
    var correctAnswer by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .selectableGroup()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .selectable(
                    selected = correctAnswer,
                    onClick = { correctAnswer = true }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = correctAnswer,
                onClick = { correctAnswer = true }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Đúng")
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .selectable(
                    selected = !correctAnswer,
                    onClick = { correctAnswer = false }
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = !correctAnswer,
                onClick = { correctAnswer = false }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Sai")
        }
    }
}

@Composable
fun FillInBlankOptions() {
    var answers by remember { mutableStateOf(listOf("")) }

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        answers.forEachIndexed { index, answer ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = answer,
                    onValueChange = { newValue ->
                        answers = answers.toMutableList().apply { set(index, newValue) }
                    },
                    label = { Text("Đáp án ${index + 1}") },
                    modifier = Modifier.weight(1f)
                )
                if (answers.size > 1) {
                    IconButton(
                        onClick = {
                            answers = answers.filterIndexed { i, _ -> i != index }
                        }
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Xóa")
                    }
                }
            }
        }
        
        Button(
            onClick = {
                answers = answers + ""
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Thêm đáp án")
        }
    }
}

@Composable
fun QuestionTagsSection() {
    var tags by remember { mutableStateOf(listOf("ESG", "Bền vững", "Môi trường")) }
    var newTag by remember { mutableStateOf("") }
    val colors = AppColors()

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tags) { tag ->
                AssistChip(
                    onClick = {
                        tags = tags.filter { it != tag }
                    },
                    label = { Text(tag) },
                    trailingIcon = {
                        Icon(Icons.Default.Close, contentDescription = "Xóa", modifier = Modifier.size(16.dp))
                    }
                )
            }
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newTag,
                onValueChange = { newTag = it },
                label = { Text("Thêm tag") },
                placeholder = { 
                    Text(
                        "Nhập tag mới",
                        color = colors.textSecondary.copy(alpha = 0.6f)
                    ) 
                },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    if (newTag.isNotBlank()) {
                        tags = tags + newTag
                        newTag = ""
                    }
                }
            ) {
                Text("Thêm")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionTemplateCard(
    template: QuestionTemplate,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = template.icon,
                contentDescription = null,
                tint = template.color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = template.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = template.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = template.type,
                    style = MaterialTheme.typography.bodySmall,
                    color = template.color
                )
                Text(
                    text = template.difficulty,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// Data classes
data class QuestionTemplate(
    val name: String,
    val description: String,
    val type: String,
    val difficulty: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

// Mock data
private fun getQuestionTemplates(): List<QuestionTemplate> {
    return listOf(
        QuestionTemplate(
            name = "Mẫu câu hỏi ESG cơ bản",
            description = "Câu hỏi trắc nghiệm về ESG",
            type = "Trắc nghiệm",
            difficulty = "Dễ",
            icon = Icons.Default.Quiz,
            color = ESGInfo
        ),
        QuestionTemplate(
            name = "Mẫu câu hỏi thực hành",
            description = "Câu hỏi tự luận về ứng dụng ESG",
            type = "Tự luận",
            difficulty = "Khó",
            icon = Icons.Default.Edit,
            color = ESGWarning
        ),
        QuestionTemplate(
            name = "Mẫu câu hỏi đúng/sai",
            description = "Câu hỏi đúng/sai về quy định ESG",
            type = "Đúng/Sai",
            difficulty = "Trung bình",
            icon = Icons.Default.CheckCircle,
            color = ESGSuccess
        )
    )
}