package com.ignitech.esgcompanion.data.local.dao

import androidx.room.*
import com.ignitech.esgcompanion.data.local.entity.ESGQuestionEntity
import com.ignitech.esgcompanion.data.local.entity.ESGQuestionOptionEntity
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import kotlinx.coroutines.flow.Flow

@Dao
interface ESGQuestionDao {
    @Query("SELECT * FROM esg_questions")
    fun getAllQuestions(): Flow<List<ESGQuestionEntity>>
    
    @Query("SELECT * FROM esg_questions WHERE pillar = :pillar")
    fun getQuestionsByPillar(pillar: ESGPillar): Flow<List<ESGQuestionEntity>>
    
    @Query("SELECT * FROM esg_questions WHERE category = :category")
    fun getQuestionsByCategory(category: String): Flow<List<ESGQuestionEntity>>
    
    @Query("SELECT * FROM esg_questions WHERE id = :questionId")
    suspend fun getQuestionById(questionId: String): ESGQuestionEntity?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: ESGQuestionEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<ESGQuestionEntity>)
    
    @Update
    suspend fun updateQuestion(question: ESGQuestionEntity)
    
    @Delete
    suspend fun deleteQuestion(question: ESGQuestionEntity)
}

@Dao
interface ESGQuestionOptionDao {
    @Query("SELECT * FROM esg_question_options WHERE questionId = :questionId")
    suspend fun getOptionsByQuestionId(questionId: String): List<ESGQuestionOptionEntity>
    
    @Query("SELECT * FROM esg_question_options WHERE id = :optionId")
    suspend fun getOptionById(optionId: String): ESGQuestionOptionEntity?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOption(option: ESGQuestionOptionEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOptions(options: List<ESGQuestionOptionEntity>)
    
    @Update
    suspend fun updateOption(option: ESGQuestionOptionEntity)
    
    @Delete
    suspend fun deleteOption(option: ESGQuestionOptionEntity)
}

