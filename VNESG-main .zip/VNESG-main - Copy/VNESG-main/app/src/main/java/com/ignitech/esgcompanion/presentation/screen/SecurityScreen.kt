package com.ignitech.esgcompanion.presentation.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.ignitech.esgcompanion.presentation.viewmodel.UserViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityScreen(
    navController: NavController,
    viewModel: UserViewModel = hiltViewModel()
) {
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var showTwoFactorDialog by remember { mutableStateOf(false) }
    
    // Password change form
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showCurrentPassword by remember { mutableStateOf(false) }
    var showNewPassword by remember { mutableStateOf(false) }
    var showConfirmPassword by remember { mutableStateOf(false) }
    
    // Two-factor authentication
    var twoFactorEnabled by remember { mutableStateOf(false) }
    var backupCodes by remember { mutableStateOf(listOf<String>()) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bảo mật") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Password Security Section
            item {
                SecuritySectionCard(
                    title = "Mật khẩu",
                    icon = Icons.Default.Lock,
                    items = listOf(
                        SecurityItem(
                            title = "Đổi mật khẩu",
                            subtitle = "Cập nhật mật khẩu hiện tại",
                            icon = Icons.Default.Key,
                            onClick = { showChangePasswordDialog = true }
                        ),
                        SecurityItem(
                            title = "Lịch sử đăng nhập",
                            subtitle = "Xem các lần đăng nhập gần đây",
                            icon = Icons.Default.History,
                            onClick = { /* Navigate to login history */ }
                        )
                    )
                )
            }
            
            // Two-Factor Authentication Section
            item {
                SecuritySectionCard(
                    title = "Xác thực hai yếu tố",
                    icon = Icons.Default.Security,
                    items = listOf(
                        SecurityItem(
                            title = if (twoFactorEnabled) "Tắt xác thực 2FA" else "Bật xác thực 2FA",
                            subtitle = if (twoFactorEnabled) "Bảo mật đã được bật" else "Tăng cường bảo mật tài khoản",
                            icon = Icons.Default.VerifiedUser,
                            onClick = { showTwoFactorDialog = true }
                        ),
                        SecurityItem(
                            title = "Mã dự phòng",
                            subtitle = "Quản lý mã khôi phục",
                            icon = Icons.Default.Backup,
                            onClick = { /* Navigate to backup codes */ }
                        )
                    )
                )
            }
            
            // Privacy Settings Section
            item {
                SecuritySectionCard(
                    title = "Quyền riêng tư",
                    icon = Icons.Default.PrivacyTip,
                    items = listOf(
                        SecurityItem(
                            title = "Quyền truy cập dữ liệu",
                            subtitle = "Quản lý quyền truy cập ứng dụng",
                            icon = Icons.Default.Settings,
                            onClick = { /* Navigate to permissions */ }
                        ),
                        SecurityItem(
                            title = "Xóa dữ liệu cá nhân",
                            subtitle = "Xóa tất cả dữ liệu được lưu trữ",
                            icon = Icons.Default.DeleteForever,
                            onClick = { /* Show data deletion dialog */ }
                        )
                    )
                )
            }
            
            // Account Security Section
            item {
                SecuritySectionCard(
                    title = "Bảo mật tài khoản",
                    icon = Icons.Default.AccountCircle,
                    items = listOf(
                        SecurityItem(
                            title = "Đăng xuất khỏi tất cả thiết bị",
                            subtitle = "Kết thúc phiên đăng nhập trên mọi thiết bị",
                            icon = Icons.Default.Logout,
                            onClick = { /* Logout from all devices */ }
                        ),
                        SecurityItem(
                            title = "Xóa tài khoản",
                            subtitle = "Xóa vĩnh viễn tài khoản và tất cả dữ liệu",
                            icon = Icons.Default.DeleteForever,
                            isDestructive = true,
                            onClick = { showDeleteAccountDialog = true }
                        )
                    )
                )
            }
        }
    }
    
    // Change Password Dialog
    if (showChangePasswordDialog) {
        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("Đổi mật khẩu") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentPassword,
                        onValueChange = { currentPassword = it },
                        label = { Text("Mật khẩu hiện tại") },
                        visualTransformation = if (showCurrentPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showCurrentPassword = !showCurrentPassword }) {
                                Icon(
                                    if (showCurrentPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("Mật khẩu mới") },
                        visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showNewPassword = !showNewPassword }) {
                                Icon(
                                    if (showNewPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("Xác nhận mật khẩu mới") },
                        visualTransformation = if (showConfirmPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showConfirmPassword = !showConfirmPassword }) {
                                Icon(
                                    if (showConfirmPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        // Handle password change
                        showChangePasswordDialog = false
                        currentPassword = ""
                        newPassword = ""
                        confirmPassword = ""
                    }
                ) {
                    Text("Đổi mật khẩu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
    
    // Two-Factor Authentication Dialog
    if (showTwoFactorDialog) {
        AlertDialog(
            onDismissRequest = { showTwoFactorDialog = false },
            title = { Text(if (twoFactorEnabled) "Tắt xác thực 2FA" else "Bật xác thực 2FA") },
            text = {
                Text(
                    if (twoFactorEnabled) {
                        "Bạn có chắc chắn muốn tắt xác thực hai yếu tố? Điều này sẽ làm giảm mức độ bảo mật của tài khoản."
                    } else {
                        "Xác thực hai yếu tố sẽ tăng cường bảo mật cho tài khoản của bạn bằng cách yêu cầu mã xác thực từ ứng dụng xác thực."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        twoFactorEnabled = !twoFactorEnabled
                        showTwoFactorDialog = false
                    }
                ) {
                    Text(if (twoFactorEnabled) "Tắt" else "Bật")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTwoFactorDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
    
    // Delete Account Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            title = { Text("Xóa tài khoản") },
            text = {
                Text(
                    "Bạn có chắc chắn muốn xóa tài khoản? Hành động này không thể hoàn tác và tất cả dữ liệu sẽ bị mất vĩnh viễn."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        // Handle account deletion
                        showDeleteAccountDialog = false
                        navController.navigate("login") {
                            popUpTo("security") { inclusive = true }
                        }
                    }
                ) {
                    Text("Xóa tài khoản")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
fun SecuritySectionCard(
    title: String,
    icon: ImageVector,
    items: List<SecurityItem>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primary,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
                
                Spacer(modifier = Modifier.width(10.dp))
                
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            
            items.forEachIndexed { index, item ->
                SecurityItemRow(item = item)
                if (index < items.size - 1) {
                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityItemRow(
    item: SecurityItem
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = item.onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Icon(
                imageVector = item.icon,
                contentDescription = item.title,
                modifier = Modifier.size(24.dp),
                tint = if (item.isDestructive) 
                    MaterialTheme.colorScheme.error 
                else 
                    MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    color = if (item.isDestructive) 
                        MaterialTheme.colorScheme.error 
                    else 
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
                item.subtitle?.let { subtitle ->
                    Spacer(modifier = Modifier.height(1.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
            
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Navigate",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

data class SecurityItem(
    val icon: ImageVector,
    val title: String,
    val subtitle: String?,
    val onClick: () -> Unit,
    val isDestructive: Boolean = false
)
