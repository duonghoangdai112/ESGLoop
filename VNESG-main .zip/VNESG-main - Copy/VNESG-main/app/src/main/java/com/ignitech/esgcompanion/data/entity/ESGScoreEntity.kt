package com.ignitech.esgcompanion.data.entity

data class ESGScoreResult(
    val averageScore: Double,
    val assessmentCount: Int
)

data class PillarScore(
    val pillar: String,
    val averageScore: Double
)
