package com.ignitech.esgcompanion.data.seed

import com.ignitech.esgcompanion.data.local.entity.UserEntity
import com.ignitech.esgcompanion.domain.entity.SubscriptionPlan
import com.ignitech.esgcompanion.domain.entity.UserRole
import java.util.*

object StudentSeeder {
    
    fun getStudents(): List<UserEntity> {
        val currentTime = System.currentTimeMillis()
        
        return listOf(
            // Lớp ESG-101
            UserEntity(
                id = "student_001",
                email = "nguyenvana@student.neu.edu.vn",
                password = "123456",
                name = "Nguyễn Văn A",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_101",
                companyName = "Lớp ESG-101 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 30,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "student_002",
                email = "tranthib@student.neu.edu.vn",
                password = "123456",
                name = "Trần Thị B",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_101",
                companyName = "Lớp ESG-101 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 25,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            ),
            UserEntity(
                id = "student_003",
                email = "levanc@student.neu.edu.vn",
                password = "123456",
                name = "Lê Văn C",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_101",
                companyName = "Lớp ESG-101 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 20,
                lastLoginAt = currentTime - 86400000L * 3,
                isActive = false
            ),
            UserEntity(
                id = "student_004",
                email = "phamthid@student.neu.edu.vn",
                password = "123456",
                name = "Phạm Thị D",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_101",
                companyName = "Lớp ESG-101 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 15,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "student_005",
                email = "hoangvane@student.neu.edu.vn",
                password = "123456",
                name = "Hoàng Văn E",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_101",
                companyName = "Lớp ESG-101 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 10,
                lastLoginAt = currentTime - 86400000L * 4,
                isActive = false
            ),
            
            // Lớp ESG-102
            UserEntity(
                id = "student_006",
                email = "vuthif@student.neu.edu.vn",
                password = "123456",
                name = "Vũ Thị F",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_102",
                companyName = "Lớp ESG-102 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 28,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            ),
            UserEntity(
                id = "student_007",
                email = "dangvang@student.neu.edu.vn",
                password = "123456",
                name = "Đặng Văn G",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_102",
                companyName = "Lớp ESG-102 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 22,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "student_008",
                email = "buitthih@student.neu.edu.vn",
                password = "123456",
                name = "Bùi Thị H",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_102",
                companyName = "Lớp ESG-102 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 18,
                lastLoginAt = currentTime - 86400000L * 3,
                isActive = false
            ),
            UserEntity(
                id = "student_009",
                email = "ngotheni@student.neu.edu.vn",
                password = "123456",
                name = "Ngô Thế I",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_102",
                companyName = "Lớp ESG-102 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 12,
                lastLoginAt = currentTime - 86400000L * 5,
                isActive = false
            ),
            UserEntity(
                id = "student_010",
                email = "dinhthij@student.neu.edu.vn",
                password = "123456",
                name = "Đinh Thị J",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_102",
                companyName = "Lớp ESG-102 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 8,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            
            // Lớp ESG-201
            UserEntity(
                id = "student_011",
                email = "truongvank@student.neu.edu.vn",
                password = "123456",
                name = "Trương Văn K",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_201",
                companyName = "Lớp ESG-201 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 35,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            ),
            UserEntity(
                id = "student_012",
                email = "lethil@student.neu.edu.vn",
                password = "123456",
                name = "Lê Thị L",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_201",
                companyName = "Lớp ESG-201 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 30,
                lastLoginAt = currentTime - 86400000L * 1,
                isActive = false
            ),
            UserEntity(
                id = "student_013",
                email = "phamvanm@student.neu.edu.vn",
                password = "123456",
                name = "Phạm Văn M",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_201",
                companyName = "Lớp ESG-201 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 25,
                lastLoginAt = currentTime - 86400000L * 4,
                isActive = false
            ),
            UserEntity(
                id = "student_014",
                email = "hoangthin@student.neu.edu.vn",
                password = "123456",
                name = "Hoàng Thị N",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_201",
                companyName = "Lớp ESG-201 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 20,
                lastLoginAt = currentTime - 86400000L * 3,
                isActive = false
            ),
            UserEntity(
                id = "student_015",
                email = "vutheo@student.neu.edu.vn",
                password = "123456",
                name = "Vũ Thế O",
                role = UserRole.ACADEMIC,
                companyId = "class_esg_201",
                companyName = "Lớp ESG-201 - Đại học Kinh tế Quốc dân",
                subscriptionPlan = SubscriptionPlan.FREE,
                avatarUrl = null,
                createdAt = currentTime - 86400000L * 15,
                lastLoginAt = currentTime - 86400000L * 2,
                isActive = false
            )
        )
    }
    
    fun getStudentsByClass(classId: String): List<UserEntity> {
        return getStudents().filter { it.companyId == classId }
    }
    
    fun getStudentsByInstructor(instructorId: String): List<UserEntity> {
        // Giả sử giảng viên có thể dạy nhiều lớp
        return when (instructorId) {
            "instructor_user_1" -> getStudents().filter { 
                it.companyId in listOf("class_esg_101", "class_esg_102") 
            }
            "instructor_user_2" -> getStudents().filter { 
                it.companyId == "class_esg_201" 
            }
            else -> emptyList()
        }
    }
    
    fun getClassStatistics(): Map<String, ClassStats> {
        val students = getStudents()
        return mapOf(
            "class_esg_101" to ClassStats(
                className = "ESG-101",
                totalStudents = students.count { it.companyId == "class_esg_101" },
                activeStudents = students.count { 
                    it.companyId == "class_esg_101" && 
                    (System.currentTimeMillis() - (it.lastLoginAt ?: 0L)) < 86400000L * 7 // 7 ngày
                },
                averageScore = 85.2f,
                completedAssignments = 78
            ),
            "class_esg_102" to ClassStats(
                className = "ESG-102",
                totalStudents = students.count { it.companyId == "class_esg_102" },
                activeStudents = students.count { 
                    it.companyId == "class_esg_102" && 
                    (System.currentTimeMillis() - (it.lastLoginAt ?: 0L)) < 86400000L * 7
                },
                averageScore = 82.7f,
                completedAssignments = 65
            ),
            "class_esg_201" to ClassStats(
                className = "ESG-201",
                totalStudents = students.count { it.companyId == "class_esg_201" },
                activeStudents = students.count { 
                    it.companyId == "class_esg_201" && 
                    (System.currentTimeMillis() - (it.lastLoginAt ?: 0L)) < 86400000L * 7
                },
                averageScore = 88.1f,
                completedAssignments = 92
            )
        )
    }
}

data class ClassStats(
    val className: String,
    val totalStudents: Int,
    val activeStudents: Int,
    val averageScore: Float,
    val completedAssignments: Int
)
