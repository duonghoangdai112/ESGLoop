package com.ignitech.esgcompanion.data.local

import com.ignitech.esgcompanion.data.repository.ESGAssessmentRepository
import com.ignitech.esgcompanion.data.local.dao.UserDao
import com.ignitech.esgcompanion.data.dao.ReportDao
import com.ignitech.esgcompanion.data.dao.ESGAssessmentDao
import com.ignitech.esgcompanion.data.seed.UserSeeder
import com.ignitech.esgcompanion.data.seed.ReportSeeder
import com.ignitech.esgcompanion.data.seed.AssessmentSeeder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DatabaseInitializer @Inject constructor(
    private val repository: ESGAssessmentRepository,
    private val userDao: UserDao,
    private val reportDao: ReportDao,
    private val esgAssessmentDao: ESGAssessmentDao
) {
    
    suspend fun initializeDatabase() = withContext(Dispatchers.IO) {
        try {
            // Initialize demo users first
            initializeUsers()
            
            // Initialize demo assessments
            initializeAssessments()
            
            // Initialize demo reports
            initializeReports()
            
            // Initialize ESG questions and categories
            repository.initializeDatabase()
            
            // Initialize Learning Hub data
            repository.initializeLearningHub()
        } catch (e: Exception) {
            android.util.Log.e("DatabaseInitializer", "Failed to initialize database", e)
            throw e
        }
    }
    
    private suspend fun initializeUsers() {
        val existingUsers = userDao.getAllUsers().first()
        if (existingUsers.isEmpty()) {
            // Insert demo users (all inactive by default)
            userDao.insertUsers(UserSeeder.getDemoUsers())
            android.util.Log.d("DatabaseInitializer", "Inserted ${UserSeeder.getDemoUsers().size} demo users")
        } else {
            // Users already exist, don't reinitialize
            android.util.Log.d("DatabaseInitializer", "Users already exist (${existingUsers.size} users), skipping user initialization")
        }
        
        // Always clear current user on app startup to ensure no one is logged in
        userDao.clearCurrentUser()
        android.util.Log.d("DatabaseInitializer", "Cleared all current users on startup")
    }
    
    private suspend fun initializeAssessments() {
        val existingAssessments = esgAssessmentDao.getAssessmentsByUser("enterprise_user_1").first()
        if (existingAssessments.isEmpty()) {
            // Insert demo assessments
            esgAssessmentDao.insertAssessments(AssessmentSeeder.getDemoAssessments())
        }
    }
    
    private suspend fun initializeReports() {
        val existingReports = reportDao.getAllReports("enterprise_user_1").first()
        if (existingReports.isEmpty()) {
            // Insert demo reports
            reportDao.insertReports(ReportSeeder.getDemoReports())
        }
    }
}

