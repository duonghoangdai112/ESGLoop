package com.ignitech.esgcompanion.presentation.screen.expert

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.domain.entity.ESGPillarInfo
import com.ignitech.esgcompanion.presentation.screen.LearningHubScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertHomeScreen(
    navController: NavController
) {
    var selectedTab by remember { mutableStateOf(0) }
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Trang chủ") },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.School, contentDescription = "Learning") },
                    label = { Text("Học liệu") },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Assessment, contentDescription = "Assessment") },
                    label = { Text("Đánh giá") },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Group, contentDescription = "Community") },
                    label = { Text("Cộng đồng") },
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Article, contentDescription = "News") },
                    label = { Text("Tin tức") },
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 }
                )
            }
        }
    ) { paddingValues ->
        when (selectedTab) {
            0 -> ExpertHomeContent(navController = navController, modifier = Modifier.padding(paddingValues))
            1 -> ExpertLearningContent(navController = navController, modifier = Modifier.padding(paddingValues))
            2 -> ExpertAssessmentContent(navController = navController, modifier = Modifier.padding(paddingValues))
            3 -> CommunityContent(navController = navController, modifier = Modifier.padding(paddingValues))
            4 -> NewsContent(navController = navController, modifier = Modifier.padding(paddingValues))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertHomeContent(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize()
    ) {
        // Header
        TopAppBar(
            title = { 
                Column {
                    Text(
                        text = "ESG Companion",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chuyên gia ESG",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            actions = {
                IconButton(onClick = { navController.navigate("settings") }) {
                    Icon(Icons.Default.Person, contentDescription = "Profile")
                }
            }
        )
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Learning Progress
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "Tiến Độ Học Tập",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "85%",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "17/20 bài học",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = 0.85f,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            
            // ESG Knowledge Areas
            item {
                Text(
                    text = "Lĩnh Vực Kiến Thức ESG",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(ESGPillarInfo.ALL_PILLARS) { pillarInfo ->
                        ExpertKnowledgeAreaCard(
                            pillarInfo = pillarInfo,
                            progress = when (pillarInfo.pillar) {
                                ESGPillar.ENVIRONMENTAL -> 0.9f
                                ESGPillar.SOCIAL -> 0.8f
                                ESGPillar.GOVERNANCE -> 0.7f
                            }
                        )
                    }
                }
            }
            
            // Quick Actions
            item {
                Text(
                    text = "Thao Tác Nhanh",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ExpertQuickActionCard(
                        title = "Học tiếp",
                        icon = Icons.Default.School,
                        onClick = { /* Continue learning */ },
                        modifier = Modifier.weight(1f)
                    )
                    ExpertQuickActionCard(
                        title = "Thi thử",
                        icon = Icons.Default.Quiz,
                        onClick = { /* Take quiz */ },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            // Recent Learning
            item {
                Text(
                    text = "Học Tập Gần Đây",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            items(3) { index ->
                ExpertLearningCard(
                    title = when (index) {
                        0 -> "Quản lý rủi ro môi trường"
                        1 -> "Đa dạng và hòa nhập trong doanh nghiệp"
                        2 -> "Báo cáo bền vững theo chuẩn GRI"
                        else -> "Bài học khác"
                    },
                    progress = when (index) {
                        0 -> 1.0f
                        1 -> 0.8f
                        2 -> 0.5f
                        else -> 0.0f
                    },
                    time = when (index) {
                        0 -> "Hoàn thành hôm qua"
                        1 -> "Đang học"
                        2 -> "Bắt đầu hôm nay"
                        else -> "Khác"
                    }
                )
            }
            
            // Achievements
            item {
                Text(
                    text = "Thành Tích",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ExpertAchievementCard(
                        title = "Chuyên gia ESG",
                        icon = "⭐",
                        modifier = Modifier.weight(1f)
                    )
                    ExpertAchievementCard(
                        title = "Người học chăm",
                        icon = "🎓",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

    }
}

@Composable
fun ExpertLearningContent(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    // Import LearningHubScreen and display it directly
    LearningHubScreen(
        modifier = modifier
    )
}

@Composable
fun ExpertAssessmentContent(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    ExpertAssessmentTabScreen(
        modifier = modifier,
        navController = navController
    )
}

@Composable
fun CommunityContent(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    ExpertCommunityTabScreen(
        modifier = modifier
    )
}

@Composable
fun NewsContent(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    ExpertNewsTabScreen(
        modifier = modifier,
        navController = navController
    )
}

@Composable
fun ExpertKnowledgeAreaCard(
    pillarInfo: ESGPillarInfo,
    progress: Float
) {
    Card(
        modifier = Modifier.width(140.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = pillarInfo.icon,
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = pillarInfo.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${(progress * 100).toInt()}%",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun ExpertLearningCard(
    title: String,
    progress: Float,
    time: String
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = time,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ExpertAchievementCard(
    title: String,
    icon: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = icon,
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertQuickActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
        }
    }
}
