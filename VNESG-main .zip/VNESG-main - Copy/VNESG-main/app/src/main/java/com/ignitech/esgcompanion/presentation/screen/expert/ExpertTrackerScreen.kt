package com.ignitech.esgcompanion.presentation.screen.expert

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.presentation.viewmodel.ExpertTrackerViewModel
import com.ignitech.esgcompanion.utils.AppColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertTrackerScreen(
    modifier: Modifier = Modifier,
    viewModel: ExpertTrackerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = AppColors()

    LaunchedEffect(Unit) {
        viewModel.loadTrackerData()
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Theo dõi ESG - Chuyên gia") },
                actions = {
                    IconButton(onClick = { viewModel.toggleFilter() }) {
                        Icon(Icons.Default.FilterList, contentDescription = "Lọc")
                    }
                    IconButton(onClick = { viewModel.showAddActivity() }) {
                        Icon(Icons.Default.Add, contentDescription = "Thêm hoạt động")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(colors.backgroundSurface)
        ) {
            // Filter Section
            if (uiState.isFilterVisible) {
                ExpertFilterSection(
                    selectedPillar = uiState.selectedPillar,
                    selectedStatus = uiState.selectedStatus,
                    selectedPriority = uiState.selectedPriority,
                    onPillarSelected = viewModel::selectPillar,
                    onStatusSelected = viewModel::selectStatus,
                    onPrioritySelected = viewModel::selectPriority
                )
            }

            // Content
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Expert Statistics Cards
                item {
                    ExpertStatisticsSection(
                        totalActivities = uiState.totalActivities,
                        completedActivities = uiState.completedActivities,
                        overdueActivities = uiState.overdueActivities,
                        verifiedActivities = uiState.verifiedActivities,
                        kpiCount = uiState.kpiCount,
                        pendingVerifications = uiState.pendingVerifications
                    )
                }

                // Pillar Filter Chips
                item {
                    PillarFilterSection(
                        selectedPillar = uiState.selectedPillar,
                        onPillarSelected = viewModel::selectPillar
                    )
                }

                // Activities List
                if (uiState.activities.isNotEmpty()) {
                    item {
                        Text(
                            text = "Hoạt động ESG",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    
                    items(uiState.activities) { activity ->
                        ExpertActivityCard(
                            activity = activity,
                            onClick = { viewModel.openActivity(activity) },
                            onStatusChange = { viewModel.updateActivityStatus(activity.id, it) },
                            onVerify = { viewModel.verifyActivity(activity.id) }
                        )
                    }
                } else {
                    item {
                        EmptyState(
                            message = "Chưa có hoạt động ESG nào",
                            onAddActivity = { viewModel.showAddActivity() }
                        )
                    }
                }

                // KPIs Section
                if (uiState.kpis.isNotEmpty()) {
                    item {
                        Text(
                            text = "KPI ESG",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    
                    items(uiState.kpis) { kpi ->
                        ExpertKPICard(
                            kpi = kpi,
                            onClick = { viewModel.openKPI(kpi) },
                            onUpdateValue = { viewModel.updateKPIValue(kpi.id, it) },
                            onVerify = { viewModel.verifyKPI(kpi.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExpertStatisticsSection(
    totalActivities: Int,
    completedActivities: Int,
    overdueActivities: Int,
    verifiedActivities: Int,
    kpiCount: Int,
    pendingVerifications: Int
) {
    val colors = AppColors()
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ExpertStatCard(
                title = "Tổng hoạt động",
                value = totalActivities.toString(),
                color = colors.primary
            )
        }
        
        item {
            ExpertStatCard(
                title = "Đã hoàn thành",
                value = completedActivities.toString(),
                color = Color(0xFF4CAF50)
            )
        }
        
        item {
            ExpertStatCard(
                title = "Đã xác minh",
                value = verifiedActivities.toString(),
                color = Color(0xFF2196F3)
            )
        }
        
        item {
            ExpertStatCard(
                title = "Chờ xác minh",
                value = pendingVerifications.toString(),
                color = Color(0xFFFF9800)
            )
        }
        
        item {
            ExpertStatCard(
                title = "Quá hạn",
                value = overdueActivities.toString(),
                color = Color(0xFFFF5722)
            )
        }
        
        item {
            ExpertStatCard(
                title = "KPI theo dõi",
                value = kpiCount.toString(),
                color = Color(0xFF9C27B0)
            )
        }
    }
}

@Composable
fun ExpertActivityCard(
    activity: ESGTrackerEntity,
    onClick: () -> Unit,
    onStatusChange: (TrackerStatus) -> Unit,
    onVerify: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    modifier = Modifier.weight(1f)
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusChip(status = activity.status)
                    if (activity.isVerified) {
                        Icon(
                            Icons.Default.Verified,
                            contentDescription = "Đã xác minh",
                            tint = Color(0xFF2196F3),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            Text(
                text = activity.description,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dự kiến: ${dateFormat.format(Date(activity.plannedDate))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                
                Text(
                    text = when (activity.pillar) {
                        ESGPillar.ENVIRONMENTAL -> "🌱 Môi trường"
                        ESGPillar.SOCIAL -> "👥 Xã hội"
                        ESGPillar.GOVERNANCE -> "🏛️ Quản trị"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
            
            // Priority indicator
            PriorityChip(priority = activity.priority)
            
            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (activity.status == TrackerStatus.IN_PROGRESS) {
                    Button(
                        onClick = { onStatusChange(TrackerStatus.COMPLETED) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                    ) {
                        Text("Hoàn thành")
                    }
                    
                    OutlinedButton(
                        onClick = { onStatusChange(TrackerStatus.ON_HOLD) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Tạm dừng")
                    }
                }
                
                if (!activity.isVerified && activity.status == TrackerStatus.COMPLETED) {
                    Button(
                        onClick = onVerify,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3))
                    ) {
                        Text("Xác minh")
                    }
                }
            }
        }
    }
}

@Composable
fun ExpertKPICard(
    kpi: ESGTrackerKPIEntity,
    onClick: () -> Unit,
    onUpdateValue: (Double) -> Unit,
    onVerify: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = kpi.kpiName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    modifier = Modifier.weight(1f)
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when (kpi.pillar) {
                            ESGPillar.ENVIRONMENTAL -> "🌱"
                            ESGPillar.SOCIAL -> "👥"
                            ESGPillar.GOVERNANCE -> "🏛️"
                        },
                        style = MaterialTheme.typography.headlineSmall
                    )
                    
                    if (kpi.isActive) {
                        Icon(
                            Icons.Default.Verified,
                            contentDescription = "Đã xác minh",
                            tint = Color(0xFF2196F3),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            Text(
                text = kpi.kpiDescription,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Mục tiêu: ${kpi.targetValue} ${kpi.unit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    
                    if (kpi.currentValue != null) {
                        Text(
                            text = "Hiện tại: ${kpi.currentValue} ${kpi.unit}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onUpdateValue(kpi.currentValue ?: 0.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
                    ) {
                        Text("Cập nhật")
                    }
                    
                    if (!kpi.isActive) {
                        Button(
                            onClick = onVerify,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3))
                        ) {
                            Text("Xác minh")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PriorityChip(priority: TrackerPriority) {
    val (text, color) = when (priority) {
        TrackerPriority.LOW -> "Thấp" to Color(0xFF4CAF50)
        TrackerPriority.MEDIUM -> "Trung bình" to Color(0xFFFF9800)
        TrackerPriority.HIGH -> "Cao" to Color(0xFFFF5722)
        TrackerPriority.CRITICAL -> "Khẩn cấp" to Color(0xFFF44336)
    }
    
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ExpertFilterSection(
    selectedPillar: ESGPillar?,
    selectedStatus: TrackerStatus?,
    selectedPriority: TrackerPriority?,
    onPillarSelected: (ESGPillar?) -> Unit,
    onStatusSelected: (TrackerStatus?) -> Unit,
    onPrioritySelected: (TrackerPriority?) -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Bộ lọc chuyên gia",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            // Status Filter
            Text(
                text = "Trạng thái",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + TrackerStatus.values().toList()) { status ->
                    StatusFilterChip(
                        status = status,
                        isSelected = status == selectedStatus,
                        onClick = { onStatusSelected(status) }
                    )
                }
            }
            
            // Priority Filter
            Text(
                text = "Mức độ ưu tiên",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(null) + TrackerPriority.values().toList()) { priority ->
                    PriorityFilterChip(
                        priority = priority,
                        isSelected = priority == selectedPriority,
                        onClick = { onPrioritySelected(priority) }
                    )
                }
            }
        }
    }
}

@Composable
fun PriorityFilterChip(
    priority: TrackerPriority?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (priority) {
                TrackerPriority.LOW -> "Thấp"
                TrackerPriority.MEDIUM -> "Trung bình"
                TrackerPriority.HIGH -> "Cao"
                TrackerPriority.CRITICAL -> "Khẩn cấp"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

// Reuse existing components from EnterpriseTrackerScreen

@Composable
fun PillarFilterSection(
    selectedPillar: ESGPillar?,
    onPillarSelected: (ESGPillar?) -> Unit
) {
    val colors = AppColors()
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            PillarChip(
                pillar = null,
                isSelected = selectedPillar == null,
                onClick = { onPillarSelected(null) }
            )
        }
        
        items(ESGPillar.values().toList()) { pillar ->
            PillarChip(
                pillar = pillar,
                isSelected = pillar == selectedPillar,
                onClick = { onPillarSelected(pillar) }
            )
        }
    }
}

@Composable
fun PillarChip(
    pillar: ESGPillar?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (pillar) {
                ESGPillar.ENVIRONMENTAL -> "Môi trường"
                ESGPillar.SOCIAL -> "Xã hội"
                ESGPillar.GOVERNANCE -> "Quản trị"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@Composable
fun StatusChip(status: TrackerStatus) {
    val (text, color) = when (status) {
        TrackerStatus.PLANNED -> "Đã lên kế hoạch" to Color(0xFF2196F3)
        TrackerStatus.IN_PROGRESS -> "Đang thực hiện" to Color(0xFFFF9800)
        TrackerStatus.COMPLETED -> "Đã hoàn thành" to Color(0xFF4CAF50)
        TrackerStatus.CANCELLED -> "Đã hủy" to Color(0xFFF44336)
        TrackerStatus.ON_HOLD -> "Tạm dừng" to Color(0xFF9E9E9E)
        TrackerStatus.OVERDUE -> "Quá hạn" to Color(0xFFFF5722)
    }
    
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun StatusFilterChip(
    status: TrackerStatus?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (status) {
                TrackerStatus.PLANNED -> "Đã lên kế hoạch"
                TrackerStatus.IN_PROGRESS -> "Đang thực hiện"
                TrackerStatus.COMPLETED -> "Đã hoàn thành"
                TrackerStatus.CANCELLED -> "Đã hủy"
                TrackerStatus.ON_HOLD -> "Tạm dừng"
                TrackerStatus.OVERDUE -> "Quá hạn"
                null -> "Tất cả"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@Composable
fun EmptyState(
    message: String,
    onAddActivity: () -> Unit
) {
    val colors = AppColors()
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            Icons.Default.Timeline,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = colors.textSecondary
        )
        
        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = colors.textSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        
        Button(onClick = onAddActivity) {
            Text("Thêm hoạt động đầu tiên")
        }
    }
}
