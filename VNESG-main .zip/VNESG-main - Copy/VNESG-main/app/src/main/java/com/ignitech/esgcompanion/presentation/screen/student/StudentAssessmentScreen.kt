package com.ignitech.esgcompanion.presentation.screen.student

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.ignitech.esgcompanion.domain.entity.*
import com.ignitech.esgcompanion.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAssessmentScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<QuizCategory?>(null) }
    
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Kiểm tra kiến thức ESG",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "🎓 Kiểm tra kiến thức ESG",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Thử thách bản thân với các bài kiểm tra về ESG và phát triển bền vững",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
            
            // Category Selection
            item {
                Text(
                    text = "Chọn chủ đề",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuizCategory.values().forEach { category ->
                        CategoryChip(
                            category = category,
                            isSelected = selectedCategory == category,
                            onClick = { selectedCategory = category }
                        )
                    }
                }
            }
            
            // Quiz List
            if (selectedCategory != null) {
                item {
                    Text(
                        text = "Bài kiểm tra ${selectedCategory?.displayName}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                items(getQuizzesForCategory(selectedCategory!!)) { quiz ->
                    QuizCard(
                        quiz = quiz,
                        onClick = { 
                            // TODO: Navigate to quiz screen
                            // navController.navigate("quiz/${quiz.id}")
                        }
                    )
                }
            } else {
                // Show all quizzes grouped by category
                QuizCategory.values().forEach { category ->
                    item {
                        CategorySection(
                            category = category,
                            quizzes = getQuizzesForCategory(category),
                            navController = navController
                        )
                    }
                }
            }
            
            // Recent Attempts
            item {
                Text(
                    text = "Lần thử gần đây",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            items(getRecentAttempts()) { attempt ->
                AttemptCard(
                    attempt = attempt,
                    onRetake = { 
                        // TODO: Navigate to quiz screen
                        // navController.navigate("quiz/${attempt.id}")
                    }
                )
            }
            
            // Achievement Card
            item {
                AchievementCard()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryChip(
    category: QuizCategory,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        onClick = onClick,
        label = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(category.icon)
                Text(category.displayName)
            }
        },
        selected = isSelected,
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = category.color.copy(alpha = 0.2f),
            selectedLabelColor = category.color
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizCard(
    quiz: Quiz,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = quiz.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = quiz.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = quiz.category.color.copy(alpha = 0.1f)
                    )
                ) {
                    Text(
                        text = quiz.category.displayName,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = quiz.category.color
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    InfoItem(
                        icon = Icons.Default.Quiz,
                        text = "${quiz.questionCount} câu hỏi"
                    )
                    InfoItem(
                        icon = Icons.Default.Schedule,
                        text = "${quiz.timeLimit} phút"
                    )
                }
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (quiz.bestScore != null) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = ESGSuccess.copy(alpha = 0.1f)
                            )
                        ) {
                            Text(
                                text = "Điểm cao: ${quiz.bestScore}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = ESGSuccess
                            )
                        }
                    }
                    
                    Button(onClick = onClick) {
                        Text("Bắt đầu")
                    }
                }
            }
        }
    }
}

@Composable
fun InfoItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CategorySection(
    category: QuizCategory,
    quizzes: List<Quiz>,
    navController: NavController
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = category.icon,
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    text = category.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "${quizzes.size} bài",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            quizzes.forEach { quiz ->
                QuizCard(
                    quiz = quiz,
                    onClick = { navController.navigate("quiz/${quiz.id}") }
                )
                if (quiz != quizzes.last()) {
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun AttemptCard(
    attempt: QuizAttempt,
    onRetake: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = attempt.quizTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${attempt.correctAnswers}/${attempt.totalQuestions} câu đúng",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (attempt.passed) ESGSuccess.copy(alpha = 0.1f) 
                                        else Color(0xFFFF5722).copy(alpha = 0.1f) // Màu đỏ cam warning
                    )
                ) {
                    Text(
                        text = if (attempt.passed) "Đạt" else "Chưa đạt",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (attempt.passed) ESGSuccess else Color(0xFFFF5722) // Màu đỏ cam warning
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = onRetake,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800), // Màu vàng cam
                        contentColor = Color.White // Chữ trắng
                    )
                ) {
                    Text("Làm lại")
                }
            }
        }
    }
}

@Composable
fun AchievementCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Text(
                    text = "Thành tích học tập",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                AchievementItem(
                    label = "Bài hoàn thành",
                    value = "12",
                    color = ESGSuccess
                )
                AchievementItem(
                    label = "Điểm trung bình",
                    value = "85%",
                    color = ESGInfo
                )
                AchievementItem(
                    label = "Chứng chỉ",
                    value = "3",
                    color = ESGWarning
                )
            }
        }
    }
}

@Composable
fun AchievementItem(
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

// Data classes
enum class QuizCategory(
    val displayName: String,
    val icon: String,
    val color: Color
) {
    ENVIRONMENTAL("Môi trường", "🌱", ESGSuccess),
    SOCIAL("Xã hội", "👥", ESGInfo),
    GOVERNANCE("Quản trị", "🏛️", ESGWarning),
    SUSTAINABILITY("Bền vững", "♻️", ESGSuccess)
}

data class Quiz(
    val id: String,
    val title: String,
    val description: String,
    val category: QuizCategory,
    val questionCount: Int,
    val timeLimit: Int, // in minutes
    val bestScore: Int? = null
)

// Mock data functions
private fun getQuizzesForCategory(category: QuizCategory): List<Quiz> {
    return when (category) {
        QuizCategory.ENVIRONMENTAL -> listOf(
            Quiz(
                id = "env_quiz_001",
                title = "Nguyên tắc môi trường cơ bản",
                description = "Kiểm tra kiến thức về bảo vệ môi trường và phát triển bền vững",
                category = category,
                questionCount = 20,
                timeLimit = 30,
                bestScore = 85
            ),
            Quiz(
                id = "env_quiz_002",
                title = "Quản lý chất thải",
                description = "Hiểu biết về phân loại và xử lý chất thải",
                category = category,
                questionCount = 15,
                timeLimit = 25
            )
        )
        QuizCategory.SOCIAL -> listOf(
            Quiz(
                id = "social_quiz_001",
                title = "Quyền lao động",
                description = "Kiến thức về quyền và phúc lợi người lao động",
                category = category,
                questionCount = 18,
                timeLimit = 25,
                bestScore = 92
            )
        )
        QuizCategory.GOVERNANCE -> listOf(
            Quiz(
                id = "gov_quiz_001",
                title = "Quản trị doanh nghiệp",
                description = "Hiểu biết về cơ cấu quản trị và minh bạch",
                category = category,
                questionCount = 22,
                timeLimit = 35,
                bestScore = 78
            )
        )
        QuizCategory.SUSTAINABILITY -> listOf(
            Quiz(
                id = "sustain_quiz_001",
                title = "Phát triển bền vững tổng quan",
                description = "Kiến thức tổng hợp về phát triển bền vững",
                category = category,
                questionCount = 25,
                timeLimit = 40
            )
        )
    }
}

private fun getRecentAttempts(): List<QuizAttempt> {
    return listOf(
        QuizAttempt(
            id = "attempt_001",
            userId = "academic_001",
            quizTitle = "Nguyên tắc môi trường cơ bản",
            totalQuestions = 20,
            correctAnswers = 17,
            score = 85,
            passed = true,
            completedAt = System.currentTimeMillis() - 86400000 * 2,
            answers = emptyList()
        ),
        QuizAttempt(
            id = "attempt_002",
            userId = "academic_001",
            quizTitle = "Quản trị doanh nghiệp",
            totalQuestions = 22,
            correctAnswers = 15,
            score = 68,
            passed = false,
            completedAt = System.currentTimeMillis() - 86400000 * 5,
            answers = emptyList()
        )
    )
}
