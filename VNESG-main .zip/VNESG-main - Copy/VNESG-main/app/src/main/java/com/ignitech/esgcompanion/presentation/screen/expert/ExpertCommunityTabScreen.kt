package com.ignitech.esgcompanion.presentation.screen.expert

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.presentation.viewmodel.ExpertCommunityTabViewModel
import com.ignitech.esgcompanion.utils.AppColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpertCommunityTabScreen(
    modifier: Modifier = Modifier,
    viewModel: ExpertCommunityTabViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = AppColors()

    LaunchedEffect(Unit) {
        viewModel.loadCommunityData()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.backgroundSurface),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Section
        item {
            Column {
                Text(
                    text = "Cộng đồng ESG",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "Kết nối và chia sẻ kiến thức với cộng đồng chuyên gia",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            }
        }

        // Quick Stats
        item {
            ExpertCommunityStatsSection(
                totalMembers = uiState.totalMembers,
                activeDiscussions = uiState.activeDiscussions,
                expertContributions = uiState.expertContributions,
                myPosts = uiState.myPosts
            )
        }

        // Quick Actions
        item {
            Text(
                text = "Thao tác nhanh",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(uiState.quickActions) { action ->
                    QuickActionCard(
                        action = action,
                        onClick = { viewModel.performQuickAction(action.id) }
                    )
                }
            }
        }

        // Featured Discussions
        if (uiState.featuredDiscussions.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Thảo luận nổi bật",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    
                    TextButton(onClick = { viewModel.viewAllDiscussions() }) {
                        Text("Xem tất cả")
                        Icon(Icons.Default.ArrowForward, contentDescription = null)
                    }
                }
            }
            
            items(uiState.featuredDiscussions) { discussion ->
                FeaturedDiscussionCard(
                    discussion = discussion,
                    onClick = { viewModel.openDiscussion(discussion.id) },
                    onLike = { viewModel.likeDiscussion(discussion.id) },
                    onComment = { viewModel.commentOnDiscussion(discussion.id) }
                )
            }
        }

        // Recent Discussions
        if (uiState.recentDiscussions.isNotEmpty()) {
            item {
                Text(
                    text = "Thảo luận gần đây",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            items(uiState.recentDiscussions) { discussion ->
                DiscussionCard(
                    discussion = discussion,
                    onClick = { viewModel.openDiscussion(discussion.id) },
                    onLike = { viewModel.likeDiscussion(discussion.id) },
                    onComment = { viewModel.commentOnDiscussion(discussion.id) }
                )
            }
        }

        // Expert Spotlight
        if (uiState.expertSpotlight.isNotEmpty()) {
            item {
                Text(
                    text = "Chuyên gia nổi bật",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(uiState.expertSpotlight) { expert ->
                        ExpertSpotlightCard(
                            expert = expert,
                            onClick = { viewModel.viewExpertProfile(expert.id) }
                        )
                    }
                }
            }
        }

        // Events and Webinars
        if (uiState.upcomingEvents.isNotEmpty()) {
            item {
                Text(
                    text = "Sự kiện sắp tới",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            items(uiState.upcomingEvents) { event ->
                EventCard(
                    event = event,
                    onClick = { viewModel.openEvent(event.id) },
                    onRegister = { viewModel.registerForEvent(event.id) }
                )
            }
        }
    }
}

@Composable
fun ExpertCommunityStatsSection(
    totalMembers: Int,
    activeDiscussions: Int,
    expertContributions: Int,
    myPosts: Int
) {
    val colors = AppColors()
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
        item {
            ExpertStatCard(
                title = "Thành viên",
                value = totalMembers.toString(),
                color = colors.primary
            )
        }
        
        item {
            ExpertStatCard(
                title = "Thảo luận",
                value = activeDiscussions.toString(),
                color = Color(0xFF4CAF50)
            )
        }
        
        item {
            ExpertStatCard(
                title = "Đóng góp",
                value = expertContributions.toString(),
                color = Color(0xFFFF9800)
            )
        }
        
        item {
            ExpertStatCard(
                title = "Bài viết của tôi",
                value = myPosts.toString(),
                color = Color(0xFF2196F3)
            )
        }
    }
}

@Composable
fun QuickActionCard(
    action: CommunityQuickAction,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .width(120.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = action.icon,
                contentDescription = action.title,
                tint = action.color,
                modifier = Modifier.size(32.dp)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = action.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun FeaturedDiscussionCard(
    discussion: CommunityDiscussion,
    onClick: () -> Unit,
    onLike: () -> Unit,
    onComment: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = colors.primary.copy(alpha = 0.05f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = colors.primary,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = discussion.authorName.take(1).uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Column {
                        Text(
                            text = discussion.authorName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "Chuyên gia ESG",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
                
                Surface(
                    color = colors.primary,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Nổi bật",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White
                    )
                }
            }
            
            Text(
                text = discussion.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            Text(
                text = discussion.content,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = dateFormat.format(Date(discussion.createdAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(onClick = onLike) {
                            Icon(
                                Icons.Default.ThumbUp,
                                contentDescription = "Like",
                                tint = if (discussion.isLiked) colors.primary else colors.textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = discussion.likeCount.toString(),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(onClick = onComment) {
                            Icon(
                                Icons.Default.Comment,
                                contentDescription = "Comment",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = discussion.commentCount.toString(),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DiscussionCard(
    discussion: CommunityDiscussion,
    onClick: () -> Unit,
    onLike: () -> Unit,
    onComment: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = colors.primary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = discussion.authorName.take(1).uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Column {
                        Text(
                            text = discussion.authorName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "Chuyên gia ESG",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
                
                Text(
                    text = dateFormat.format(Date(discussion.createdAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
            
            Text(
                text = discussion.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            
            Text(
                text = discussion.content,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ExpertPillarChip(pillar = discussion.pillar)
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(onClick = onLike) {
                            Icon(
                                Icons.Default.ThumbUp,
                                contentDescription = "Like",
                                tint = if (discussion.isLiked) colors.primary else colors.textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = discussion.likeCount.toString(),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(onClick = onComment) {
                            Icon(
                                Icons.Default.Comment,
                                contentDescription = "Comment",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = discussion.commentCount.toString(),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExpertSpotlightCard(
    expert: ExpertProfile,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Card(
        modifier = Modifier
            .width(150.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = colors.primary.copy(alpha = 0.1f),
                shape = RoundedCornerShape(30.dp),
                modifier = Modifier.size(60.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = expert.name.take(1).uppercase(),
                        style = MaterialTheme.typography.headlineSmall,
                        color = colors.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            Text(
                text = expert.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            
            Text(
                text = expert.specialization,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    Icons.Default.Star,
                    contentDescription = null,
                    tint = Color(0xFFFF9800),
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = String.format("%.1f", expert.rating),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
        }
    }
}

@Composable
fun EventCard(
    event: CommunityEvent,
    onClick: () -> Unit,
    onRegister: () -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        colors = CardDefaults.cardColors(containerColor = colors.backgroundSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    modifier = Modifier.weight(1f)
                )
                
                EventTypeChip(type = event.type)
            }
            
            Text(
                text = event.description,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.Schedule,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = dateFormat.format(Date(event.startTime)),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                
                Button(
                    onClick = onRegister,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
                ) {
                    Text("Đăng ký")
                }
            }
        }
    }
}


@Composable
fun EventTypeChip(type: EventType) {
    val (text, color) = when (type) {
        EventType.WEBINAR -> "Webinar" to Color(0xFF4CAF50)
        EventType.WORKSHOP -> "Workshop" to Color(0xFF2196F3)
        EventType.CONFERENCE -> "Hội thảo" to Color(0xFFFF9800)
        EventType.NETWORKING -> "Networking" to Color(0xFF9C27B0)
    }
    
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}


// Data classes
data class CommunityDiscussion(
    val id: String,
    val title: String,
    val content: String,
    val authorName: String,
    val authorId: String,
    val pillar: ESGPillar,
    val likeCount: Int,
    val commentCount: Int,
    val isLiked: Boolean = false,
    val createdAt: Long,
    val isFeatured: Boolean = false
)

data class CommunityQuickAction(
    val id: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

data class ExpertProfile(
    val id: String,
    val name: String,
    val specialization: String,
    val rating: Float,
    val contributionCount: Int
)

data class CommunityEvent(
    val id: String,
    val title: String,
    val description: String,
    val type: EventType,
    val startTime: Long,
    val duration: Int, // in minutes
    val isRegistered: Boolean = false
)

enum class EventType {
    WEBINAR, WORKSHOP, CONFERENCE, NETWORKING
}
