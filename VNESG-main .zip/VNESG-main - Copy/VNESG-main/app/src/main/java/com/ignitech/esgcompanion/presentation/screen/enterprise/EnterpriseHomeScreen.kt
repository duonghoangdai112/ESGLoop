package com.ignitech.esgcompanion.presentation.screen.enterprise

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.compose.ui.res.colorResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.domain.entity.ESGPillarInfo
import com.ignitech.esgcompanion.domain.entity.*
import com.ignitech.esgcompanion.ui.theme.*
import com.ignitech.esgcompanion.R
import com.ignitech.esgcompanion.utils.AppColors
import com.ignitech.esgcompanion.presentation.screen.LearningHubScreen
import com.ignitech.esgcompanion.presentation.screen.enterprise.EnterpriseTrackerScreen
import com.ignitech.esgcompanion.presentation.screen.enterprise.EnterpriseReportScreen
import com.ignitech.esgcompanion.presentation.viewmodel.EnterpriseHomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnterpriseHomeScreen(
    navController: NavHostController
) {
    val colors = AppColors()
    var selectedTab by remember { mutableStateOf(0) }
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Trang chủ") },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Assessment, contentDescription = "Assessment") },
                    label = { Text("Đánh giá") },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.School, contentDescription = "Learning") },
                    label = { Text("Học liệu") },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Timeline, contentDescription = "Tracker") },
                    label = { Text("Theo dõi") },
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Description, contentDescription = "Reports") },
                    label = { Text("Báo cáo") },
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 }
                )
            }
        }
    ) { paddingValues ->
        when (selectedTab) {
            0 -> HomeContent(navController = navController, modifier = Modifier.padding(paddingValues))
            1 -> EnterpriseAssessmentScreen(navController = navController, modifier = Modifier.padding(paddingValues))
            2 -> LearningHubScreen(modifier = Modifier.padding(paddingValues))
            3 -> EnterpriseTrackerScreen(navController = navController, modifier = Modifier.padding(paddingValues))
            4 -> EnterpriseReportScreen(navController = navController, modifier = Modifier.padding(paddingValues))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeContent(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: EnterpriseHomeViewModel = hiltViewModel()
) {
    val colors = AppColors()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    LaunchedEffect(Unit) {
        viewModel.loadESGData()
    }
    Column(
        modifier = modifier.fillMaxSize()
    ) {
        // Header
        TopAppBar(
            title = { 
                Column {
                    Text(
                        text = "ESG Companion",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Công ty TNHH Xây Dựng Xanh",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textOnSurfaceVariant
                    )
                }
            },
            actions = {
                IconButton(onClick = { navController.navigate("settings") }) {
                    Icon(Icons.Default.Person, contentDescription = "Profile")
                }
            }
        )
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // ESG Score Overview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = colors.primary.copy(alpha = 0.1f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "Điểm ESG Tổng Quan",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${uiState.esgScoreData.overallScore}/${uiState.esgScoreData.maxScore}",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = colors.primary
                        )
                        StatusTag(
                            text = when {
                                uiState.esgScoreData.overallScore >= 90 -> "Xuất sắc"
                                uiState.esgScoreData.overallScore >= 80 -> "Tốt"
                                uiState.esgScoreData.overallScore >= 70 -> "Khá"
                                uiState.esgScoreData.overallScore >= 60 -> "Trung bình"
                                else -> "Cần cải thiện"
                            },
                            color = when {
                                uiState.esgScoreData.overallScore >= 90 -> ESGSuccess
                                uiState.esgScoreData.overallScore >= 80 -> Color(0xFF4CAF50)
                                uiState.esgScoreData.overallScore >= 70 -> Color(0xFFFF9800)
                                uiState.esgScoreData.overallScore >= 60 -> Color(0xFFFF5722)
                                else -> Color(0xFFF44336)
                            }
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = uiState.esgScoreData.lastUpdated,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textOnSurfaceVariant
                    )
                }
            }
        }
        
        // ESG Pillars
        item {
            Text(
                text = "3 Trụ Cột ESG",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(ESGPillarInfo.ALL_PILLARS) { pillarInfo ->
                    ESGPillarCard(
                        pillarInfo = pillarInfo,
                        score = when (pillarInfo.pillar) {
                            ESGPillar.ENVIRONMENTAL -> uiState.esgScoreData.environmentalScore
                            ESGPillar.SOCIAL -> uiState.esgScoreData.socialScore
                            ESGPillar.GOVERNANCE -> uiState.esgScoreData.governanceScore
                        }
                    )
                }
            }
        }
        
        // Quick Actions
        item {
            Text(
                text = "Thao Tác Nhanh",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                EnterpriseQuickActionCard(
                    title = "Đánh giá mới",
                    icon = Icons.Default.Add,
                    onClick = { 
                        // Navigate to assessment with proper navigation stack
                        navController.navigate("enterprise_assessment") {
                            popUpTo("enterprise_home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
                EnterpriseQuickActionCard(
                    title = "Tạo báo cáo",
                    icon = Icons.Default.Description,
                    onClick = { /* Generate report */ },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        
        // Recent Activities
        item {
            Text(
                text = "Hoạt Động Gần Đây",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        items(3) { index ->
            ActivityCard(
                title = when (index) {
                    0 -> "Hoàn thành đánh giá ESG Q4 2024"
                    1 -> "Tạo báo cáo bền vững"
                    2 -> "Cập nhật chính sách môi trường"
                    else -> "Hoạt động khác"
                },
                time = when (index) {
                    0 -> "3 ngày trước"
                    1 -> "1 tuần trước"
                    2 -> "2 tuần trước"
                    else -> "Khác"
                },
                icon = when (index) {
                    0 -> Icons.Default.Assessment
                    1 -> Icons.Default.Description
                    2 -> Icons.Default.Update
                    else -> Icons.Default.Info
                }
            )
        }
        
        // Loading state
        if (uiState.isLoading) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = colors.backgroundSurface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = colors.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Đang tải dữ liệu ESG...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
        
        // Error state
        uiState.error?.let { error ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFEBEE)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = "Error",
                            tint = Color(0xFFD32F2F),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Lỗi tải dữ liệu",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD32F2F)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD32F2F),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.refreshData() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD32F2F)
                            )
                        ) {
                            Text("Thử lại", color = Color.White)
                        }
                    }
                }
            }
        }
        }
    }
}


@Composable
fun StatusTag(
    text: String,
    color: Color
) {
    Surface(
        modifier = Modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        color = color
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = Color.White,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun LearningContent(modifier: Modifier = Modifier) {
    val colors = AppColors()
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Học liệu ESG",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Khóa học ESG cơ bản",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tìm hiểu về các nguyên tắc ESG và cách áp dụng trong doanh nghiệp",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = 0.65f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "65% hoàn thành",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.primary
                    )
                }
            }
        }
    }
}



@Composable
fun ESGPillarCard(
    pillarInfo: ESGPillarInfo,
    score: Int
) {
    Card(
        modifier = Modifier
            .width(120.dp)
            .height(140.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(android.graphics.Color.parseColor(pillarInfo.color))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = pillarInfo.icon,
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = pillarInfo.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$score/100",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnterpriseQuickActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AppColors()
    Card(
        modifier = modifier
            .height(100.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(28.dp),
                tint = colors.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ActivityCard(
    title: String,
    time: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    val colors = AppColors()
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = time,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textOnSurfaceVariant
                )
            }
        }
        }
}