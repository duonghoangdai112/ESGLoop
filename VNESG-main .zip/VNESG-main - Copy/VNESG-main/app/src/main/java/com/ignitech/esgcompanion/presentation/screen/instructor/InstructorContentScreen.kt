package com.ignitech.esgcompanion.presentation.screen.instructor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ignitech.esgcompanion.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorContentScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Tạo nội dung học tập",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
        
        // Quick Actions
        item {
            Text(
                text = "Thao tác nhanh",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ContentActionCard(
                    title = "Tạo bài giảng",
                    icon = Icons.Default.VideoLibrary,
                    description = "Soạn thảo bài giảng mới",
                    onClick = { navController.navigate("create_lesson") },
                    modifier = Modifier.weight(1f)
                )
                ContentActionCard(
                    title = "Tạo bài tập",
                    icon = Icons.Default.Assignment,
                    description = "Tạo bài tập cho học sinh",
                    onClick = { navController.navigate("create_assignment") },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ContentActionCard(
                    title = "Tạo câu hỏi",
                    icon = Icons.Default.Quiz,
                    description = "Thêm câu hỏi kiểm tra",
                    onClick = { navController.navigate("create_question") },
                    modifier = Modifier.weight(1f)
                )
                ContentActionCard(
                    title = "Upload tài liệu",
                    icon = Icons.Default.Upload,
                    description = "Tải lên tài liệu học tập",
                    onClick = { /* Upload document */ },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        
        // Recent Content
        item {
            Text(
                text = "Nội dung gần đây",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        items(getRecentContent()) { content ->
            ContentCard(content = content)
        }
        
        // Content Categories
        item {
            Text(
                text = "Danh mục nội dung",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(getContentCategories()) { category ->
                    CategoryCard(category = category)
                }
            }
        }
        
        // Templates
        item {
            Text(
                text = "Mẫu nội dung",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        items(getContentTemplates()) { template ->
            TemplateCard(template = template)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(32.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ContentCard(
    content: ContentItem
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = content.icon,
                contentDescription = null,
                tint = content.color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = content.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = content.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = content.className,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = content.date,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun CategoryCard(
    category: ContentCategory
) {
    Card(
        modifier = Modifier.width(120.dp),
        colors = CardDefaults.cardColors(
            containerColor = category.color.copy(alpha = 0.1f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = category.icon,
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = category.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = category.color
            )
            Text(
                text = "${category.count} mục",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun TemplateCard(
    template: ContentTemplate
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = template.icon,
                    contentDescription = null,
                    tint = template.color,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = template.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = template.difficulty,
                    style = MaterialTheme.typography.bodySmall,
                    color = template.color
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = template.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Thời gian: ${template.duration}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { /* Use template */ },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = template.color,
                        contentColor = Color.White
                    )
                ) {
                    Text("Sử dụng")
                }
            }
        }
    }
}

// Data classes
data class ContentItem(
    val title: String,
    val description: String,
    val className: String,
    val date: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

data class ContentCategory(
    val name: String,
    val icon: String,
    val count: Int,
    val color: Color
)

data class ContentTemplate(
    val name: String,
    val description: String,
    val difficulty: String,
    val duration: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

// Mock data functions
private fun getRecentContent(): List<ContentItem> {
    return listOf(
        ContentItem(
            title = "Bài giảng: Nguyên tắc ESG cơ bản",
            description = "Giới thiệu về các nguyên tắc ESG trong doanh nghiệp",
            className = "ESG-101",
            date = "2 ngày trước",
            icon = Icons.Default.VideoLibrary,
            color = ESGInfo
        ),
        ContentItem(
            title = "Bài tập: Phân tích báo cáo bền vững",
            description = "Học sinh phân tích báo cáo ESG của các công ty",
            className = "ESG-102",
            date = "3 ngày trước",
            icon = Icons.Default.Assignment,
            color = ESGWarning
        ),
        ContentItem(
            title = "Câu hỏi: Quản trị doanh nghiệp",
            description = "Bộ câu hỏi trắc nghiệm về quản trị",
            className = "ESG-201",
            date = "1 tuần trước",
            icon = Icons.Default.Quiz,
            color = ESGSuccess
        )
    )
}

private fun getContentCategories(): List<ContentCategory> {
    return listOf(
        ContentCategory(
            name = "Bài giảng",
            icon = "📚",
            count = 12,
            color = ESGInfo
        ),
        ContentCategory(
            name = "Bài tập",
            icon = "📝",
            count = 8,
            color = ESGWarning
        ),
        ContentCategory(
            name = "Câu hỏi",
            icon = "❓",
            count = 25,
            color = ESGSuccess
        ),
        ContentCategory(
            name = "Tài liệu",
            icon = "📄",
            count = 15,
            color = Color(0xFFFF9800)
        )
    )
}

private fun getContentTemplates(): List<ContentTemplate> {
    return listOf(
        ContentTemplate(
            name = "Mẫu bài giảng ESG cơ bản",
            description = "Template chuẩn cho bài giảng về ESG với cấu trúc rõ ràng",
            difficulty = "Cơ bản",
            duration = "45 phút",
            icon = Icons.Default.VideoLibrary,
            color = ESGInfo
        ),
        ContentTemplate(
            name = "Mẫu bài tập nhóm",
            description = "Template cho bài tập nhóm về phân tích ESG",
            difficulty = "Trung bình",
            duration = "2 tuần",
            icon = Icons.Default.Group,
            color = ESGWarning
        ),
        ContentTemplate(
            name = "Mẫu câu hỏi trắc nghiệm",
            description = "Bộ câu hỏi mẫu cho kiểm tra kiến thức ESG",
            difficulty = "Cơ bản",
            duration = "30 phút",
            icon = Icons.Default.Quiz,
            color = ESGSuccess
        )
    )
}
