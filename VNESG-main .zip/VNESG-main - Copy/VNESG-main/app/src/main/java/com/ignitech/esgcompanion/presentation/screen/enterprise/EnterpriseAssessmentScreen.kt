package com.ignitech.esgcompanion.presentation.screen.enterprise

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.ui.draw.scale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.colorResource
import com.ignitech.esgcompanion.domain.entity.*
import com.ignitech.esgcompanion.ui.theme.*
import com.ignitech.esgcompanion.R
import com.ignitech.esgcompanion.utils.AppColors
import com.ignitech.esgcompanion.utils.AppColorsData
import com.ignitech.esgcompanion.data.local.entity.ESGAssessmentEntity

private data class StatusData(
    val text: String,
    val backgroundColor: androidx.compose.ui.graphics.Color,
    val textColor: androidx.compose.ui.graphics.Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnterpriseAssessmentScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    val colors = AppColors()
    var selectedPillar by remember { mutableStateOf<ESGPillar?>(null) }
    
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
            // Pillar Selection
            item {
                Text(
                    text = "Chọn trụ cột ESG",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            item {
                PillarTabRow(
                    selectedPillar = selectedPillar,
                    onPillarSelected = { selectedPillar = it }
                )
            }
            
            // Start New Assessment Button
            if (selectedPillar != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = colors.primary.copy(alpha = 0.1f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "Bắt đầu đánh giá mới",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Tạo đánh giá ${selectedPillar?.let { getPillarName(it) }} cho doanh nghiệp của bạn",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = { 
                                    // Navigate to assessment form screen with proper navigation stack
                                    navController.navigate("assessment_form/${selectedPillar?.name}") {
                                        popUpTo("enterprise_home") { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Bắt đầu đánh giá")
                            }
                        }
                    }
                }
            }
            
            // Assessment Cards
            if (selectedPillar != null) {
                item {
                    Text(
                        text = "Bài đánh giá ${selectedPillar?.let { getPillarName(it) }}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                items(getAssessmentsForPillar(selectedPillar!!)) { assessment ->
                    AssessmentCard(
                        assessment = assessment,
                        onClick = { 
                            // TODO: Navigate to assessment detail screen
                            // navController.navigate("assessment_detail/${assessment.id}")
                        }
                    )
                }
            } else {
                // Start New Assessment Button (All Pillars)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = colors.primary.copy(alpha = 0.1f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "Bắt đầu đánh giá mới",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Chọn một trụ cột ESG ở trên để bắt đầu đánh giá",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Hoặc xem các đánh giá hiện có bên dưới",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textOnSurfaceVariant
                            )
                        }
                    }
                }
                
                // Show all assessments grouped by pillar
                item {
                    Text(
                        text = "Tất cả bài đánh giá",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                ESGPillar.values().forEach { pillar ->
                    item {
                        PillarSection(
                            pillar = pillar,
                            assessments = getAssessmentsForPillar(pillar),
                            navController = navController
                        )
                    }
                }
            }
            
            // Assessment History Section
            item {
                AssessmentHistorySection()
            }
            
            // Overall Progress
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = colors.primary.copy(alpha = 0.1f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Tiến độ tổng thể",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        val overallProgress = getOverallProgress()
                        ProgressIndicator(
                            label = "Hoàn thành ESG",
                            progress = overallProgress,
                            color = colors.primary
                        )
                    }
                }
            }
        }
}

@Composable
fun PillarTabRow(
    selectedPillar: ESGPillar?,
    onPillarSelected: (ESGPillar?) -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.backgroundSurfaceVariant.copy(alpha = 0.3f),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            PillarTab(
                pillar = ESGPillar.ENVIRONMENTAL,
                label = "Môi trường",
                icon = "🌱",
                color = colors.pillarEnvironmental,
                isSelected = selectedPillar == ESGPillar.ENVIRONMENTAL,
                onClick = { onPillarSelected(ESGPillar.ENVIRONMENTAL) },
                modifier = Modifier.weight(1f)
            )
            
            PillarTab(
                pillar = ESGPillar.SOCIAL,
                label = "Xã hội", 
                icon = "👥",
                color = colors.pillarSocial,
                isSelected = selectedPillar == ESGPillar.SOCIAL,
                onClick = { onPillarSelected(ESGPillar.SOCIAL) },
                modifier = Modifier.weight(1f)
            )
            
            PillarTab(
                pillar = ESGPillar.GOVERNANCE,
                label = "Quản trị",
                icon = "🏛️",
                color = colors.pillarGovernance,
                isSelected = selectedPillar == ESGPillar.GOVERNANCE,
                onClick = { onPillarSelected(ESGPillar.GOVERNANCE) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun PillarTab(
    pillar: ESGPillar,
    label: String,
    icon: String,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AppColors()
    val animatedAlpha by animateFloatAsState(
        targetValue = if (isSelected) 0.2f else 0f,
        animationSpec = tween(200)
    )
    
    val animatedScale by animateFloatAsState(
        targetValue = if (isSelected) 1.02f else 1f,
        animationSpec = tween(200)
    )
    
    Box(
        modifier = modifier
            .padding(horizontal = 1.dp)
            .scale(animatedScale)
            .background(
                color = color.copy(alpha = animatedAlpha),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Text(
                text = icon,
                fontSize = if (isSelected) 18.sp else 16.sp
            )
            
            Spacer(modifier = Modifier.width(4.dp))
            
            // Label
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = if (isSelected) color else colors.textOnSurfaceVariant,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
            
            // Progress dot (if selected)
            if (isSelected) {
                Spacer(modifier = Modifier.width(3.dp))
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .background(
                            color = color,
                            shape = androidx.compose.foundation.shape.CircleShape
                        )
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssessmentCard(
    assessment: ESGAssessment,
    onClick: () -> Unit
) {
    val colors = AppColors()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = assessment.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = assessment.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                StatusChip(status = assessment.status)
            }
            
            if (assessment.status == AssessmentStatus.COMPLETED) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Điểm số: ${assessment.totalScore}/${assessment.maxScore}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = colors.primary
                    )
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(onClick = { /* Share */ }) {
                            Icon(Icons.Default.Share, contentDescription = "Chia sẻ")
                        }
                        IconButton(onClick = { /* Download */ }) {
                            Icon(Icons.Default.Download, contentDescription = "Tải xuống")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusChip(status: AssessmentStatus) {
    val colors = AppColors()
    val statusData = when (status) {
        AssessmentStatus.NOT_STARTED -> 
            StatusData(
                "Chưa làm", 
                colors.statusNotStarted.copy(alpha = 0.1f), 
                colors.statusNotStarted, 
                Icons.Default.Schedule
            )
        AssessmentStatus.IN_PROGRESS -> 
            StatusData(
                "Đang làm", 
                colors.statusInProgress.copy(alpha = 0.15f), 
                colors.statusInProgress, 
                Icons.Default.AccessTime
            )
        AssessmentStatus.COMPLETED -> 
            StatusData(
                "Hoàn thành", 
                colors.statusCompleted.copy(alpha = 0.15f), 
                colors.statusCompleted, 
                Icons.Default.CheckCircle
            )
        AssessmentStatus.DRAFT -> 
            StatusData(
                "Bản nháp", 
                colors.statusInProgress.copy(alpha = 0.1f), 
                colors.statusInProgress, 
                Icons.Default.Edit
            )
    }
    
    val (text, backgroundColor, textColor, icon) = statusData
    
    Surface(
        modifier = Modifier,
        color = backgroundColor,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                modifier = Modifier.size(12.dp),
                tint = textColor
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun PillarSection(
    pillar: ESGPillar,
    assessments: List<ESGAssessment>,
    navController: NavController
) {
    val colors = AppColors()
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = getPillarIcon(pillar),
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    text = getPillarName(pillar),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "${assessments.count { it.status == AssessmentStatus.COMPLETED }}/${assessments.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.primary
                )
            }
            
            Spacer(modifier = Modifier.height(6.dp))
            
            assessments.forEach { assessment ->
                AssessmentCard(
                    assessment = assessment,
                    onClick = { 
                        // TODO: Navigate to assessment detail screen
                        // navController.navigate("assessment_detail/${assessment.id}")
                    }
                )
                if (assessment != assessments.last()) {
                    Spacer(modifier = Modifier.height(3.dp))
                }
            }
        }
    }
}

@Composable
fun ProgressIndicator(
    label: String,
    progress: Float,
    color: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "${(progress * 100).toInt()}%",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = color
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier.fillMaxWidth(),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

// Mock data functions
private fun getAssessmentsForPillar(pillar: ESGPillar): List<ESGAssessment> {
    return when (pillar) {
        ESGPillar.ENVIRONMENTAL -> listOf(
            ESGAssessment(
                id = "env_001",
                userId = "enterprise_001",
                title = "Đánh giá tác động môi trường",
                description = "Đánh giá tác động môi trường của hoạt động sản xuất",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.COMPLETED,
                totalScore = 85,
                maxScore = 100,
                completedAt = System.currentTimeMillis() - 86400000 * 7,
                createdAt = System.currentTimeMillis() - 86400000 * 10,
                answers = emptyList()
            ),
            ESGAssessment(
                id = "env_002",
                userId = "enterprise_001",
                title = "Quản lý chất thải",
                description = "Đánh giá hệ thống quản lý chất thải và tái chế",
                pillar = ESGPillar.ENVIRONMENTAL,
                status = AssessmentStatus.IN_PROGRESS,
                totalScore = 60,
                maxScore = 100,
                completedAt = null,
                createdAt = System.currentTimeMillis() - 86400000 * 5,
                answers = emptyList()
            )
        )
        ESGPillar.SOCIAL -> listOf(
            ESGAssessment(
                id = "social_001",
                userId = "enterprise_001",
                title = "Quyền lao động",
                description = "Đánh giá về quyền và phúc lợi của người lao động",
                pillar = ESGPillar.SOCIAL,
                status = AssessmentStatus.NOT_STARTED,
                totalScore = 0,
                maxScore = 100,
                completedAt = null,
                createdAt = System.currentTimeMillis() - 86400000 * 3,
                answers = emptyList()
            )
        )
        ESGPillar.GOVERNANCE -> listOf(
            ESGAssessment(
                id = "gov_001",
                userId = "enterprise_001",
                title = "Quản trị doanh nghiệp",
                description = "Đánh giá cơ cấu quản trị và minh bạch tài chính",
                pillar = ESGPillar.GOVERNANCE,
                status = AssessmentStatus.COMPLETED,
                totalScore = 78,
                maxScore = 100,
                completedAt = System.currentTimeMillis() - 86400000 * 14,
                createdAt = System.currentTimeMillis() - 86400000 * 20,
                answers = emptyList()
            )
        )
    }
}

private fun getOverallProgress(): Float {
    return 0.6f // 60% completed
}

private fun getPillarName(pillar: ESGPillar): String {
    return when (pillar) {
        ESGPillar.ENVIRONMENTAL -> "Môi trường"
        ESGPillar.SOCIAL -> "Xã hội"
        ESGPillar.GOVERNANCE -> "Quản trị"
    }
}

private fun getPillarIcon(pillar: ESGPillar): String {
    return when (pillar) {
        ESGPillar.ENVIRONMENTAL -> "🌱"
        ESGPillar.SOCIAL -> "👥"
        ESGPillar.GOVERNANCE -> "🏛️"
    }
}

@Composable
fun AssessmentHistorySection() {
    val colors = AppColors()
    var selectedYear by remember { mutableStateOf(2024) }
    
    // Mock data for assessment history
    val allAssessmentHistory = listOf(
        "Q4-2023" to listOf(78, 82, 85),
        "Q1-2024" to listOf(85, 88, 90),
        "Q2-2024" to listOf(92, 85, 87),
        "Q3-2024" to listOf(88, 91, 89),
        "Q4-2024" to listOf(0, 0, 0) // Current quarter
    )
    
    // Filter data based on selected year
    val assessmentHistory = allAssessmentHistory.filter { (period, _) ->
        val year = period.split("-")[1].toInt()
        year == selectedYear
    }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = colors.primary.copy(alpha = 0.05f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Lịch sử đánh giá",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            // Year selector
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf(2023, 2024)) { year ->
                    YearChip(
                        year = year,
                        isSelected = selectedYear == year,
                        onClick = { 
                            selectedYear = year
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            
            // Timeline view
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                assessmentHistory.forEach { (period, scores) ->
                    PeriodCard(
                        period = period,
                        scores = scores,
                        colors = colors
                    )
                }
            }
        }
    }
}

@Composable
fun YearChip(
    year: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple()
        ) { onClick() },
        color = if (isSelected) colors.primary else Color.Transparent,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = year.toString(),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}


@Composable
fun PeriodCard(
    period: String,
    scores: List<Int>,
    colors: AppColorsData
) {
    val completedCount = scores.count { it > 0 }
    val totalCount = scores.size
    val progress = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f
    val averageScore = if (scores.any { it > 0 }) scores.filter { it > 0 }.average().toInt() else 0
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = period,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (averageScore > 0) "Điểm TB: $averageScore" else "Chưa đánh giá",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.primary
                )
            }
            
            Spacer(modifier = Modifier.height(6.dp))
            
            // Progress bar
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth(),
                color = colors.primary,
                trackColor = colors.primary.copy(alpha = 0.2f)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Pillar breakdown
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ESGPillar.values().forEachIndexed { index, pillar ->
                    PillarIndicator(
                        pillar = pillar,
                        score = scores.getOrNull(index) ?: 0,
                        colors = colors
                    )
                }
            }
        }
    }
}

@Composable
fun PillarIndicator(
    pillar: ESGPillar,
    score: Int,
    colors: AppColorsData
) {
    val pillarColor = when (pillar) {
        ESGPillar.ENVIRONMENTAL -> colors.pillarEnvironmental
        ESGPillar.SOCIAL -> colors.pillarSocial
        ESGPillar.GOVERNANCE -> colors.pillarGovernance
    }
    
    val scorePercentage = if (score > 0) score.toFloat() / 100f else 0f
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = getPillarIcon(pillar),
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = if (score > 0) "$score%" else "-",
            style = MaterialTheme.typography.labelSmall,
            color = if (score > 0) pillarColor else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
