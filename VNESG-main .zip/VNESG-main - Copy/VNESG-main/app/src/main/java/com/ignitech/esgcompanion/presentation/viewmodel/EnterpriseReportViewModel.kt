package com.ignitech.esgcompanion.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ignitech.esgcompanion.data.repository.ReportRepository
import com.ignitech.esgcompanion.domain.entity.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import java.util.*
import javax.inject.Inject

data class EnterpriseReportUiState(
    val isLoading: Boolean = false,
    val totalReports: Int = 0,
    val draftReports: Int = 0,
    val publishedReports: Int = 0,
    val recentReports: List<ReportSummary> = emptyList(),
    val selectedTemplate: ReportStandard? = null,
    val error: String? = null
)

@HiltViewModel
class EnterpriseReportViewModel @Inject constructor(
    private val reportRepository: ReportRepository,
    private val userDao: com.ignitech.esgcompanion.data.local.dao.UserDao
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(EnterpriseReportUiState())
    val uiState: StateFlow<EnterpriseReportUiState> = _uiState.asStateFlow()
    
    private val _navigateToReportBuilder = MutableStateFlow<ReportStandard?>(null)
    val navigateToReportBuilder: StateFlow<ReportStandard?> = _navigateToReportBuilder.asStateFlow()
    
    private val _navigateToReportViewer = MutableStateFlow<String?>(null)
    val navigateToReportViewer: StateFlow<String?> = _navigateToReportViewer.asStateFlow()
    
    private var userId: String? = null
    
    fun loadReportData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            try {
                // Get current user ID from database
                val currentUser = userDao.getCurrentUser()
                if (currentUser == null) {
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            error = "Chưa đăng nhập. Vui lòng đăng nhập lại."
                        )
                    }
                    return@launch
                }
                
                userId = currentUser.id
                
                // Load data in parallel for better performance
                val totalReportsDeferred = async { reportRepository.getTotalReportsCount(userId!!) }
                val draftReportsDeferred = async { reportRepository.getDraftReportsCount(userId!!) }
                val publishedReportsDeferred = async { reportRepository.getPublishedReportsCount(userId!!) }
                val recentReportsDeferred = async { 
                    reportRepository.getAllReports(userId!!).first().take(5)
                }
                
                val totalReports = totalReportsDeferred.await()
                val draftReports = draftReportsDeferred.await()
                val publishedReports = publishedReportsDeferred.await()
                val recentReports = recentReportsDeferred.await()
                
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        totalReports = totalReports,
                        draftReports = draftReports,
                        publishedReports = publishedReports,
                        recentReports = recentReports
                    )
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = when (e) {
                            is java.net.UnknownHostException -> "Không có kết nối mạng"
                            is java.util.concurrent.TimeoutException -> "Hết thời gian chờ"
                            else -> e.message ?: "Có lỗi xảy ra khi tải dữ liệu"
                        }
                    )
                }
            }
        }
    }
    
    fun selectTemplate(template: ReportStandard) {
        _uiState.update { it.copy(selectedTemplate = template) }
        _navigateToReportBuilder.value = template
    }
    
    fun showCreateReport() {
        _navigateToReportBuilder.value = ReportStandard.CUSTOM
    }
    
    fun onNavigateToReportBuilder() {
        _navigateToReportBuilder.value = null
    }
    
    fun openReport(reportId: String) {
        _navigateToReportViewer.value = reportId
    }
    
    fun onNavigateToReportViewer() {
        _navigateToReportViewer.value = null
    }
    
    fun shareReport(reportId: String) {
        // TODO: Implement share functionality
    }
    
    fun deleteReport(reportId: String) {
        viewModelScope.launch {
            try {
                if (userId == null) {
                    _uiState.update { 
                        it.copy(
                            error = "Chưa đăng nhập. Vui lòng đăng nhập lại."
                        )
                    }
                    return@launch
                }
                
                reportRepository.deleteReport(reportId)
                loadReportData() // Refresh data after deletion
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        error = e.message ?: "Có lỗi xảy ra khi xóa báo cáo"
                    )
                }
            }
        }
    }
    
}
