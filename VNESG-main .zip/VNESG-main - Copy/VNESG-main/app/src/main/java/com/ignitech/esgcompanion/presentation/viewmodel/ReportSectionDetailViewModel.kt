package com.ignitech.esgcompanion.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ignitech.esgcompanion.data.repository.ReportRepository
import com.ignitech.esgcompanion.domain.entity.*
import com.ignitech.esgcompanion.presentation.screen.enterprise.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ReportSectionDetailUiState(
    val isLoading: Boolean = false,
    val section: ReportSection? = null,
    val formFields: List<FormField> = emptyList(),
    val completedFields: Int = 0,
    val error: String? = null
)

@HiltViewModel
class ReportSectionDetailViewModel @Inject constructor(
    private val reportRepository: ReportRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(ReportSectionDetailUiState())
    val uiState: StateFlow<ReportSectionDetailUiState> = _uiState.asStateFlow()
    
    fun loadSection(sectionId: String, template: ReportStandard) {
        viewModelScope.launch {
            _uiState.update { 
                it.copy(
                    isLoading = true,
                    error = null
                ) 
            }
            
            try {
                val section = getSectionById(sectionId, template)
                val formFields = generateFormFields(sectionId, template)
                
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        section = section,
                        formFields = formFields,
                        completedFields = formFields.count { field -> field.value.isNotEmpty() }
                    ) 
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = e.message ?: "Có lỗi xảy ra khi tải phần báo cáo"
                    ) 
                }
            }
        }
    }
    
    fun updateFieldValue(fieldId: String, value: String) {
        _uiState.update { currentState ->
            val updatedFields = currentState.formFields.map { field ->
                if (field.id == fieldId) {
                    field.copy(value = value)
                } else {
                    field
                }
            }
            
            currentState.copy(
                formFields = updatedFields,
                completedFields = updatedFields.count { field -> field.value.isNotEmpty() }
            )
        }
    }
    
    fun saveSection() {
        viewModelScope.launch {
            try {
                val currentState = _uiState.value
                val sectionData = currentState.formFields.associate { field ->
                    field.id to field.value
                }
                
                // Get reportId from current template context
                val reportId = getCurrentReportId()
                if (reportId != null && currentState.section != null) {
                    reportRepository.saveSectionData(
                        reportId = reportId,
                        sectionId = currentState.section.id,
                        title = currentState.section.title,
                        description = currentState.section.description,
                        data = sectionData
                    )
                }
                
                _uiState.update { it.copy(error = "Đã lưu thành công") }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        error = e.message ?: "Có lỗi xảy ra khi lưu dữ liệu"
                    ) 
                }
            }
        }
    }
    
    fun saveDraft() {
        saveSection()
    }
    
    fun completeSection() {
        viewModelScope.launch {
            try {
                val currentState = _uiState.value
                val sectionData = currentState.formFields.associate { field ->
                    field.id to field.value
                }
                
                // Save section data first
                val reportId = getCurrentReportId()
                if (reportId != null && currentState.section != null) {
                    reportRepository.saveSectionData(
                        reportId = reportId,
                        sectionId = currentState.section.id,
                        title = currentState.section.title,
                        description = currentState.section.description,
                        data = sectionData
                    )
                    
                    // Mark section as completed
                    reportRepository.completeSection(reportId, currentState.section.id)
                }
                
                _uiState.update { it.copy(error = "Đã hoàn thành phần báo cáo") }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        error = e.message ?: "Có lỗi xảy ra khi hoàn thành phần báo cáo"
                    ) 
                }
            }
        }
    }
    
    private fun getCurrentReportId(): String? {
        // This should be passed from the parent screen or stored in state
        // For now, we'll generate a temporary ID
        return "temp_report_${System.currentTimeMillis()}"
    }
    
    private fun getSectionById(sectionId: String, template: ReportStandard): ReportSection? {
        return getTemplateSections(template).find { it.id == sectionId }
    }
    
    private fun generateFormFields(sectionId: String, template: ReportStandard): List<FormField> {
        return when (template) {
            ReportStandard.GRI -> getGriFormFields(sectionId)
            ReportStandard.SASB -> getSasbFormFields(sectionId)
            ReportStandard.VN_ENVIRONMENT -> getVnFormFields(sectionId)
            ReportStandard.CUSTOM -> getCustomFormFields(sectionId)
        }
    }
    
    private fun getGriFormFields(sectionId: String): List<FormField> {
        return when (sectionId) {
            "1" -> listOf( // Thông tin tổng quan
                FormField("company_name", "Tên công ty", "Tên đầy đủ của công ty", "Nhập tên công ty", FieldType.TEXT, isRequired = true),
                FormField("reporting_period", "Kỳ báo cáo", "Thời gian báo cáo", "Chọn kỳ báo cáo", FieldType.SELECT, isRequired = true, options = listOf("2024", "2023", "2022")),
                FormField("reporting_scope", "Phạm vi báo cáo", "Mô tả phạm vi và ranh giới báo cáo", "Mô tả phạm vi báo cáo", FieldType.MULTILINE_TEXT, isRequired = true),
                FormField("methodology", "Phương pháp luận", "Phương pháp thu thập và xử lý dữ liệu", "Mô tả phương pháp luận", FieldType.MULTILINE_TEXT),
                FormField("stakeholder_engagement", "Tham vấn stakeholders", "Có tham vấn stakeholders không?", "", FieldType.CHECKBOX)
            )
            "2" -> listOf( // Quản trị và chiến lược
                FormField("governance_structure", "Cơ cấu quản trị", "Mô tả cơ cấu quản trị ESG", "Mô tả cơ cấu quản trị", FieldType.MULTILINE_TEXT, isRequired = true),
                FormField("esg_strategy", "Chiến lược ESG", "Chiến lược và mục tiêu ESG", "Mô tả chiến lược ESG", FieldType.MULTILINE_TEXT, isRequired = true),
                FormField("risk_management", "Quản lý rủi ro", "Hệ thống quản lý rủi ro ESG", "Mô tả hệ thống quản lý rủi ro", FieldType.MULTILINE_TEXT),
                FormField("esg_committee", "Ủy ban ESG", "Có ủy ban ESG riêng không?", "", FieldType.CHECKBOX),
                FormField("esg_budget", "Ngân sách ESG", "Ngân sách dành cho ESG (triệu VND)", "Nhập số tiền", FieldType.NUMBER)
            )
            "3" -> listOf( // Môi trường
                FormField("ghg_emissions", "Phát thải khí nhà kính", "Tổng phát thải CO2 (tấn)", "Nhập số lượng", FieldType.NUMBER, isRequired = true),
                FormField("energy_consumption", "Tiêu thụ năng lượng", "Tổng tiêu thụ năng lượng (MWh)", "Nhập số lượng", FieldType.NUMBER, isRequired = true),
                FormField("water_consumption", "Tiêu thụ nước", "Tổng tiêu thụ nước (m³)", "Nhập số lượng", FieldType.NUMBER),
                FormField("waste_generated", "Chất thải phát sinh", "Tổng chất thải phát sinh (tấn)", "Nhập số lượng", FieldType.NUMBER),
                FormField("renewable_energy", "Năng lượng tái tạo", "Tỷ lệ năng lượng tái tạo (%)", "Nhập tỷ lệ", FieldType.NUMBER),
                FormField("environmental_initiatives", "Sáng kiến môi trường", "Các sáng kiến bảo vệ môi trường", "Mô tả các sáng kiến", FieldType.MULTILINE_TEXT)
            )
            "4" -> listOf( // Xã hội
                FormField("total_employees", "Tổng số nhân viên", "Số lượng nhân viên", "Nhập số lượng", FieldType.NUMBER, isRequired = true),
                FormField("female_employees", "Nhân viên nữ", "Tỷ lệ nhân viên nữ (%)", "Nhập tỷ lệ", FieldType.NUMBER),
                FormField("training_hours", "Giờ đào tạo", "Tổng giờ đào tạo nhân viên", "Nhập số giờ", FieldType.NUMBER),
                FormField("safety_incidents", "Tai nạn lao động", "Số vụ tai nạn lao động", "Nhập số vụ", FieldType.NUMBER),
                FormField("community_investment", "Đầu tư cộng đồng", "Số tiền đầu tư cho cộng đồng (triệu VND)", "Nhập số tiền", FieldType.NUMBER),
                FormField("human_rights_policy", "Chính sách nhân quyền", "Có chính sách nhân quyền không?", "", FieldType.CHECKBOX)
            )
            "5" -> listOf( // Kinh tế
                FormField("revenue", "Doanh thu", "Tổng doanh thu (triệu VND)", "Nhập doanh thu", FieldType.NUMBER, isRequired = true),
                FormField("tax_contribution", "Đóng góp thuế", "Tổng số thuế đã nộp (triệu VND)", "Nhập số tiền", FieldType.NUMBER),
                FormField("local_procurement", "Mua sắm địa phương", "Tỷ lệ mua sắm từ nhà cung cấp địa phương (%)", "Nhập tỷ lệ", FieldType.NUMBER),
                FormField("economic_impact", "Tác động kinh tế", "Mô tả tác động kinh tế đến địa phương", "Mô tả tác động", FieldType.MULTILINE_TEXT)
            )
            else -> emptyList()
        }
    }
    
    private fun getSasbFormFields(sectionId: String): List<FormField> {
        return when (sectionId) {
            "1" -> listOf( // Thông tin ngành
                FormField("industry_sector", "Lĩnh vực ngành", "Lĩnh vực hoạt động chính", "Chọn lĩnh vực", FieldType.SELECT, isRequired = true, options = listOf("Năng lượng", "Công nghiệp", "Tài chính", "Bất động sản", "Công nghệ")),
                FormField("business_model", "Mô hình kinh doanh", "Mô tả mô hình kinh doanh", "Mô tả mô hình", FieldType.MULTILINE_TEXT, isRequired = true),
                FormField("key_risks", "Rủi ro chính", "Các rủi ro ESG chính", "Mô tả rủi ro", FieldType.MULTILINE_TEXT),
                FormField("market_position", "Vị thế thị trường", "Vị thế cạnh tranh trên thị trường", "Mô tả vị thế", FieldType.MULTILINE_TEXT)
            )
            "2" -> listOf( // Môi trường
                FormField("carbon_intensity", "Cường độ carbon", "Tấn CO2/triệu VND doanh thu", "Nhập số liệu", FieldType.NUMBER, isRequired = true),
                FormField("water_intensity", "Cường độ sử dụng nước", "m³ nước/triệu VND doanh thu", "Nhập số liệu", FieldType.NUMBER),
                FormField("waste_intensity", "Cường độ chất thải", "Tấn chất thải/triệu VND doanh thu", "Nhập số liệu", FieldType.NUMBER),
                FormField("renewable_energy_ratio", "Tỷ lệ năng lượng tái tạo", "Tỷ lệ năng lượng tái tạo (%)", "Nhập tỷ lệ", FieldType.NUMBER)
            )
            "3" -> listOf( // Xã hội
                FormField("employee_turnover", "Tỷ lệ nghỉ việc", "Tỷ lệ nhân viên nghỉ việc (%)", "Nhập tỷ lệ", FieldType.NUMBER, isRequired = true),
                FormField("safety_rate", "Tỷ lệ an toàn", "Số giờ làm việc an toàn", "Nhập số giờ", FieldType.NUMBER),
                FormField("diversity_ratio", "Tỷ lệ đa dạng", "Tỷ lệ đa dạng trong lãnh đạo (%)", "Nhập tỷ lệ", FieldType.NUMBER),
                FormField("customer_satisfaction", "Hài lòng khách hàng", "Điểm hài lòng khách hàng (1-10)", "Nhập điểm", FieldType.NUMBER)
            )
            "4" -> listOf( // Quản trị
                FormField("board_independence", "Độc lập hội đồng", "Tỷ lệ thành viên độc lập (%)", "Nhập tỷ lệ", FieldType.NUMBER, isRequired = true),
                FormField("esg_oversight", "Giám sát ESG", "Có giám sát ESG ở cấp hội đồng không?", "", FieldType.CHECKBOX),
                FormField("risk_management_framework", "Khung quản lý rủi ro", "Mô tả khung quản lý rủi ro", "Mô tả khung", FieldType.MULTILINE_TEXT),
                FormField("compliance_rate", "Tỷ lệ tuân thủ", "Tỷ lệ tuân thủ quy định (%)", "Nhập tỷ lệ", FieldType.NUMBER)
            )
            else -> emptyList()
        }
    }
    
    private fun getVnFormFields(sectionId: String): List<FormField> {
        return when (sectionId) {
            "1" -> listOf( // Thông tin doanh nghiệp
                FormField("company_name_vn", "Tên công ty", "Tên đầy đủ bằng tiếng Việt", "Nhập tên công ty", FieldType.TEXT, isRequired = true),
                FormField("business_license", "Giấy phép kinh doanh", "Số giấy phép kinh doanh", "Nhập số giấy phép", FieldType.TEXT, isRequired = true),
                FormField("business_scope", "Phạm vi hoạt động", "Mô tả phạm vi hoạt động kinh doanh", "Mô tả phạm vi", FieldType.MULTILINE_TEXT, isRequired = true),
                FormField("establishment_date", "Ngày thành lập", "Ngày thành lập công ty", "Chọn ngày", FieldType.DATE),
                FormField("headquarters", "Trụ sở chính", "Địa chỉ trụ sở chính", "Nhập địa chỉ", FieldType.TEXT)
            )
            "2" -> listOf( // Tuân thủ pháp luật
                FormField("environmental_license", "Giấy phép môi trường", "Số giấy phép môi trường", "Nhập số giấy phép", FieldType.TEXT, isRequired = true),
                FormField("safety_license", "Giấy phép an toàn lao động", "Số giấy phép an toàn", "Nhập số giấy phép", FieldType.TEXT),
                FormField("compliance_status", "Tình trạng tuân thủ", "Tình trạng tuân thủ quy định", "Chọn tình trạng", FieldType.SELECT, isRequired = true, options = listOf("Tuân thủ đầy đủ", "Tuân thủ một phần", "Chưa tuân thủ")),
                FormField("violation_records", "Vi phạm", "Có vi phạm quy định không?", "", FieldType.CHECKBOX),
                FormField("penalty_amount", "Số tiền phạt", "Tổng số tiền phạt (triệu VND)", "Nhập số tiền", FieldType.NUMBER)
            )
            "3" -> listOf( // Môi trường
                FormField("waste_treatment", "Xử lý chất thải", "Phương pháp xử lý chất thải", "Mô tả phương pháp", FieldType.MULTILINE_TEXT, isRequired = true),
                FormField("emission_control", "Kiểm soát phát thải", "Biện pháp kiểm soát phát thải", "Mô tả biện pháp", FieldType.MULTILINE_TEXT),
                FormField("energy_efficiency", "Tiết kiệm năng lượng", "Biện pháp tiết kiệm năng lượng", "Mô tả biện pháp", FieldType.MULTILINE_TEXT),
                FormField("environmental_investment", "Đầu tư môi trường", "Số tiền đầu tư cho môi trường (triệu VND)", "Nhập số tiền", FieldType.NUMBER)
            )
            "4" -> listOf( // Xã hội
                FormField("employee_count", "Số nhân viên", "Tổng số nhân viên", "Nhập số lượng", FieldType.NUMBER, isRequired = true),
                FormField("local_employment", "Tuyển dụng địa phương", "Tỷ lệ tuyển dụng từ địa phương (%)", "Nhập tỷ lệ", FieldType.NUMBER),
                FormField("training_programs", "Chương trình đào tạo", "Các chương trình đào tạo nhân viên", "Mô tả chương trình", FieldType.MULTILINE_TEXT),
                FormField("community_support", "Hỗ trợ cộng đồng", "Các hoạt động hỗ trợ cộng đồng", "Mô tả hoạt động", FieldType.MULTILINE_TEXT)
            )
            else -> emptyList()
        }
    }
    
    private fun getCustomFormFields(sectionId: String): List<FormField> {
        return when (sectionId) {
            "1" -> listOf(
                FormField("custom_field_1", "Trường tùy chỉnh 1", "Mô tả trường", "Nhập giá trị", FieldType.TEXT, isRequired = true),
                FormField("custom_field_2", "Trường tùy chỉnh 2", "Mô tả trường", "Nhập giá trị", FieldType.TEXT)
            )
            "2" -> listOf(
                FormField("custom_field_3", "Trường tùy chỉnh 3", "Mô tả trường", "Nhập giá trị", FieldType.TEXT, isRequired = true),
                FormField("custom_field_4", "Trường tùy chỉnh 4", "Mô tả trường", "Nhập giá trị", FieldType.MULTILINE_TEXT)
            )
            else -> emptyList()
        }
    }
    
    private fun getTemplateSections(template: ReportStandard): List<ReportSection> {
        return when (template) {
            ReportStandard.GRI -> listOf(
                ReportSection("1", "Thông tin tổng quan", "Giới thiệu về doanh nghiệp và báo cáo", listOf("Tổng quan công ty", "Phạm vi báo cáo", "Phương pháp luận")),
                ReportSection("2", "Quản trị và chiến lược", "Cơ cấu quản trị và chiến lược ESG", listOf("Cơ cấu quản trị", "Chiến lược ESG", "Quản lý rủi ro")),
                ReportSection("3", "Môi trường", "Tác động môi trường và biện pháp", listOf("Khí thải", "Nước", "Chất thải", "Đa dạng sinh học")),
                ReportSection("4", "Xã hội", "Tác động xã hội và trách nhiệm", listOf("Lao động", "Cộng đồng", "Nhân quyền", "An toàn")),
                ReportSection("5", "Kinh tế", "Tác động kinh tế và tài chính", listOf("Hiệu quả kinh tế", "Đầu tư", "Thuế", "Tác động địa phương"))
            )
            ReportStandard.SASB -> listOf(
                ReportSection("1", "Thông tin ngành", "Thông tin cụ thể theo ngành", listOf("Phân khúc ngành", "Rủi ro ESG", "Cơ hội")),
                ReportSection("2", "Môi trường", "Tác động môi trường tài chính", listOf("Khí thải", "Nước", "Chất thải", "Năng lượng")),
                ReportSection("3", "Xã hội", "Tác động xã hội tài chính", listOf("Lao động", "An toàn", "Cộng đồng", "Sản phẩm")),
                ReportSection("4", "Quản trị", "Quản trị và rủi ro", listOf("Cơ cấu quản trị", "Quản lý rủi ro", "Tuân thủ", "Đạo đức"))
            )
            ReportStandard.VN_ENVIRONMENT -> listOf(
                ReportSection("1", "Thông tin doanh nghiệp", "Thông tin cơ bản về doanh nghiệp", listOf("Giới thiệu", "Lĩnh vực hoạt động", "Quy mô")),
                ReportSection("2", "Tuân thủ pháp luật", "Tuân thủ quy định VN", listOf("Giấy phép", "Báo cáo môi trường", "An toàn lao động")),
                ReportSection("3", "Môi trường", "Bảo vệ môi trường", listOf("Xử lý chất thải", "Tiết kiệm năng lượng", "Giảm phát thải")),
                ReportSection("4", "Xã hội", "Trách nhiệm xã hội", listOf("Lao động", "Cộng đồng", "Đào tạo", "Phúc lợi"))
            )
            ReportStandard.CUSTOM -> listOf(
                ReportSection("1", "Phần tùy chỉnh 1", "Mô tả phần báo cáo", listOf("Yêu cầu 1", "Yêu cầu 2")),
                ReportSection("2", "Phần tùy chỉnh 2", "Mô tả phần báo cáo", listOf("Yêu cầu 1", "Yêu cầu 2"))
            )
        }
    }
}
