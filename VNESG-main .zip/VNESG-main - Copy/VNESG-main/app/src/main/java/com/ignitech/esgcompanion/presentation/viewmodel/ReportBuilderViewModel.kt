package com.ignitech.esgcompanion.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ignitech.esgcompanion.data.repository.ReportRepository
import com.ignitech.esgcompanion.domain.entity.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ReportBuilderUiState(
    val isLoading: Boolean = false,
    val currentTemplate: ReportStandard? = null,
    val completedSections: Set<String> = emptySet(),
    val currentSection: String? = null,
    val reportData: Map<String, Any> = emptyMap(),
    val error: String? = null
)

@HiltViewModel
class ReportBuilderViewModel @Inject constructor(
    private val reportRepository: ReportRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(ReportBuilderUiState())
    val uiState: StateFlow<ReportBuilderUiState> = _uiState.asStateFlow()
    
    private val _navigateToSection = MutableStateFlow<String?>(null)
    val navigateToSection: StateFlow<String?> = _navigateToSection.asStateFlow()
    
    private val _navigateToPreview = MutableStateFlow(false)
    val navigateToPreview: StateFlow<Boolean> = _navigateToPreview.asStateFlow()
    
    private val userId = "enterprise_user_1" // TODO: Get from auth
    
    fun loadTemplate(template: ReportStandard) {
        viewModelScope.launch {
            _uiState.update { 
                it.copy(
                    isLoading = true,
                    currentTemplate = template,
                    error = null
                ) 
            }
            
            try {
                // Create new report in database
                val reportId = reportRepository.createReport(
                    title = "Báo cáo ${getTemplateDisplayName(template)} - Bản nháp",
                    description = "Báo cáo đang được soạn thảo",
                    standard = template,
                    template = template.name,
                    userId = userId
                )
                
                // Load template-specific data
                val templateData = loadTemplateData(template)
                
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        reportData = templateData + mapOf("reportId" to reportId)
                    ) 
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = e.message ?: "Có lỗi xảy ra khi tải mẫu báo cáo"
                    ) 
                }
            }
        }
    }
    
    fun openSection(sectionId: String) {
        _navigateToSection.value = sectionId
    }
    
    fun onNavigateToSection() {
        _navigateToSection.value = null
    }
    
    fun completeSection(sectionId: String) {
        _uiState.update { 
            it.copy(
                completedSections = it.completedSections + sectionId
            ) 
        }
    }
    
    fun saveDraft() {
        viewModelScope.launch {
            try {
                val currentState = _uiState.value
                val template = currentState.currentTemplate ?: return@launch
                
                // Create draft report
                val draftReport = ReportSummary(
                    id = generateReportId(),
                    title = "Báo cáo ${getTemplateDisplayName(template)} - Bản nháp",
                    description = "Báo cáo đang được soạn thảo",
                    status = ReportStatus.DRAFT,
                    standard = template,
                    createdAt = System.currentTimeMillis()
                )
                
                // Save to repository
                // reportRepository.saveDraft(draftReport, currentState.reportData)
                
                _uiState.update { it.copy(error = "Đã lưu bản nháp thành công") }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        error = e.message ?: "Có lỗi xảy ra khi lưu bản nháp"
                    ) 
                }
            }
        }
    }
    
    fun previewReport() {
        _navigateToPreview.value = true
    }
    
    fun onNavigateToPreview() {
        _navigateToPreview.value = false
    }
    
    fun updateReportData(sectionId: String, data: Map<String, Any>) {
        _uiState.update { 
            it.copy(
                reportData = it.reportData + data
            ) 
        }
    }
    
    private fun loadTemplateData(template: ReportStandard): Map<String, Any> {
        return when (template) {
            ReportStandard.GRI -> mapOf(
                "template_name" to "GRI Standards",
                "version" to "2021",
                "sections" to getGriSections(),
                "requirements" to getGriRequirements()
            )
            ReportStandard.SASB -> mapOf(
                "template_name" to "SASB Standards",
                "version" to "2023",
                "sections" to getSasbSections(),
                "requirements" to getSasbRequirements()
            )
            ReportStandard.VN_ENVIRONMENT -> mapOf(
                "template_name" to "Chuẩn Việt Nam",
                "version" to "2024",
                "sections" to getVnSections(),
                "requirements" to getVnRequirements()
            )
            ReportStandard.CUSTOM -> mapOf(
                "template_name" to "Tùy chỉnh",
                "version" to "1.0",
                "sections" to getCustomSections(),
                "requirements" to getCustomRequirements()
            )
        }
    }
    
    private fun getGriSections(): List<Map<String, Any>> {
        return listOf(
            mapOf("id" to "1", "title" to "Thông tin tổng quan", "weight" to 0.2),
            mapOf("id" to "2", "title" to "Quản trị và chiến lược", "weight" to 0.25),
            mapOf("id" to "3", "title" to "Môi trường", "weight" to 0.25),
            mapOf("id" to "4", "title" to "Xã hội", "weight" to 0.25),
            mapOf("id" to "5", "title" to "Kinh tế", "weight" to 0.05)
        )
    }
    
    private fun getSasbSections(): List<Map<String, Any>> {
        return listOf(
            mapOf("id" to "1", "title" to "Thông tin ngành", "weight" to 0.3),
            mapOf("id" to "2", "title" to "Môi trường", "weight" to 0.3),
            mapOf("id" to "3", "title" to "Xã hội", "weight" to 0.3),
            mapOf("id" to "4", "title" to "Quản trị", "weight" to 0.1)
        )
    }
    
    private fun getVnSections(): List<Map<String, Any>> {
        return listOf(
            mapOf("id" to "1", "title" to "Thông tin doanh nghiệp", "weight" to 0.2),
            mapOf("id" to "2", "title" to "Tuân thủ pháp luật", "weight" to 0.3),
            mapOf("id" to "3", "title" to "Môi trường", "weight" to 0.3),
            mapOf("id" to "4", "title" to "Xã hội", "weight" to 0.2)
        )
    }
    
    private fun getCustomSections(): List<Map<String, Any>> {
        return listOf(
            mapOf("id" to "1", "title" to "Phần tùy chỉnh 1", "weight" to 0.5),
            mapOf("id" to "2", "title" to "Phần tùy chỉnh 2", "weight" to 0.5)
        )
    }
    
    private fun getGriRequirements(): List<String> {
        return listOf(
            "Báo cáo phải được kiểm toán bởi bên thứ ba",
            "Cần cung cấp dữ liệu định lượng cho ít nhất 2 năm",
            "Phải có báo cáo tóm tắt cho stakeholders",
            "Cần đăng tải công khai trên website công ty"
        )
    }
    
    private fun getSasbRequirements(): List<String> {
        return listOf(
            "Tập trung vào metrics có tác động tài chính",
            "Dữ liệu phải được xác minh bởi kiểm toán viên",
            "Báo cáo theo format chuẩn của SASB",
            "Cập nhật hàng năm và so sánh với năm trước"
        )
    }
    
    private fun getVnRequirements(): List<String> {
        return listOf(
            "Tuân thủ quy định của Bộ Tài nguyên và Môi trường",
            "Báo cáo bằng tiếng Việt",
            "Cần có xác nhận của cơ quan có thẩm quyền",
            "Đăng tải trên cổng thông tin điện tử của cơ quan quản lý"
        )
    }
    
    private fun getCustomRequirements(): List<String> {
        return listOf(
            "Tùy chỉnh theo yêu cầu cụ thể của doanh nghiệp",
            "Có thể kết hợp nhiều chuẩn khác nhau",
            "Cần xác định rõ metrics và KPIs",
            "Thiết kế phù hợp với đối tượng đọc báo cáo"
        )
    }
    
    private fun getTemplateDisplayName(template: ReportStandard): String {
        return when (template) {
            ReportStandard.GRI -> "GRI Standards"
            ReportStandard.SASB -> "SASB Standards"
            ReportStandard.VN_ENVIRONMENT -> "Chuẩn Việt Nam"
            ReportStandard.CUSTOM -> "Báo cáo tùy chỉnh"
        }
    }
    
    private fun generateReportId(): String {
        return "report_${System.currentTimeMillis()}"
    }
}
