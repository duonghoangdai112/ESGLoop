package com.ignitech.esgcompanion.presentation.screen.enterprise

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ignitech.esgcompanion.data.entity.*
import com.ignitech.esgcompanion.domain.entity.ESGPillar
import com.ignitech.esgcompanion.presentation.viewmodel.AddActivityViewModel
import com.ignitech.esgcompanion.utils.AppColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddActivityScreen(
    onBack: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: AddActivityViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = AppColors()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "Thêm hoạt động ESG",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            viewModel.saveActivity()
                            onSave()
                        },
                        enabled = uiState.isFormValid
                    ) {
                        Text(
                            "Lưu",
                            color = if (uiState.isFormValid) colors.primary else colors.textSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.backgroundSurface,
                    titleContentColor = colors.textPrimary
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(colors.backgroundSurface),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Activity Type Selection
            item {
                Text(
                    text = "Loại hoạt động",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                ActivityTypeGrid(
                    selectedType = uiState.selectedActivityType,
                    onTypeSelected = viewModel::selectActivityType
                )
            }

            // Basic Information
            item {
                Text(
                    text = "Thông tin cơ bản",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }

            // Title
            item {
                OutlinedTextField(
                    value = uiState.title,
                    onValueChange = viewModel::updateTitle,
                    label = { Text("Tiêu đề hoạt động") },
                    placeholder = { 
                        Text(
                            text = "Nhập tiêu đề hoạt động...",
                            color = colors.textSecondary.copy(alpha = 0.6f)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = uiState.titleError.isNotEmpty(),
                    supportingText = if (uiState.titleError.isNotEmpty()) {
                        { Text(uiState.titleError, color = MaterialTheme.colorScheme.error) }
                    } else null
                )
            }

            // Description
            item {
                OutlinedTextField(
                    value = uiState.description,
                    onValueChange = viewModel::updateDescription,
                    label = { Text("Mô tả chi tiết") },
                    placeholder = { 
                        Text(
                            text = "Mô tả chi tiết về hoạt động...",
                            color = colors.textSecondary.copy(alpha = 0.6f)
                        ) 
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    maxLines = 4,
                    isError = uiState.descriptionError.isNotEmpty(),
                    supportingText = if (uiState.descriptionError.isNotEmpty()) {
                        { Text(uiState.descriptionError, color = MaterialTheme.colorScheme.error) }
                    } else null
                )
            }

            // Pillar Selection
            item {
                Text(
                    text = "Trụ cột ESG",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                PillarSelectionRow(
                    selectedPillar = uiState.selectedPillar,
                    onPillarSelected = viewModel::selectPillar
                )
            }

            // Priority Selection
            item {
                Text(
                    text = "Mức độ ưu tiên",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                PrioritySelectionRow(
                    selectedPriority = uiState.selectedPriority,
                    onPrioritySelected = viewModel::selectPriority
                )
            }

            // Date Selection
            item {
                Text(
                    text = "Ngày thực hiện",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            
            item {
                DateSelectionCard(
                    selectedDate = uiState.plannedDate,
                    onDateSelected = viewModel::selectDate
                )
            }

            // Additional Information
            item {
                Text(
                    text = "Thông tin bổ sung",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }

            // Department
            item {
                OutlinedTextField(
                    value = uiState.department,
                    onValueChange = viewModel::updateDepartment,
                    label = { Text("Phòng ban") },
                    placeholder = { 
                        Text(
                            text = "VD: Phòng Môi trường",
                            color = colors.textSecondary.copy(alpha = 0.6f)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            // Location
            item {
                OutlinedTextField(
                    value = uiState.location,
                    onValueChange = viewModel::updateLocation,
                    label = { Text("Địa điểm") },
                    placeholder = { 
                        Text(
                            text = "VD: Trụ sở chính",
                            color = colors.textSecondary.copy(alpha = 0.6f)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            // Budget
            item {
                OutlinedTextField(
                    value = uiState.budget,
                    onValueChange = viewModel::updateBudget,
                    label = { Text("Ngân sách (VNĐ)") },
                    placeholder = { 
                        Text(
                            text = "VD: 10000000",
                            color = colors.textSecondary.copy(alpha = 0.6f)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = uiState.budgetError.isNotEmpty(),
                    supportingText = if (uiState.budgetError.isNotEmpty()) {
                        { Text(uiState.budgetError, color = MaterialTheme.colorScheme.error) }
                    } else null
                )
            }

            // Notes
            item {
                OutlinedTextField(
                    value = uiState.notes,
                    onValueChange = viewModel::updateNotes,
                    label = { Text("Ghi chú") },
                    placeholder = { 
                        Text(
                            text = "Ghi chú thêm...",
                            color = colors.textSecondary.copy(alpha = 0.6f)
                        ) 
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    maxLines = 3
                )
            }

            // Spacer for bottom padding
            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun ActivityTypeGrid(
    selectedType: ESGTrackerType?,
    onTypeSelected: (ESGTrackerType) -> Unit
) {
    val colors = AppColors()
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(ESGTrackerType.values().toList()) { type ->
            ActivityTypeChip(
                type = type,
                isSelected = type == selectedType,
                onClick = { onTypeSelected(type) }
            )
        }
    }
}

@Composable
fun ActivityTypeChip(
    type: ESGTrackerType,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = AppColors()
    
    Surface(
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple()
        ) { onClick() },
        color = if (isSelected) colors.primary else colors.backgroundSurface,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) colors.primary else colors.borderLight
        )
    ) {
        Text(
            text = when (type) {
                ESGTrackerType.ENERGY_EFFICIENCY -> "Tiết kiệm năng lượng"
                ESGTrackerType.WASTE_REDUCTION -> "Giảm rác thải"
                ESGTrackerType.WATER_CONSERVATION -> "Tiết kiệm nước"
                ESGTrackerType.RENEWABLE_ENERGY -> "Năng lượng tái tạo"
                ESGTrackerType.CARBON_REDUCTION -> "Giảm phát thải"
                ESGTrackerType.POLLUTION_CONTROL -> "Kiểm soát ô nhiễm"
                ESGTrackerType.BIODIVERSITY -> "Đa dạng sinh học"
                ESGTrackerType.SUSTAINABLE_MATERIALS -> "Vật liệu bền vững"
                ESGTrackerType.EMPLOYEE_TRAINING -> "Đào tạo nhân viên"
                ESGTrackerType.SAFETY_IMPROVEMENT -> "Cải thiện an toàn"
                ESGTrackerType.COMMUNITY_OUTREACH -> "Hỗ trợ cộng đồng"
                ESGTrackerType.DIVERSITY_INCLUSION -> "Đa dạng & hòa nhập"
                ESGTrackerType.WORK_LIFE_BALANCE -> "Cân bằng công việc"
                ESGTrackerType.HEALTH_WELLNESS -> "Sức khỏe & phúc lợi"
                ESGTrackerType.EDUCATION_SUPPORT -> "Hỗ trợ giáo dục"
                ESGTrackerType.LOCAL_DEVELOPMENT -> "Phát triển địa phương"
                ESGTrackerType.POLICY_UPDATE -> "Cập nhật chính sách"
                ESGTrackerType.COMPLIANCE_AUDIT -> "Kiểm toán tuân thủ"
                ESGTrackerType.RISK_MANAGEMENT -> "Quản lý rủi ro"
                ESGTrackerType.TRANSPARENCY_REPORT -> "Báo cáo minh bạch"
                ESGTrackerType.STAKEHOLDER_ENGAGEMENT -> "Tương tác bên liên quan"
                ESGTrackerType.ETHICS_TRAINING -> "Đào tạo đạo đức"
                ESGTrackerType.BOARD_DIVERSITY -> "Đa dạng hội đồng"
                ESGTrackerType.SUSTAINABILITY_STRATEGY -> "Chiến lược bền vững"
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else colors.textPrimary
        )
    }
}

@Composable
fun PillarSelectionRow(
    selectedPillar: ESGPillar?,
    onPillarSelected: (ESGPillar) -> Unit
) {
    val colors = AppColors()
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ESGPillar.values().forEach { pillar ->
            PillarSelectionCard(
                pillar = pillar,
                isSelected = pillar == selectedPillar,
                onClick = { onPillarSelected(pillar) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun PillarSelectionCard(
    pillar: ESGPillar,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AppColors()
    val (icon, title, color) = when (pillar) {
        ESGPillar.ENVIRONMENTAL -> Triple("🌱", "Môi trường", Color(0xFF4CAF50))
        ESGPillar.SOCIAL -> Triple("👥", "Xã hội", Color(0xFF2196F3))
        ESGPillar.GOVERNANCE -> Triple("🏛️", "Quản trị", Color(0xFF9C27B0))
    }
    
    Surface(
        modifier = modifier
            .height(80.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() },
        color = if (isSelected) color.copy(alpha = 0.1f) else colors.backgroundSurface,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) color else colors.borderLight
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = icon,
                style = MaterialTheme.typography.headlineSmall
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) color else colors.textPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun PrioritySelectionRow(
    selectedPriority: TrackerPriority?,
    onPrioritySelected: (TrackerPriority) -> Unit
) {
    val colors = AppColors()
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TrackerPriority.values().forEach { priority ->
            PriorityChip(
                priority = priority,
                isSelected = priority == selectedPriority,
                onClick = { onPrioritySelected(priority) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun PriorityChip(
    priority: TrackerPriority,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AppColors()
    val (text, color) = when (priority) {
        TrackerPriority.LOW -> "Thấp" to Color(0xFF4CAF50)
        TrackerPriority.MEDIUM -> "Trung bình" to Color(0xFFFF9800)
        TrackerPriority.HIGH -> "Cao" to Color(0xFFFF5722)
        TrackerPriority.CRITICAL -> "Khẩn cấp" to Color(0xFFF44336)
    }
    
    Surface(
        modifier = modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { onClick() },
        color = if (isSelected) color.copy(alpha = 0.1f) else colors.backgroundSurface,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) color else colors.borderLight
        )
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) color else colors.textPrimary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun DateSelectionCard(
    selectedDate: Long,
    onDateSelected: (Long) -> Unit
) {
    val colors = AppColors()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    var showDatePicker by remember { mutableStateOf(false) }
    
    OutlinedTextField(
        value = dateFormat.format(Date(selectedDate)),
        onValueChange = { },
        label = { Text("Ngày dự kiến thực hiện") },
        readOnly = true,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) { showDatePicker = true },
        trailingIcon = {
            Icon(
                Icons.Default.CalendarToday,
                contentDescription = "Chọn ngày",
                tint = colors.primary
            )
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.primary,
            unfocusedBorderColor = colors.borderLight,
            focusedLabelColor = colors.primary,
            unfocusedLabelColor = colors.textSecondary
        )
    )
    
    if (showDatePicker) {
        // TODO: Implement date picker dialog
    }
}
