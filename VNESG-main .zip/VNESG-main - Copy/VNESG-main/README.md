# Android Base Project

Một base project Android Kotlin với MVVM Clean Architecture và các công nghệ chuẩn.

## 🏗️ Kiến trúc

Project sử dụng **Clean Architecture** với các layer:

- **Presentation Layer**: UI Components, ViewModels, Screens
- **Domain Layer**: Entities, Use Cases, Repository Interfaces
- **Data Layer**: Repository Implementations, Data Sources (Local & Remote)

## 🛠️ Công nghệ sử dụng

### Core
- **Kotlin** - Ngôn ngữ lập trình chính
- **Jetpack Compose** - UI framework
- **Material 3** - Design system

### Architecture Components
- **ViewModel** - Quản lý UI state
- **LiveData/StateFlow** - Reactive programming
- **Navigation Component** - Navigation giữa các screen

### Dependency Injection
- **Hilt** - Dependency injection framework

### Networking
- **Retrofit** - HTTP client
- **OkHttp** - HTTP client với logging
- **Gson** - JSON serialization

### Database
- **Room** - Local database
- **SQLite** - Database engine

### Image Loading
- **Coil** - Image loading library

### Testing
- **JUnit** - Unit testing
- **Mockito** - Mocking framework
- **Turbine** - Flow testing
- **Espresso** - UI testing

## 📁 Cấu trúc thư mục

```
app/src/main/java/com/example/androidbaseproject/
├── data/
│   ├── local/
│   │   ├── entity/          # Room entities
│   │   ├── dao/             # Data Access Objects
│   │   └── AppDatabase.kt   # Database configuration
│   ├── remote/
│   │   ├── dto/             # Data Transfer Objects
│   │   ├── ApiService.kt    # API interface
│   │   └── NetworkModule.kt # Network configuration
│   ├── repository/          # Repository implementations
│   └── mapper/              # Data mappers
├── domain/
│   ├── entity/              # Domain entities
│   ├── repository/          # Repository interfaces
│   └── usecase/             # Use cases
├── presentation/
│   ├── screen/              # Compose screens
│   ├── viewmodel/           # ViewModels
│   └── component/           # Reusable UI components
├── di/                      # Dependency injection modules
├── util/                    # Utility classes
└── common/                  # Common base classes
```

## 🚀 Cách sử dụng

### 1. Clone project
```bash
git clone <repository-url>
cd android-base-project
```

### 2. Mở project trong Android Studio
- Mở Android Studio
- Chọn "Open an existing project"
- Chọn thư mục project

### 3. Sync project
- Android Studio sẽ tự động sync dependencies
- Nếu có lỗi, chọn "Sync Now" trong notification

### 4. Chạy project
- Kết nối thiết bị Android hoặc khởi động emulator
- Nhấn nút "Run" hoặc Shift + F10

## 📝 Tạo feature mới

### 1. Tạo Entity trong Domain Layer
```kotlin
// domain/entity/YourEntity.kt
data class YourEntity(
    val id: Int,
    val name: String
)
```

### 2. Tạo Repository Interface
```kotlin
// domain/repository/YourRepository.kt
interface YourRepository {
    suspend fun getData(): Flow<Result<List<YourEntity>>>
}
```

### 3. Tạo DTO cho API
```kotlin
// data/remote/dto/YourDto.kt
data class YourDto(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String
)
```

### 4. Tạo Room Entity
```kotlin
// data/local/entity/YourEntity.kt
@Entity(tableName = "your_table")
data class YourEntity(
    @PrimaryKey val id: Int,
    val name: String
)
```

### 5. Tạo DAO
```kotlin
// data/local/dao/YourDao.kt
@Dao
interface YourDao {
    @Query("SELECT * FROM your_table")
    fun getAll(): Flow<List<YourEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: YourEntity)
}
```

### 6. Tạo Repository Implementation
```kotlin
// data/repository/YourRepositoryImpl.kt
@Singleton
class YourRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    private val yourDao: YourDao
) : BaseRepository(), YourRepository {
    
    override suspend fun getData(): Flow<Result<List<YourEntity>>> {
        return safeApiCall {
            // API call logic
        }
    }
}
```

### 7. Tạo ViewModel
```kotlin
// presentation/viewmodel/YourViewModel.kt
@HiltViewModel
class YourViewModel @Inject constructor(
    private val repository: YourRepository
) : BaseViewModel<YourViewModel.UiState, YourViewModel.UiEvent>() {
    
    data class UiState(
        val data: List<YourEntity> = emptyList(),
        val isLoading: Boolean = false
    )
    
    sealed class UiEvent {
        object LoadData : UiEvent()
    }
    
    override fun createInitialState(): UiState = UiState()
    
    override suspend fun onEvent(event: UiEvent) {
        when (event) {
            is UiEvent.LoadData -> loadData()
        }
    }
    
    private fun loadData() {
        // Load data logic
    }
}
```

### 8. Tạo Screen
```kotlin
// presentation/screen/YourScreen.kt
@Composable
fun YourScreen(
    modifier: Modifier = Modifier,
    viewModel: YourViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    // UI implementation
}
```

## 🔧 Cấu hình

### API Base URL
Cập nhật `BASE_URL` trong `util/Constants.kt`:
```kotlin
const val BASE_URL = "https://your-api.com/"
```

### Database
Cập nhật database version trong `util/Constants.kt`:
```kotlin
const val DATABASE_VERSION = 1
```

## 🧪 Testing

### Unit Tests
```bash
./gradlew test
```

### Instrumented Tests
```bash
./gradlew connectedAndroidTest
```

## 📦 Dependencies chính

- **AndroidX Core**: 1.17.0
- **Compose BOM**: 2024.09.00
- **Lifecycle**: 2.9.3
- **Hilt**: 2.52
- **Retrofit**: 2.11.0
- **Room**: 2.6.1
- **Coil**: 2.7.0

## 🤝 Đóng góp

1. Fork project
2. Tạo feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Tạo Pull Request

## 📄 License

Distributed under the MIT License. See `LICENSE` for more information.

## 📞 Liên hệ

Project Link: [https://github.com/yourusername/android-base-project](https://github.com/yourusername/android-base-project)

